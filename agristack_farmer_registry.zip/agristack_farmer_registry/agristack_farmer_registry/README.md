# AgriStack Farmer Registry Portal

## Academic Prototype Disclaimer
This is an academic prototype designed for a B.Tech final-year project. It demonstrates digital farmer registration, identity verification workflows, farm registration, geo-tagging, agricultural scheme applications, eSign, paperless documentation, and DBT transaction simulation.
**This is NOT an official UIDAI, AgriStack, or Government of India application.**

## Technology Stack
- Frontend: HTML5, CSS3, JavaScript, Bootstrap 5, Leaflet.js
- Backend: PHP 8+
- Database: MySQL
- Server: XAMPP (Apache + MySQL)

## Features
- **Farmer Portal:** Registration with mandatory email, Profile with email edit/validation, Demo SSO, eKYC (Simulated photo extraction), Farm Registry, Geo-Tagging, Scheme Application, eSign (Canvas/Upload demo + Verified emSigner integration architecture), Printable Dossier.
- **Admin Portal:** Dashboard, Farmer Verification, eKYC Review, Document Review, Application Review, DBT Sandbox (Simulation with direct Farmer and Admin email notifications), Audit Logs.
- **eSign Module:** Pre-configured architecture for verified digital signature providers (e.g. emSigner) linking signer email and application metadata, with Demo Canvas/Upload signatures clearly labeled as "Demo eSign — Not legally certified".

## Setup Instructions
1. Clone or extract this project to `C:\xampp\htdocs\agristack_farmer_registry`
2. Start Apache and MySQL via XAMPP Control Panel.
3. Import `database.sql` into a new database named `agristack_farmer_registry` using phpMyAdmin or CLI.
4. Access the application at: `http://localhost/agristack_farmer_registry/`

## Demo Credentials
**Admin Account:**
- Email: admin@agristack-demo.local
- Password: Admin@12345

**Farmer Account:**
- Mobile: 8888888888 (or Email: farmer@agristack-demo.local)
- Password: Farmer@12345
- Demo SSO can also be used for farmer login.

## Limitations & Legal Disclaimers
- eKYC uses basic image handling to simulate photo extraction.
- eSign canvas & image upload tools are for academic simulation only and are **not legally certified**. Integration architecture is prepared for certified providers (emSigner).
- DBT Sandbox is a simulation; no real money is transferred.
- SSO is a direct session generation simulation, not a real OAuth flow.
