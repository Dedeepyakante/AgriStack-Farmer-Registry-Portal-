<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../config/mailer.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_id = (int)$_POST['app_id'];
    $user_id = (int)$_POST['user_id'];
    $status = trim($_POST['status'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    
    // Fetch application details before or during update
    $appQ = $pdo->prepare("SELECT a.application_id, s.scheme_name FROM scheme_applications a JOIN schemes s ON a.scheme_id = s.id WHERE a.id = ?");
    $appQ->execute([$app_id]);
    $appData = $appQ->fetch();

    $stmt = $pdo->prepare("UPDATE scheme_applications SET status=?, admin_remarks=? WHERE id=?");
    $stmt->execute([$status, $remarks, $app_id]);
    
    logAudit($pdo, getUserId(), 'admin', 'App Review', "Application ID {$appData['application_id']} status changed to {$status}.");
    sendNotification($pdo, $user_id, "Application Status Updated", "Your application status is now {$status}. Remarks: {$remarks}");
    
    // Dispatch direct email to the Farmer
    if ($appData) {
        notifyFarmerOfApplicationStatus($pdo, $user_id, $appData['application_id'], $appData['scheme_name'], $status, $remarks);
    }
    
    $message = "Application updated successfully and status notification email was dispatched to the farmer.";
}

$stmt = $pdo->query("SELECT a.*, u.name, u.farmer_id, u.email, s.scheme_name, f.farm_name,
                            es.signature_path, es.signature_type, es.provider_ref_id, es.farmer_email as esign_email, es.signed_at as esign_signed_at
                     FROM scheme_applications a 
                     JOIN users u ON a.user_id = u.id 
                     JOIN schemes s ON a.scheme_id = s.id 
                     LEFT JOIN farms f ON a.farm_id = f.id 
                     LEFT JOIN esignatures es ON (a.esign_id = es.id OR (a.application_id = es.application_id AND a.application_id IS NOT NULL))
                     ORDER BY a.id DESC");
$apps = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Scheme Applications Review</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="accordion" id="appAccordion">
            <?php foreach($apps as $index => $app): ?>
            <div class="accordion-item mb-2 border rounded shadow-sm">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>">
                        <strong><?= htmlspecialchars($app['application_id']) ?></strong>&nbsp;-&nbsp;<?= htmlspecialchars($app['scheme_name']) ?>&nbsp;(<?= htmlspecialchars($app['farmer_id']) ?>)
                        <span class="badge ms-auto me-2 <?= !empty($app['signature_path']) ? ($app['signature_type']=='verified_provider' ? 'bg-success' : 'bg-warning text-dark') : 'bg-light text-muted border' ?>">
                            <i class="bi bi-pen me-1"></i><?= !empty($app['signature_path']) ? ($app['signature_type']=='verified_provider' ? 'Verified eSign' : 'Demo eSign') : 'Unsigned' ?>
                        </span>
                        <span class="badge <?= $app['status']=='Approved'?'bg-success':($app['status']=='Rejected'?'bg-danger':'bg-warning text-dark') ?>">
                            <?= $app['status'] ?>
                        </span>
                    </button>
                </h2>
                <div id="collapse<?= $index ?>" class="accordion-collapse collapse" data-bs-parent="#appAccordion">
                    <div class="accordion-body">
                        <div class="row mb-3">
                            <div class="col-md-3"><strong>Farmer:</strong> <?= htmlspecialchars($app['name']) ?></div>
                            <div class="col-md-3"><strong>Registered Email:</strong> <?= htmlspecialchars($app['email'] ?? 'N/A') ?></div>
                            <div class="col-md-3"><strong>Farm:</strong> <?= htmlspecialchars($app['farm_name'] ?? 'N/A') ?></div>
                            <div class="col-md-3"><strong>Applied On:</strong> <?= date('d M Y', strtotime($app['applied_at'])) ?></div>
                        </div>

                        <!-- eSign Review Box -->
                        <div class="border rounded p-3 mb-3 bg-white shadow-sm">
                            <h6 class="fw-bold mb-2"><i class="bi bi-patch-check me-1 text-primary"></i> Digital eSign Verification Status</h6>
                            <?php if(!empty($app['signature_path'])): ?>
                                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                                    <div>
                                        <?php if($app['signature_type'] === 'verified_provider'): ?>
                                            <span class="badge bg-success mb-1"><i class="bi bi-patch-check-fill me-1"></i>Verified Digital Signature (eMudhra emSigner)</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark mb-1"><i class="bi bi-shield-exclamation me-1"></i>Demo eSign — Not legally certified</span>
                                        <?php endif; ?>
                                        <br>
                                        <small class="text-muted">
                                            Signer Email: <strong><?= htmlspecialchars($app['esign_email'] ?? $app['email'] ?? 'N/A') ?></strong> &bull;
                                            Ref ID: <span class="font-monospace"><?= htmlspecialchars($app['provider_ref_id'] ?? 'N/A') ?></span> &bull;
                                            Signed: <?= date('d M Y, h:i A', strtotime($app['esign_signed_at'])) ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <a href="../uploads/signatures/<?= htmlspecialchars($app['signature_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye me-1"></i> View Signature
                                        </a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <p class="text-muted small mb-0">
                                    <i class="bi bi-info-circle me-1"></i> No electronic signature has been attached to this application yet.
                                </p>
                            <?php endif; ?>
                        </div>
                        
                        <form method="post" class="border p-3 rounded bg-light">
                            <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                            <input type="hidden" name="user_id" value="<?= $app['user_id'] ?>">
                            <div class="row align-items-end">
                                <div class="col-md-4">
                                    <label>Update Status</label>
                                    <select name="status" class="form-select">
                                        <option value="Under Review" <?= $app['status']=='Under Review'?'selected':'' ?>>Under Review</option>
                                        <option value="Approved" <?= $app['status']=='Approved'?'selected':'' ?>>Approved</option>
                                        <option value="Rejected" <?= $app['status']=='Rejected'?'selected':'' ?>>Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Admin Remarks</label>
                                    <input type="text" name="remarks" class="form-control" value="<?= htmlspecialchars($app['admin_remarks'] ?? '') ?>">
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
