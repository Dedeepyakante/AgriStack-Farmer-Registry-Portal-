<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$stmt = $pdo->query("SELECT a.*, u.name, u.farmer_id FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.id DESC LIMIT 200");
$logs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">System Audit Logs</h2>
        
        <div class="table-responsive bg-white rounded shadow-sm border-0">
            <table class="table table-hover table-sm mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Timestamp</th>
                        <th>Role</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($logs as $log): ?>
                    <tr>
                        <td style="white-space:nowrap;"><?= $log['created_at'] ?></td>
                        <td><span class="badge bg-secondary"><?= htmlspecialchars($log['role']) ?></span></td>
                        <td><?= htmlspecialchars($log['name'] ?? 'System') ?> <?= $log['farmer_id']?"({$log['farmer_id']})":"" ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($log['action']) ?></td>
                        <td><?= htmlspecialchars($log['description']) ?></td>
                        <td><?= htmlspecialchars($log['ip_address']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
