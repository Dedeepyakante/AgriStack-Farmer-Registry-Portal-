<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$stats = [
    'farmers' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='farmer'")->fetchColumn(),
    'pending_ekyc' => $pdo->query("SELECT COUNT(*) FROM identity_verifications WHERE status='Pending'")->fetchColumn(),
    'farms' => $pdo->query("SELECT COUNT(*) FROM farms")->fetchColumn(),
    'pending_apps' => $pdo->query("SELECT COUNT(*) FROM scheme_applications WHERE status IN ('Submitted', 'Under Review')")->fetchColumn(),
    'dbt_tx' => $pdo->query("SELECT COUNT(*) FROM dbt_transactions")->fetchColumn(),
    'pending_docs' => $pdo->query("SELECT COUNT(*) FROM documents WHERE status != 'Approved and signed'")->fetchColumn(),
    'market_tx' => $pdo->query("SELECT COUNT(*) FROM market_transactions")->fetchColumn(),
    'awaiting_sig' => $pdo->query("SELECT COUNT(*) FROM transaction_agreements WHERE agreement_status = 'Awaiting signatures'")->fetchColumn(),
];
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h2 class="mb-0">Admin Dashboard</h2>
            <div class="d-flex gap-2">
                <a href="transactions.php" class="btn btn-outline-success fw-semibold shadow-sm">
                    <i class="bi bi-receipt me-1"></i>Transactions &amp; emSigner
                </a>
                <a href="https://demo.emsigner.com/" target="_blank" class="btn btn-success fw-semibold shadow-sm">
                    <i class="bi bi-box-arrow-up-right me-1"></i>Open emSigner
                </a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="card bg-success text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-people fs-1 mb-2"></i>
                        <h5>Total Farmers</h5>
                        <h2 class="fw-bold"><?= $stats['farmers'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-warning text-dark border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-fingerprint fs-1 mb-2"></i>
                        <h5>Pending eKYC</h5>
                        <h2 class="fw-bold"><?= $stats['pending_ekyc'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-info text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-geo-alt fs-1 mb-2"></i>
                        <h5>Registered Farms</h5>
                        <h2 class="fw-bold"><?= $stats['farms'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-danger text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-ui-checks fs-1 mb-2"></i>
                        <h5>Pending Apps</h5>
                        <h2 class="fw-bold"><?= $stats['pending_apps'] ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- emSigner Signing Workflow Cards -->
        <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-pen me-2 text-success"></i>emSigner Workflow &amp; Three-Way Status Tracking</h5>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted small text-uppercase fw-semibold">Pending Document Approvals</span>
                        <i class="bi bi-file-earmark-text text-warning fs-4"></i>
                    </div>
                    <h3 class="fw-bold mb-1 text-dark"><?= $stats['pending_docs'] ?></h3>
                    <small class="text-muted mb-3 d-block">Documents awaiting admin review &amp; emSigner signature</small>
                    <a href="documents.php" class="btn btn-sm btn-outline-warning text-dark fw-semibold mt-auto">
                        <i class="bi bi-arrow-right me-1"></i>Review in Document Repository
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-primary border-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted small text-uppercase fw-semibold">Market Transactions</span>
                        <i class="bi bi-receipt text-primary fs-4"></i>
                    </div>
                    <h3 class="fw-bold mb-1 text-dark"><?= $stats['market_tx'] ?></h3>
                    <small class="text-muted mb-3 d-block">Agreements created between farmers &amp; buyers</small>
                    <a href="transactions.php" class="btn btn-sm btn-outline-primary fw-semibold mt-auto">
                        <i class="bi bi-arrow-right me-1"></i>Manage Transactions
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4 h-100">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted small text-uppercase fw-semibold">Agreements Awaiting Signatures</span>
                        <i class="bi bi-pen-fill text-success fs-4"></i>
                    </div>
                    <h3 class="fw-bold mb-1 text-dark"><?= $stats['awaiting_sig'] ?></h3>
                    <small class="text-muted mb-3 d-block">Confirmed agreements requiring Farmer &amp; Admin signatures</small>
                    <a href="transactions.php" class="btn btn-sm btn-success fw-semibold mt-auto">
                        <i class="bi bi-arrow-right me-1"></i>Sign in emSigner
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
