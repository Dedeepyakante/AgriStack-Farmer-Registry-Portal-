<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

require_once '../config/mailer.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['initiate_dbt'])) {
    $app_id    = trim($_POST['app_id']    ?? '');
    $farmer_id = trim($_POST['farmer_id'] ?? '');
    $amount    = (float)($_POST['amount'] ?? 0);

    if (empty($app_id) || empty($farmer_id) || $amount <= 0) {
        $error = 'Please select an application and enter a valid transfer amount.';
    } else {
        // Check if already paid successfully
        $chk = $pdo->prepare("SELECT id FROM dbt_transactions WHERE application_id = ? AND status = 'Success'");
        $chk->execute([$app_id]);

        if ($chk->fetch()) {
            $error = "A successful DBT transaction already exists for this application. Duplicate transfers are not allowed.";
        } else {
            $tx_id = generateTransactionId($pdo);

            // Insert the transaction record
            $stmt = $pdo->prepare("INSERT INTO dbt_transactions (transaction_id, application_id, farmer_id, amount, status) VALUES (?,?,?,?,'Success')");
            $stmt->execute([$tx_id, $app_id, $farmer_id, $amount]);

            // Fetch farmer's full details and scheme name for the notification
            $farmerData = $pdo->prepare(
                "SELECT u.id, u.name, u.email, u.mobile, u.farmer_id,
                        s.scheme_name,
                        a.application_id
                 FROM scheme_applications a
                 JOIN users u   ON a.user_id   = u.id
                 JOIN schemes s ON a.scheme_id = s.id
                 WHERE a.application_id = ?"
            );
            $farmerData->execute([$app_id]);
            $fd = $farmerData->fetch();

            if ($fd) {
                $txTimestamp = date('d M Y, h:i A');

                // ── In-app notification ──────────────────────────────────────
                sendNotification(
                    $pdo,
                    $fd['id'],
                    "DBT Credited – ₹" . number_format($amount, 2),
                    "₹" . number_format($amount, 2) . " has been credited to your DBT account for the '{$fd['scheme_name']}' scheme (Application: {$app_id}). Transaction ID: {$tx_id}."
                );

                // ── Farmer Email notification ─────────────────────────────────
                if (!empty($fd['email'])) {
                    $emailResult = notifyFarmerOfDbtTransfer(
                        $fd['email'],
                        $fd['name'],
                        $fd['scheme_name'],
                        $app_id,
                        $amount,
                        $tx_id,
                        $txTimestamp
                    );

                    if ($emailResult['mode'] === 'smtp') {
                        $farmerEmailStatus = " DBT receipt sent directly to farmer inbox (<strong>{$fd['email']}</strong>).";
                    } else {
                        $farmerEmailStatus = " DBT receipt generated &amp; logged for farmer (<strong>{$fd['email']}</strong>).";
                    }
                } else {
                    $farmerEmailStatus = " <span class='text-warning'>(No registered email on file for this farmer.)</span>";
                }

                // ── Admin DBT confirmation email (Kept as required) ──────────
                $adminUserId = getUserId();
                $admStmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
                $admStmt->execute([$adminUserId]);
                $adminUser = $admStmt->fetch();
                $adminEmail = (!empty($adminUser['email'])) ? $adminUser['email'] : (defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'admin@agristack-demo.local');
                $adminName  = $adminUser['name'] ?? 'Administrator';

                $adminEmailResult = notifyAdminOfDbtConfirmation(
                    $adminEmail,
                    $adminName,
                    $fd['name'],
                    $fd['farmer_id'],
                    $fd['scheme_name'],
                    $app_id,
                    $amount,
                    $tx_id,
                    $txTimestamp
                );
            } else {
                $farmerEmailStatus = '';
                $adminEmail = 'Administrator';
            }

            logAudit($pdo, getUserId(), 'admin', 'DBT Transfer', "DBT of Rs.{$amount} sent to {$farmer_id} (App: {$app_id}). TX: {$tx_id}.");
            $message = "✅ DBT transaction <strong>{$tx_id}</strong> of <strong>₹" . number_format($amount, 2) . "</strong> processed successfully for Application <strong>{$app_id}</strong>.<br><small class='text-muted'><i class='bi bi-envelope-fill me-1 text-success'></i>" . ($farmerEmailStatus ?? '') . "<br><i class='bi bi-shield-check me-1 text-primary'></i> Admin confirmation email dispatched to <strong>" . htmlspecialchars($adminEmail) . "</strong>.</small>";
        }
    }
}

// Get Approved applications ready for DBT
$approved_apps = $pdo->query("SELECT a.application_id, u.farmer_id, u.name, s.scheme_name FROM scheme_applications a JOIN users u ON a.user_id = u.id JOIN schemes s ON a.scheme_id = s.id WHERE a.status = 'Approved'")->fetchAll();
$transactions = $pdo->query("SELECT * FROM dbt_transactions ORDER BY id DESC")->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">DBT Sandbox <small class="text-muted">(Simulation Only)</small></h2>
        <div class="alert alert-danger fw-bold border-0 text-center">
            DBT Sandbox â€” No real money is transferred. This is an academic simulation.
        </div>
        
        <?php if($message): ?><div class="alert alert-success border-0 shadow-sm"><?= $message ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger border-0 shadow-sm"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        
        <div class="row">
            <div class="col-md-5">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-primary text-white fw-bold">Initiate Demo DBT</div>
                    <div class="card-body">
                        <form method="post">
                            <div class="mb-3">
                                <label>Select Approved Application</label>
                                <select name="app_id" class="form-select" required onchange="setFarmerId(this)">
                                    <option value="">-- Select --</option>
                                    <?php foreach($approved_apps as $a): ?>
                                        <option value="<?= $a['application_id'] ?>" data-farmer="<?= $a['farmer_id'] ?>">
                                            <?= $a['application_id'] ?> — <?= htmlspecialchars($a['name']) ?> (<?= htmlspecialchars($a['scheme_name']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Farmer ID</label>
                                <input type="text" name="farmer_id" id="farmer_id" class="form-control" readonly required>
                            </div>
                            <div class="mb-3">
                                <label>Transfer Amount (Demo ₹)</label>
                                <input type="number" name="amount" class="form-control" required min="1" step="0.01" placeholder="e.g. 5000">
                            </div>
                            <button type="submit" name="initiate_dbt" class="btn btn-primary w-100">
                                <i class="bi bi-send me-1"></i> Process Transfer &amp; Notify Farmer
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-7">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">Recent Transactions</div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Txn ID</th>
                                        <th>App ID</th>
                                        <th>Farmer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($transactions as $t): ?>
                                    <tr>
                                        <td class="fw-bold"><?= $t['transaction_id'] ?></td>
                                        <td><?= $t['application_id'] ?></td>
                                        <td><?= $t['farmer_id'] ?></td>
                                        <td>₹<?= number_format($t['amount'], 2) ?></td>
                                        <td><span class="badge bg-success"><?= $t['status'] ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if(empty($transactions)): ?>
                                        <tr><td colspan="5" class="text-center py-3 text-muted">No transactions simulated yet.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function setFarmerId(sel) {
    if(sel.selectedIndex > 0) {
        document.getElementById('farmer_id').value = sel.options[sel.selectedIndex].getAttribute('data-farmer');
    } else {
        document.getElementById('farmer_id').value = '';
    }
}
</script>
<?php require_once '../includes/footer.php'; ?>
