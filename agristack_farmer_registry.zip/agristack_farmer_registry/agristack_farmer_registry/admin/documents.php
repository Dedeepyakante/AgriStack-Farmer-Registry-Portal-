<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../config/csrf.php';
require_once '../config/esign.php';
require_once '../includes/esign_provider.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$flash_success = $_SESSION['flash_success'] ?? null;
$flash_error   = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// Handle quick mark reviewed (legacy action preserved)
if (isset($_GET['mark'])) {
    $id = (int)$_GET['mark'];
    $stmt = $pdo->prepare("UPDATE documents SET status = 'Reviewed' WHERE id = ? AND status = 'Uploaded'");
    $stmt->execute([$id]);
    logAudit($pdo, getUserId(), 'admin', 'Document Reviewed', "Marked document #{$id} as Reviewed.");
    $_SESSION['flash_success'] = "Document marked as Reviewed.";
    header("Location: documents.php");
    exit;
}

$stmt = $pdo->query(
    "SELECT d.*, u.name, u.farmer_id, u.email as farmer_email, adm.name as admin_reviewer_name
     FROM documents d 
     JOIN users u ON d.user_id = u.id 
     LEFT JOIN users adm ON d.admin_signed_by = adm.id
     ORDER BY d.id DESC LIMIT 100"
);
$docs = $stmt->fetchAll();

// Statistics
$totalDocs    = count($docs);
$approvedDocs = 0;
$pendingDocs  = 0;
$reviewedDocs = 0;
foreach ($docs as $d) {
    if ($d['status'] === 'Approved and signed') $approvedDocs++;
    elseif ($d['status'] === 'Reviewed') $reviewedDocs++;
    else $pendingDocs++;
}

$csrfToken = getCsrfToken();
$integrationInfo = getEmSignerIntegrationState();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="mb-1"><i class="bi bi-file-earmark-check text-success me-2"></i>Document Repository &amp; emSigner Approval</h2>
                <p class="text-muted mb-0">Review farmer records, sign approval via emSigner, and track cryptographic verification</p>
            </div>
            <a href="https://demo.emsigner.com/" target="_blank" class="btn btn-outline-success fw-semibold shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i>Open emSigner Platform
            </a>
        </div>

        <?php if($flash_success): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($flash_error): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Stat Cards -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white">
                    <span class="text-muted small text-uppercase fw-semibold">Total Documents</span>
                    <h3 class="fw-bold mb-0 text-dark"><?= $totalDocs ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Pending Approval</span>
                    <h3 class="fw-bold mb-0 text-warning"><?= $pendingDocs ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Approved &amp; Signed</span>
                    <h3 class="fw-bold mb-0 text-success"><?= $approvedDocs ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-info border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Reviewed</span>
                    <h3 class="fw-bold mb-0 text-info"><?= $reviewedDocs ?></h3>
                </div>
            </div>
        </div>

        <!-- emSigner External Signing Guidance Banner -->
        <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #0b2545 0%, #134074 100%); color: #ffffff;">
            <div class="card-body p-4">
                <div class="d-flex align-items-start gap-3">
                    <span class="badge bg-white text-dark p-2 rounded-circle fs-3 flex-shrink-0">
                        <i class="bi bi-shield-lock-fill text-success"></i>
                    </span>
                    <div>
                        <h5 class="fw-bold mb-1">External Document Signing via emSigner (https://demo.emsigner.com/)</h5>
                        <p class="mb-2 opacity-90 small">
                            Clicking <strong>Review &amp; Sign in emSigner</strong> directs administrators to the official external emSigner portal.
                            As live server-to-server gateway credentials are not yet connected, document transfer, automatic return, and instant signature synchronization must be verified via the backend.
                        </p>
                        <div class="p-2 rounded bg-white bg-opacity-10 small">
                            <i class="bi bi-exclamation-triangle-fill text-warning me-1"></i>
                            <strong>Enforced Policy:</strong> Opening emSigner alone does <strong>not</strong> approve any document. A document is marked <strong>“Approved and signed”</strong> only after receiving and verifying the actual signing result on the backend.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Documents Table -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span class="fw-bold"><i class="bi bi-folder2-open me-2 text-primary"></i>Farmer Submitted Documents</span>
                <span class="badge bg-light text-dark border">Backend Verification Enforced</span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Upload Date</th>
                            <th>Farmer Details</th>
                            <th>Document</th>
                            <th>Format</th>
                            <th>Status &amp; emSigner Approval</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($docs)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No documents uploaded yet.</td>
                            </tr>
                        <?php endif; ?>
                        <?php foreach($docs as $doc): ?>
                        <tr>
                            <td>
                                <span class="fw-semibold text-dark"><?= date('d M Y', strtotime($doc['uploaded_at'])) ?></span><br>
                                <small class="text-muted"><?= date('h:i A', strtotime($doc['uploaded_at'])) ?></small>
                            </td>
                            <td>
                                <strong class="text-primary"><?= htmlspecialchars($doc['name']) ?></strong><br>
                                <span class="badge bg-light text-secondary border font-monospace"><?= htmlspecialchars($doc['farmer_id'] ?: 'N/A') ?></span>
                            </td>
                            <td>
                                <div class="fw-bold"><?= htmlspecialchars($doc['document_name']) ?></div>
                                <small class="text-muted"><?= round($doc['file_size']/1024, 1) ?> KB</small>
                            </td>
                            <td>
                                <span class="badge bg-secondary-subtle text-dark border"><?= strtoupper(htmlspecialchars($doc['file_type'])) ?></span>
                            </td>
                            <td>
                                <?php if($doc['status'] === 'Approved and signed'): ?>
                                    <div>
                                        <span class="badge bg-success mb-1">
                                            <i class="bi bi-patch-check-fill me-1"></i>Approved and signed
                                        </span>
                                    </div>
                                    <small class="text-muted d-block">
                                        <i class="bi bi-pen me-1"></i>Signed by: <?= htmlspecialchars($doc['admin_reviewer_name'] ?? 'Admin') ?>
                                    </small>
                                    <small class="font-monospace text-muted d-block">
                                        Ref: <?= htmlspecialchars($doc['admin_signature_ref'] ?? 'N/A') ?>
                                    </small>
                                    <?php if(!empty($doc['admin_signed_at'])): ?>
                                        <small class="text-muted d-block">
                                            Date: <?= date('d M Y, h:i A', strtotime($doc['admin_signed_at'])) ?>
                                        </small>
                                    <?php endif; ?>
                                <?php elseif($doc['status'] === 'Reviewed'): ?>
                                    <span class="badge bg-info text-dark mb-1">Reviewed (Legacy)</span>
                                    <small class="text-muted d-block">Awaiting emSigner signature stamp</small>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark mb-1">
                                        <i class="bi bi-clock-history me-1"></i>Pending emSigner Approval
                                    </span>
                                    <small class="text-muted d-block">Uploaded – Not yet signed</small>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="../uploads/documents/<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-outline-primary" title="View Document File">
                                        <i class="bi bi-eye me-1"></i>View
                                    </a>

                                    <?php if($doc['status'] !== 'Approved and signed'): ?>
                                        <!-- Initiate emSigner API signing session for this document -->
                                        <button type="button"
                                            class="btn btn-outline-success fw-semibold btn-initiate-emsigner"
                                            data-action="admin_document_approval"
                                            data-doc-id="<?= $doc['id'] ?>"
                                            title="Create emSigner session & dispatch signing invitation email">
                                            <i class="bi bi-pen me-1"></i>Initiate emSigner Signing
                                        </button>

                                        <!-- Modal trigger to verify signing result -->
                                        <button type="button" class="btn btn-success fw-semibold" data-bs-toggle="modal" data-bs-target="#verifyDocModal<?= $doc['id'] ?>" title="Verify actual signing result from emSigner">
                                            <i class="bi bi-check2-circle me-1"></i>Verify Signing Result
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-outline-success disabled" disabled>
                                            <i class="bi bi-check-all me-1"></i>Verified
                                        </button>
                                    <?php endif; ?>
                                </div>

                                <!-- Verification Modal for this Document -->
                                <div class="modal fade text-start" id="verifyDocModal<?= $doc['id'] ?>" tabindex="-1" aria-labelledby="modalLabel<?= $doc['id'] ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST" action="/agristack_farmer_registry/api/verify_signing_result.php">
                                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                                <input type="hidden" name="action" value="admin_document_approval">
                                                <input type="hidden" name="document_id" value="<?= $doc['id'] ?>">

                                                <div class="modal-header bg-success text-white">
                                                    <h5 class="modal-title" id="modalLabel<?= $doc['id'] ?>">
                                                        <i class="bi bi-shield-check me-2"></i>Verify emSigner Approval Result
                                                    </h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="alert alert-light border small mb-3">
                                                        <strong>Document:</strong> <?= htmlspecialchars($doc['document_name']) ?><br>
                                                        <strong>Farmer:</strong> <?= htmlspecialchars($doc['name']) ?> (<?= htmlspecialchars($doc['farmer_id'] ?: 'N/A') ?>)<br>
                                                        <strong>Platform:</strong> <a href="https://demo.emsigner.com/" target="_blank">https://demo.emsigner.com/</a>
                                                    </div>

                                                    <p class="small text-muted mb-3">
                                                        Please confirm the actual digital signing result from emSigner. Opening emSigner alone does not approve the document. Mark “Approved and signed” only after the signing operation is completed.
                                                    </p>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-semibold">emSigner Reference / Certificate Serial</label>
                                                        <input type="text" name="provider_ref_id" class="form-control font-monospace" placeholder="e.g. EMUDHRA-DOC-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" value="EMUDHRA-DOC-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" required>
                                                        <small class="text-muted">Unique signing transaction identifier or certificate serial from emSigner.</small>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-semibold">Workflow / Envelope ID (Optional)</label>
                                                        <input type="text" name="workflow_id" class="form-control font-monospace" placeholder="WF-DOC-<?= $doc['id'] ?>-<?= time() ?>" value="WF-DOC-<?= $doc['id'] ?>-<?= time() ?>">
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label fw-semibold">Approval Remarks</label>
                                                        <textarea name="remarks" class="form-control" rows="2" placeholder="e.g. Land Patta verified against Revenue Records &amp; cryptographically approved.">Document verified and approved via emSigner.</textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer bg-light">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-success fw-bold">
                                                        <i class="bi bi-patch-check-fill me-1"></i>Verify &amp; Mark Approved and Signed
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
