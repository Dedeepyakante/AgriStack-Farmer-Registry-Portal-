<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $id = $_POST['ekyc_id'];
    $uid = $_POST['user_id'];
    $action = $_POST['action'];
    $remarks = $_POST['remarks'];
    
    // Rule 6: Keep demo results separate from genuine identity verification
    $chk = $pdo->prepare("SELECT verification_status FROM identity_verifications WHERE id = ?");
    $chk->execute([$id]);
    $rec = $chk->fetch();
    if ($rec && ($rec['verification_status'] === 'demo_completed')) {
        $message = "Demo e-KYC records cannot be verified as genuine Aadhaar identities.";
    } else {
        $status = $action === 'verify' ? 'Verified' : 'Rejected';
        $holder_status = $action === 'verify' ? 'Verified' : 'Rejected';
        $stmt = $pdo->prepare("UPDATE identity_verifications SET status=?, holder_check_status=?, admin_remarks=?, verified_at=NOW(), verified_by=? WHERE id=?");
        $stmt->execute([$status, $holder_status, $remarks, getUserId(), $id]);
        
        logAudit($pdo, getUserId(), 'admin', "eKYC $status", "eKYC ID $id marked as $status (Holder check $holder_status).");
        sendNotification($pdo, $uid, "eKYC Status Update", "Your eKYC document has been $status. Remarks: $remarks");
        
        $message = "eKYC marked as $status successfully.";
    }
}

$stmt = $pdo->query("SELECT v.*, u.name, u.farmer_id FROM identity_verifications v JOIN users u ON v.user_id = u.id WHERE v.status = 'Pending' AND (v.verification_status != 'demo_completed' OR v.verification_status IS NULL) ORDER BY v.id ASC");
$pending = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">eKYC Review</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($pending as $p): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-warning fw-bold d-flex justify-content-between align-items-center">
                        <span><?= htmlspecialchars($p['farmer_id']) ?> - <?= htmlspecialchars($p['name']) ?></span>
                        <span class="badge bg-dark"><?= htmlspecialchars($p['verification_status'] ?? 'Pending') ?></span>
                    </div>
                    <div class="card-body">
                        <p class="mb-1"><strong>Type:</strong> <?= htmlspecialchars($p['document_type']) ?></p>
                        <p class="mb-1"><strong>Submitted:</strong> <?= date('d M Y H:i', strtotime($p['submitted_at'])) ?></p>
                        <?php if(!empty($p['aadhaar_last4'])): ?>
                            <p class="mb-1 font-monospace"><strong>Aadhaar:</strong> XXXX-XXXX-<?= htmlspecialchars($p['aadhaar_last4']) ?></p>
                        <?php endif; ?>
                        <?php if(!empty($p['uidai_sig_status'])): ?>
                            <p class="mb-2"><strong>UIDAI Signature:</strong> <span class="badge bg-success-subtle text-success border"><?= htmlspecialchars($p['uidai_sig_status']) ?></span></p>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <?php if(!empty($p['document_path'])): ?>
                                <a href="../uploads/ekyc/<?= htmlspecialchars($p['document_path']) ?>" target="_blank" class="btn btn-sm btn-primary">View Full Document</a>
                            <?php else: ?>
                                <span class="badge bg-light text-dark border p-2"><i class="bi bi-shield-check text-success me-1"></i>In-Memory Verified (Raw Aadhaar Discarded)</span>
                            <?php endif; ?>
                            <?php if(!empty($p['extracted_photo_path'])): ?>
                                <button class="btn btn-sm btn-info" data-bs-toggle="collapse" data-bs-target="#photo-<?= $p['id'] ?>">Show Detected Photo</button>
                            <?php endif; ?>
                        </div>
                        
                        <?php if(!empty($p['extracted_photo_path'])): ?>
                        <div class="collapse mb-3" id="photo-<?= $p['id'] ?>">
                            <img src="../uploads/ekyc/<?= htmlspecialchars($p['extracted_photo_path']) ?>" class="img-thumbnail" style="max-height: 120px;">
                        </div>
                        <?php endif; ?>
                        
                        <form method="post" class="mt-3">
                            <input type="hidden" name="ekyc_id" value="<?= $p['id'] ?>">
                            <input type="hidden" name="user_id" value="<?= $p['user_id'] ?>">
                            <div class="mb-2">
                                <input type="text" name="remarks" class="form-control" placeholder="Admin remarks (Optional)">
                            </div>
                            <button type="submit" name="action" value="verify" class="btn btn-success"><i class="bi bi-check-lg"></i> Verify</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger"><i class="bi bi-x-lg"></i> Reject</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($pending)): ?>
                <div class="col-12"><div class="alert alert-info">No pending eKYC requests.</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
