<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ? AND u.role='farmer'");
$stmt->execute([$id]);
$farmer = $stmt->fetch();

if(!$farmer) die("Farmer not found.");
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Farmer Details</h2>
            <a href="farmers.php" class="btn btn-outline-secondary">Back</a>
        </div>
        
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="text-success border-bottom pb-2 mb-3">Basic Information</h5>
                <div class="row">
                    <div class="col-md-4 mb-2"><strong>Farmer ID:</strong> <?= htmlspecialchars($farmer['farmer_id']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Name:</strong> <?= htmlspecialchars($farmer['name']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Mobile:</strong> <?= htmlspecialchars($farmer['mobile']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Email:</strong> <?= htmlspecialchars($farmer['email']) ?></div>
                    <div class="col-md-4 mb-2"><strong>DOB:</strong> <?= htmlspecialchars($farmer['dob']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Gender:</strong> <?= htmlspecialchars($farmer['gender']) ?></div>
                    <div class="col-md-12 mt-2"><strong>Address:</strong> <?= htmlspecialchars($farmer['address'].', '.$farmer['district'].', '.$farmer['state']) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
