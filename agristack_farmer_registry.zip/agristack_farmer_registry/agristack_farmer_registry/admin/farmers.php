<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$search = trim($_GET['search'] ?? '');
$params = [];
$query = "SELECT u.id, u.farmer_id, u.name, u.email, u.mobile, p.state FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.role='farmer'";
if($search !== ''){
    $query .= " AND (u.name LIKE ? OR u.farmer_id LIKE ? OR u.email LIKE ? OR u.mobile LIKE ?)";
    $term = "%{$search}%";
    $params = [$term, $term, $term, $term];
}
$query .= " ORDER BY u.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$farmers = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Registered Farmers</h2>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="get" class="d-flex w-50">
                    <input type="text" name="search" class="form-control me-2" placeholder="Search Name, Farmer ID, Email or Mobile" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-outline-success">Search</button>
                    <?php if($search): ?>
                        <a href="farmers.php" class="btn btn-outline-secondary ms-2">Reset</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Farmer ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>State</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($farmers as $f): ?>
                    <tr>
                        <td class="fw-bold"><?= htmlspecialchars($f['farmer_id'] ?? '') ?></td>
                        <td><?= htmlspecialchars($f['name']) ?></td>
                        <td><?= htmlspecialchars($f['mobile']) ?></td>
                        <td><?= htmlspecialchars($f['email'] ?? 'Not Provided') ?></td>
                        <td><?= htmlspecialchars($f['state'] ?? '-') ?></td>
                        <td>
                            <a href="farmer-view.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-success"><i class="bi bi-eye"></i> View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
