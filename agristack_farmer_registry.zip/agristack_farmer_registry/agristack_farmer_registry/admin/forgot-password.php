<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/mailer.php';
require_once __DIR__ . '/../includes/functions.php';

$error = '';
$info = '';
$success = '';

// Determine current step (default: 1)
$step = $_SESSION['admin_reset_step'] ?? 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Action: Request OTP
    if (isset($_POST['send_otp'])) {
        $identity = trim($_POST['identity'] ?? '');
        if (empty($identity)) {
            $error = 'Please enter your registered Admin Email or Mobile number.';
        } else {
            $stmt = $pdo->prepare("SELECT id, name, email, mobile FROM users WHERE (email = ? OR mobile = ?) AND role = 'admin'");
            $stmt->execute([$identity, $identity]);
            $admin = $stmt->fetch();

            if ($admin) {
                // Generate 6-digit cryptographically random OTP
                $otp = str_pad((string)random_int(100000, 999999), 6, '0', STR_PAD_LEFT);

                $_SESSION['admin_reset_id']          = $admin['id'];
                $_SESSION['admin_reset_email']       = $admin['email'];
                $_SESSION['admin_reset_mobile']      = $admin['mobile'];
                $_SESSION['admin_reset_name']        = $admin['name'];
                $_SESSION['admin_reset_otp']         = $otp;
                $_SESSION['admin_reset_otp_expiry']  = time() + 900; // 15 minutes
                $_SESSION['admin_reset_step']        = 2;
                $step = 2;

                // Dispatch OTP externally (Email/SMS or Demo Outbox file)
                $target = !empty($admin['email']) ? $admin['email'] : $admin['mobile'];
                $deliveryType = !empty($admin['email']) ? 'email' : 'sms';
                $dispatch = sendOTPMessage($target, $otp, $deliveryType, $admin['name']);

                $info = $dispatch['message'];
            } else {
                $chkFarmer = $pdo->prepare("SELECT id, name FROM users WHERE (email = ? OR mobile = ?) AND role = 'farmer'");
                $chkFarmer->execute([$identity, $identity]);
                $isFarmer = $chkFarmer->fetch();

                if ($isFarmer) {
                    $error = 'This Email/Mobile is registered as a <strong>Farmer</strong> account. <br><a href="../forgot-password.php" class="alert-link">Click here for Farmer Password Reset</a> or <a href="register.php" class="alert-link">Register / Upgrade to Admin</a>.';
                } else {
                    $error = 'No administrator account found matching that Email or Mobile number. <br><a href="register.php" class="alert-link">Click here to Register as Admin</a>.';
                }
            }
        }
    }
    // Action: Verify OTP
    elseif (isset($_POST['verify_otp'])) {
        $inputOtp = trim($_POST['otp'] ?? '');
        
        if (!isset($_SESSION['admin_reset_id']) || !isset($_SESSION['admin_reset_otp'])) {
            $error = 'Reset session has expired. Please request a new OTP.';
            $step = 1;
            $_SESSION['admin_reset_step'] = 1;
        } elseif (time() > ($_SESSION['admin_reset_otp_expiry'] ?? 0)) {
            $error = 'The OTP has expired (valid for 15 minutes). Please request a new OTP.';
            unset($_SESSION['admin_reset_otp'], $_SESSION['admin_reset_otp_expiry']);
            $step = 1;
            $_SESSION['admin_reset_step'] = 1;
        } elseif ($inputOtp === $_SESSION['admin_reset_otp']) {
            $_SESSION['admin_reset_verified'] = true;
            $_SESSION['admin_reset_step']     = 3;
            $step = 3;
            $info = 'OTP verified successfully. Please enter your new password.';
        } else {
            $error = 'Invalid OTP entered. Please check and enter the correct 6-digit OTP.';
            $step = 2;
        }
    }
    // Action: Set New Password
    elseif (isset($_POST['reset_password'])) {
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (!isset($_SESSION['admin_reset_id']) || empty($_SESSION['admin_reset_verified'])) {
            $error = 'Unauthorized password reset attempt. Please verify OTP first.';
            $step = 1;
            $_SESSION['admin_reset_step'] = 1;
        } elseif (strlen($new_password) < 8) {
            $error = 'Password must be at least 8 characters long.';
            $step = 3;
        } elseif ($new_password !== $confirm_password) {
            $error = 'The passwords do not match. Please re-enter.';
            $step = 3;
        } else {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ? AND role = 'admin'");
            $stmt->execute([$hash, $_SESSION['admin_reset_id']]);

            logAudit($pdo, $_SESSION['admin_reset_id'], 'admin', 'Password Reset', 'Admin successfully reset password via OTP.');

            // Clear reset session
            unset(
                $_SESSION['admin_reset_id'],
                $_SESSION['admin_reset_email'],
                $_SESSION['admin_reset_mobile'],
                $_SESSION['admin_reset_name'],
                $_SESSION['admin_reset_otp'],
                $_SESSION['admin_reset_otp_expiry'],
                $_SESSION['admin_reset_verified'],
                $_SESSION['admin_reset_step']
            );

            $success = 'Your admin password has been reset successfully! You can now log in with your new password.';
            $step = 4; // Completed step
        }
    }
    // Action: Restart / Cancel
    elseif (isset($_POST['cancel_reset'])) {
        unset(
            $_SESSION['admin_reset_id'],
            $_SESSION['admin_reset_email'],
            $_SESSION['admin_reset_mobile'],
            $_SESSION['admin_reset_name'],
            $_SESSION['admin_reset_otp'],
            $_SESSION['admin_reset_otp_expiry'],
            $_SESSION['admin_reset_verified'],
            $_SESSION['admin_reset_step']
        );
        header("Location: login.php");
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white text-center py-3">
                    <div class="mb-1"><i class="bi bi-shield-lock fs-2"></i></div>
                    <h4 class="mb-0 fw-bold">Admin Password Reset</h4>
                    <small class="text-light opacity-75">Secure Multi-Factor Recovery</small>
                </div>
                <div class="card-body p-4">
                    <!-- Progress Indicator -->
                    <div class="d-flex justify-content-between text-center mb-4 pb-2 border-bottom">
                        <div class="<?= $step >= 1 ? 'text-dark fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 1 ? 'bg-dark' : 'bg-secondary' ?> rounded-pill mb-1">1</span><br>
                            <small>Request</small>
                        </div>
                        <div class="text-muted pt-1">&rarr;</div>
                        <div class="<?= $step >= 2 ? 'text-dark fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 2 ? 'bg-dark' : 'bg-secondary' ?> rounded-pill mb-1">2</span><br>
                            <small>Verify OTP</small>
                        </div>
                        <div class="text-muted pt-1">&rarr;</div>
                        <div class="<?= $step >= 3 ? 'text-dark fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 3 ? 'bg-dark' : 'bg-secondary' ?> rounded-pill mb-1">3</span><br>
                            <small>New Password</small>
                        </div>
                    </div>

                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($info)): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                            <i class="bi bi-info-circle-fill me-2"></i><?= htmlspecialchars($info) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success text-center py-4" role="alert">
                            <i class="bi bi-check-circle-fill fs-1 text-success d-block mb-2"></i>
                            <h5 class="alert-heading fw-bold">Success!</h5>
                            <p class="mb-3"><?= htmlspecialchars($success) ?></p>
                            <a href="login.php" class="btn btn-dark w-100 py-2 fw-semibold">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Go to Admin Login
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if($step === 1): ?>
                        <!-- Step 1: Request OTP -->
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Enter your registered Admin Email address or Mobile number. A secure 6-digit OTP will be dispatched to your registered address.
                            </p>
                            <div class="mb-3">
                                <label for="identity" class="form-label fw-semibold">Admin Email / Mobile</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                    <input type="text" id="identity" name="identity" class="form-control" placeholder="Enter Admin Email or Mobile" required autofocus>
                                </div>
                            </div>
                            <button type="submit" name="send_otp" class="btn btn-dark w-100 py-2 fw-semibold">
                                <i class="bi bi-send me-1"></i> Send Secure OTP
                            </button>
                        </form>

                    <?php elseif($step === 2): ?>
                        <!-- Step 2: Verify OTP -->
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Enter the 6-digit OTP code dispatched to your registered channel. (Valid for 15 minutes).
                            </p>
                            <div class="mb-3">
                                <label for="otp" class="form-label fw-semibold">Enter 6-Digit OTP</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-key-fill"></i></span>
                                    <input type="text" id="otp" name="otp" class="form-control font-monospace fs-5 text-center letter-spacing" maxlength="6" pattern="[0-9]{6}" placeholder="______" required autofocus>
                                </div>
                            </div>
                            <button type="submit" name="verify_otp" class="btn btn-dark w-100 py-2 fw-semibold mb-2">
                                <i class="bi bi-shield-check me-1"></i> Verify OTP
                            </button>
                        </form>
                        <form method="post" action="forgot-password.php" class="d-flex justify-content-between mt-2">
                            <button type="submit" name="send_otp" class="btn btn-link btn-sm text-decoration-none p-0 text-muted">
                                <i class="bi bi-arrow-clockwise me-1"></i>Resend OTP
                            </button>
                            <button type="submit" name="cancel_reset" class="btn btn-link btn-sm text-decoration-none p-0 text-danger">
                                Cancel & Restart
                            </button>
                        </form>

                    <?php elseif($step === 3): ?>
                        <!-- Step 3: Set New Password -->
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Please create a strong new password for your administrator account (minimum 8 characters).
                            </p>
                            <div class="mb-3">
                                <label for="new_password" class="form-label fw-semibold">New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock-fill"></i></span>
                                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" placeholder="Minimum 8 characters" required autofocus>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label fw-semibold">Confirm New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock-fill"></i></span>
                                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" placeholder="Re-type password" required>
                                </div>
                            </div>
                            <button type="submit" name="reset_password" class="btn btn-dark w-100 py-2 fw-semibold">
                                <i class="bi bi-check2-circle me-1"></i> Update Admin Password
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if($step !== 4): ?>
                        <div class="text-center mt-3 pt-2 border-top">
                            <a href="login.php" class="text-decoration-none small text-muted">
                                <i class="bi bi-arrow-left me-1"></i>Back to Admin Login
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="mt-3 pt-2 border-top">
                        <a href="../index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
