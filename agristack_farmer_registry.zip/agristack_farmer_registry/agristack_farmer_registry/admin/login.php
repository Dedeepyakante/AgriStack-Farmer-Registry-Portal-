<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/mailer.php';
require_once __DIR__ . '/../includes/functions.php';

// If already logged in, redirect to appropriate dashboard
if (isLoggedIn()) {
    if (getUserRole() === 'admin') {
        header("Location: dashboard.php");
        exit;
    } else {
        header("Location: ../farmer/dashboard.php");
        exit;
    }
}

$error   = '';
$info    = '';
$success = '';
$username_val = '';

// ── Determine which step we are on ───────────────────────────────────────────
// Step 1: credentials form  |  Step 2: OTP verification
$step = isset($_SESSION['admin_2fa_pending']) ? 2 : 1;

// ── STEP 1: Credentials + CAPTCHA ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $identity = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha  = $_POST['captcha'] ?? '';
    $username_val = $identity;

    if (empty($identity) || empty($password)) {
        $error = 'Please enter both your Email/Mobile and Password.';
    } elseif (!isset($_SESSION['admin_captcha_answer']) || $captcha === '' || (int)$captcha !== (int)$_SESSION['admin_captcha_answer']) {
        $error = 'Invalid CAPTCHA answer. Please solve the calculation again.';
    } else {
        // Look up admin by email or mobile
        $stmt = $pdo->prepare("SELECT * FROM users WHERE (email = ? OR mobile = ?) AND role = 'admin'");
        $stmt->execute([$identity, $identity]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if (isset($user['status']) && $user['status'] !== 'active') {
                $error = 'Your administrator account is inactive. Please contact system support.';
            } else {
                // ── Credentials valid → generate and dispatch 2FA OTP ──────────
                $otp    = str_pad((string)random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
                $expiry = time() + 600; // 10 minutes

                // Store pending 2FA data in session (NOT logged in yet)
                $_SESSION['admin_2fa_pending']     = true;
                $_SESSION['admin_2fa_user_id']     = $user['id'];
                $_SESSION['admin_2fa_otp']         = $otp;
                $_SESSION['admin_2fa_otp_expiry']  = $expiry;
                $_SESSION['admin_2fa_attempts']    = 0;
                $step = 2;

                // Determine delivery channel: email preferred, fall back to SMS
                $deliveredTo = '';
                if (!empty($user['email'])) {
                    $subject = "AgriStack Admin – 2FA Verification Code";
                    $body    = "Hello {$user['name']},\n\n"
                             . "Your Two-Factor Authentication code for the AgriStack Admin Portal is:\n\n"
                             . "  ➤  {$otp}\n\n"
                             . "This code is valid for 10 minutes. Do not share it with anyone.\n\n"
                             . "If you did not attempt to login, please change your password immediately.\n\n"
                             . "Regards,\nAgriStack Administration";
                    $dispatch = sendPortalEmail($user['email'], $subject, $body, $user['name']);
                    $deliveredTo = 'email (' . $user['email'] . ')';
                } elseif (!empty($user['mobile'])) {
                    $dispatch = sendOTPMessage($user['mobile'], $otp, 'sms', $user['name']);
                    $deliveredTo = 'mobile (' . $user['mobile'] . ')';
                } else {
                    // Edge case: admin has no contact info → fail gracefully
                    unset($_SESSION['admin_2fa_pending'], $_SESSION['admin_2fa_user_id'],
                          $_SESSION['admin_2fa_otp'], $_SESSION['admin_2fa_otp_expiry'], $_SESSION['admin_2fa_attempts']);
                    $error = 'Cannot send 2FA code: your admin account has no registered email or mobile. Please contact system support.';
                    $step  = 1;
                }

                if ($step === 2) {
                    logAudit($pdo, $user['id'], 'admin', '2FA OTP Sent', "2FA OTP dispatched to {$deliveredTo}.");
                    $info = "A 6-digit verification code has been sent to your registered {$deliveredTo}. Enter it below to complete login.";
                    if (isset($dispatch['mode']) && $dispatch['mode'] === 'demo') {
                        $info .= " <em class='text-muted'>(Demo mode: check <code>demo_email_outbox.txt</code> or <code>demo_sms_outbox.txt</code>.)</em>";
                    }
                }
            }
        } else {
            // Check if this identity belongs to a farmer account
            $chkFarmer = $pdo->prepare("SELECT id FROM users WHERE (email = ? OR mobile = ?) AND role = 'farmer'");
            $chkFarmer->execute([$identity, $identity]);
            if ($chkFarmer->fetch()) {
                $error = 'This account is registered as a <strong>Farmer</strong>, not an Admin. <br><a href="../login.php" class="alert-link">Click here for Farmer Login</a>.';
            } else {
                $error = 'Invalid Email/Mobile or Password. Please check your credentials or <a href="register.php" class="alert-link">Register New Admin</a>.';
            }
        }
    }
}

// ── STEP 2: OTP Verification ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_2fa'])) {
    $enteredOtp = trim($_POST['otp'] ?? '');

    if (!isset($_SESSION['admin_2fa_pending'])) {
        $error = 'Session expired. Please log in again.';
        $step  = 1;
    } elseif (time() > ($_SESSION['admin_2fa_otp_expiry'] ?? 0)) {
        $error = 'The verification code has expired (valid for 10 minutes). Please log in again.';
        unset($_SESSION['admin_2fa_pending'], $_SESSION['admin_2fa_user_id'],
              $_SESSION['admin_2fa_otp'], $_SESSION['admin_2fa_otp_expiry'], $_SESSION['admin_2fa_attempts']);
        $step = 1;
    } else {
        $_SESSION['admin_2fa_attempts'] = ($_SESSION['admin_2fa_attempts'] ?? 0) + 1;

        if ($_SESSION['admin_2fa_attempts'] > 5) {
            // Brute-force protection: invalidate session after 5 wrong attempts
            unset($_SESSION['admin_2fa_pending'], $_SESSION['admin_2fa_user_id'],
                  $_SESSION['admin_2fa_otp'], $_SESSION['admin_2fa_otp_expiry'], $_SESSION['admin_2fa_attempts']);
            $error = 'Too many incorrect attempts. Please log in again.';
            $step  = 1;
        } elseif ($enteredOtp === $_SESSION['admin_2fa_otp']) {
            // ── OTP correct → complete login ───────────────────────────────────
            $userId = $_SESSION['admin_2fa_user_id'];

            // Clear 2FA session data
            unset($_SESSION['admin_2fa_pending'], $_SESSION['admin_2fa_user_id'],
                  $_SESSION['admin_2fa_otp'], $_SESSION['admin_2fa_otp_expiry'], $_SESSION['admin_2fa_attempts']);

            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            if (!$user || $user['status'] !== 'active') {
                $error = 'Account verification failed. Please try again.';
                $step  = 1;
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['name']    = $user['name'];

                logAudit($pdo, $user['id'], 'admin', 'Login', 'Admin completed 2FA and logged in successfully.');

                header("Location: dashboard.php");
                exit;
            }
        } else {
            $remaining = 5 - $_SESSION['admin_2fa_attempts'];
            $error = "Incorrect verification code. {$remaining} attempt(s) remaining.";
        }
    }
}

// ── Cancel 2FA / restart ──────────────────────────────────────────────────────
if (isset($_POST['cancel_2fa'])) {
    unset($_SESSION['admin_2fa_pending'], $_SESSION['admin_2fa_user_id'],
          $_SESSION['admin_2fa_otp'], $_SESSION['admin_2fa_otp_expiry'], $_SESSION['admin_2fa_attempts']);
    header("Location: login.php");
    exit;
}

// ── Generate new CAPTCHA only on Step 1 ──────────────────────────────────────
if ($step === 1) {
    $num1 = rand(1, 10);
    $num2 = rand(1, 10);
    $_SESSION['admin_captcha_answer'] = $num1 + $num2;
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white text-center py-3">
                    <div class="mb-1">
                        <?php if ($step === 2): ?>
                            <i class="bi bi-shield-check fs-2 text-success"></i>
                        <?php else: ?>
                            <i class="bi bi-shield-lock-fill fs-2"></i>
                        <?php endif; ?>
                    </div>
                    <h4 class="mb-0 fw-bold">
                        <?= $step === 2 ? '2-Factor Verification' : 'Admin Portal Login' ?>
                    </h4>
                    <small class="text-light opacity-75">
                        <?= $step === 2 ? 'Enter the code sent to your registered contact' : 'AgriStack Farmer Registry Administrative Access' ?>
                    </small>
                </div>

                <?php if ($step === 2): ?>
                <!-- ── Step indicator ── -->
                <div class="bg-dark bg-opacity-10 border-bottom px-4 py-2">
                    <div class="d-flex align-items-center gap-2 small text-muted">
                        <span class="badge bg-success rounded-pill">1</span> Credentials verified
                        <i class="bi bi-arrow-right"></i>
                        <span class="badge bg-dark rounded-pill">2</span> <strong class="text-dark">2FA Verification</strong>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card-body p-4">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($info)): ?>
                        <div class="alert alert-info" role="alert">
                            <i class="bi bi-info-circle-fill me-2"></i><?= $info ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($step === 1): ?>
                    <!-- ═══════════════ STEP 1: Credentials ═══════════════ -->
                    <form method="post" action="login.php" novalidate>
                        <div class="mb-3">
                            <label for="username" class="form-label fw-semibold">Admin Email / Mobile</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-person"></i></span>
                                <input type="text" id="username" name="username" class="form-control"
                                       placeholder="admin@domain.com or Mobile"
                                       value="<?= htmlspecialchars($username_val) ?>" required autofocus>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label fw-semibold">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-key"></i></span>
                                <input type="password" id="password" name="password" class="form-control"
                                       placeholder="Enter your password" required>
                                <button type="button" class="btn btn-outline-secondary" id="togglePwd" tabindex="-1">
                                    <i class="bi bi-eye" id="togglePwdIcon"></i>
                                </button>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="captcha" class="form-label fw-semibold">Security Verification</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light font-monospace fw-bold text-dark"><?= $num1 ?> + <?= $num2 ?> = ?</span>
                                <input type="number" id="captcha" name="captcha" class="form-control"
                                       placeholder="Result" required>
                            </div>
                            <div class="form-text small">Enter the sum of the two numbers above.</div>
                        </div>

                        <button type="submit" name="admin_login" class="btn btn-dark w-100 py-2 fw-semibold">
                            <i class="bi bi-arrow-right-circle me-1"></i> Continue to Verification
                        </button>
                    </form>

                    <?php else: ?>
                    <!-- ═══════════════ STEP 2: OTP ═══════════════ -->
                    <p class="text-muted small mb-3">
                        A 6-digit verification code was sent to your registered email/mobile.
                        Enter it below. <strong>Valid for 10 minutes.</strong>
                    </p>

                    <form method="post" action="login.php" novalidate id="otpForm">
                        <div class="mb-4">
                            <label for="otp" class="form-label fw-semibold">Verification Code</label>
                            <input type="text" id="otp" name="otp"
                                   class="form-control form-control-lg font-monospace text-center fw-bold ls-5"
                                   maxlength="6" pattern="[0-9]{6}"
                                   placeholder="• • • • • •"
                                   autocomplete="one-time-code"
                                   inputmode="numeric"
                                   autofocus required
                                   style="letter-spacing:0.5em; font-size:1.8rem;">
                            <div class="form-text text-center small mt-1" id="otpTimer">
                                Code expires in <span id="countdown" class="fw-bold text-danger"></span>
                            </div>
                        </div>

                        <button type="submit" name="verify_2fa" class="btn btn-dark w-100 py-2 fw-semibold mb-2">
                            <i class="bi bi-shield-check me-1"></i> Verify & Login
                        </button>
                    </form>

                    <form method="post" action="login.php" class="text-center mt-1">
                        <button type="submit" name="cancel_2fa" class="btn btn-link btn-sm text-decoration-none text-danger p-0">
                            <i class="bi bi-x-circle me-1"></i>Cancel &amp; Start Over
                        </button>
                    </form>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                        <a href="forgot-password.php" class="text-decoration-none small text-danger fw-semibold">
                            <i class="bi bi-question-circle me-1"></i>Forgot Password?
                        </a>
                        <a href="register.php" class="text-decoration-none small text-dark fw-bold">
                            <i class="bi bi-person-plus-fill me-1"></i>Register New Admin
                        </a>
                    </div>
                    <div class="text-center mt-2">
                        <a href="../login.php" class="text-decoration-none small text-success fw-semibold">
                            <i class="bi bi-person-badge me-1"></i>Go to Farmer Login
                        </a>
                    </div>
                    <div class="mt-3 pt-2 border-top">
                        <a href="../index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>

                <div class="card-footer bg-light border-0 py-3 text-center">
                    <small class="text-muted">
                        <i class="bi bi-shield-lock-fill me-1"></i>
                        <?= $step === 2 ? '2-Factor Authentication Active &mdash; Secure Login' : 'Secure AgriStack Administrative Access Portal' ?>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ── Password show/hide toggle ─────────────────────────────────────────────────
const togglePwdBtn  = document.getElementById('togglePwd');
const togglePwdIcon = document.getElementById('togglePwdIcon');
const pwdInput      = document.getElementById('password');
if (togglePwdBtn) {
    togglePwdBtn.addEventListener('click', () => {
        const shown = pwdInput.type === 'text';
        pwdInput.type = shown ? 'password' : 'text';
        togglePwdIcon.className = shown ? 'bi bi-eye' : 'bi bi-eye-slash';
    });
}

// ── OTP auto-focus & numeric-only ────────────────────────────────────────────
const otpInput = document.getElementById('otp');
if (otpInput) {
    otpInput.addEventListener('input', function () {
        this.value = this.value.replace(/\D/g, '').slice(0, 6);
        if (this.value.length === 6) {
            document.getElementById('otpForm').querySelector('[name=verify_2fa]').focus();
        }
    });

    // ── 10-minute countdown timer ─────────────────────────────────────────────
    const countdownEl = document.getElementById('countdown');
    let remaining = 600; // seconds
    function tick() {
        if (remaining <= 0) {
            countdownEl.textContent = '00:00 — EXPIRED';
            return;
        }
        const m = String(Math.floor(remaining / 60)).padStart(2, '0');
        const s = String(remaining % 60).padStart(2, '0');
        countdownEl.textContent = m + ':' + s;
        remaining--;
        setTimeout(tick, 1000);
    }
    tick();
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
