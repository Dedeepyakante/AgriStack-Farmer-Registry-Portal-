<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
if (isset($_GET['mark_all'])) {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user_id]);
    header("Location: notifications.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100");
$stmt->execute([$user_id]);
$notifs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Admin Notifications</h2>
            <a href="?mark_all=1" class="btn btn-outline-success">Mark All as Read</a>
        </div>
        <div class="list-group shadow-sm border-0">
            <?php foreach($notifs as $n): ?>
                <div class="list-group-item <?= $n['is_read'] ? 'bg-light text-muted' : '' ?>">
                    <div class="d-flex justify-content-between">
                        <h6 class="<?= $n['is_read'] ? '' : 'fw-bold' ?>"><?= htmlspecialchars($n['title']) ?></h6>
                        <small><?= date('d M H:i', strtotime($n['created_at'])) ?></small>
                    </div>
                    <p class="mb-0"><?= htmlspecialchars($n['message']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
