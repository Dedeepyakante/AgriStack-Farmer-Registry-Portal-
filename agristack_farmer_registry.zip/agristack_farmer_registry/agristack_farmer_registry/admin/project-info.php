<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE student_details SET student_name=?, register_number=?, department=?, college_name=?, guide_name=?, team_members=?, academic_year=? WHERE id=1");
    $stmt->execute([$_POST['student_name'], $_POST['register_number'], $_POST['department'], $_POST['college_name'], $_POST['guide_name'], $_POST['team_members'], $_POST['academic_year']]);
    $message = "Project information updated successfully.";
}

$project = $pdo->query("SELECT * FROM student_details WHERE id=1")->fetch();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Academic Project Information</h2>
        <?php if($message): ?><div class="alert alert-success"><?= $message ?></div><?php endif; ?>
        
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label>Student Name</label><input type="text" name="student_name" class="form-control" value="<?= htmlspecialchars($project['student_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Register Number</label><input type="text" name="register_number" class="form-control" value="<?= htmlspecialchars($project['register_number']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Department</label><input type="text" name="department" class="form-control" value="<?= htmlspecialchars($project['department']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>College/University Name</label><input type="text" name="college_name" class="form-control" value="<?= htmlspecialchars($project['college_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Guide Name</label><input type="text" name="guide_name" class="form-control" value="<?= htmlspecialchars($project['guide_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Academic Year</label><input type="text" name="academic_year" class="form-control" value="<?= htmlspecialchars($project['academic_year']) ?>"></div>
                        <div class="col-12 mb-3"><label>Team Members</label><textarea name="team_members" class="form-control"><?= htmlspecialchars($project['team_members']) ?></textarea></div>
                    </div>
                    <button type="submit" class="btn btn-success">Save Information</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
