<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// If already logged in as admin, redirect to dashboard
if (isLoggedIn() && getUserRole() === 'admin') {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$success = '';

$name_val = '';
$email_val = '';
$mobile_val = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim($_POST['name'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $mobile    = trim($_POST['mobile'] ?? '');
    $password  = $_POST['password'] ?? '';
    $cpassword = $_POST['cpassword'] ?? '';
    $captcha   = $_POST['captcha'] ?? '';

    $name_val   = $name;
    $email_val  = $email;
    $mobile_val = $mobile;

    if (empty($name) || empty($email) || empty($mobile) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $error = 'Please enter a valid 10-digit mobile number.';
    } elseif (!isset($_SESSION['admin_reg_captcha']) || $captcha === '' || (int)$captcha !== (int)$_SESSION['admin_reg_captcha']) {
        $error = 'Invalid CAPTCHA solution. Please solve the calculation again.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } elseif ($password !== $cpassword) {
        $error = 'Passwords do not match. Please re-enter.';
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Check if an existing account with this email or mobile exists
        $stmt = $pdo->prepare("SELECT id, name, email, mobile, role FROM users WHERE email = ? OR mobile = ?");
        $stmt->execute([$email, $mobile]);
        $existing = $stmt->fetch();

        if ($existing) {
            if ($existing['role'] === 'admin') {
                $error = 'An Administrator account with this Email/Mobile already exists. Please <a href="login.php" class="alert-link">Login here</a> or use <a href="forgot-password.php" class="alert-link">Forgot Password</a>.';
            } else {
                // User previously registered as a farmer -> update/upgrade account to Administrator
                try {
                    $upd = $pdo->prepare("UPDATE users SET name = ?, email = ?, mobile = ?, password_hash = ?, role = 'admin', status = 'active' WHERE id = ?");
                    $upd->execute([$name, $email, $mobile, $passwordHash, $existing['id']]);

                    logAudit($pdo, $existing['id'], 'admin', 'Admin Registration', "Account for '{$name}' registered/upgraded to Administrator.");

                    $success = "Administrator account created successfully! You can now log in using your Email or Mobile number.";
                } catch (Exception $e) {
                    $error = 'Registration failed: ' . $e->getMessage();
                }
            }
        } else {
            // New admin registration
            try {
                $stmt = $pdo->prepare("INSERT INTO users (farmer_id, name, email, mobile, password_hash, role, status) VALUES (NULL, ?, ?, ?, ?, 'admin', 'active')");
                $stmt->execute([$name, $email, $mobile, $passwordHash]);
                $newAdminId = $pdo->lastInsertId();

                logAudit($pdo, $newAdminId, 'admin', 'Admin Registration', "New administrator '{$name}' registered successfully.");

                $success = "Administrator account created successfully! You can now log in using your registered Email or Mobile number.";
            } catch (Exception $e) {
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    }
}

// Generate security CAPTCHA
$num1 = rand(1, 10);
$num2 = rand(1, 10);
$_SESSION['admin_reg_captcha'] = $num1 + $num2;

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white text-center py-3">
                    <div class="mb-1"><i class="bi bi-person-plus-fill fs-2"></i></div>
                    <h4 class="mb-0 fw-bold">Admin Account Registration</h4>
                    <small class="text-light opacity-75">Create an Administrator Account for AgriStack Portal</small>
                </div>
                <div class="card-body p-4">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success text-center py-4" role="alert">
                            <i class="bi bi-check-circle-fill fs-1 text-success d-block mb-2"></i>
                            <h5 class="alert-heading fw-bold">Registration Successful!</h5>
                            <p class="mb-3"><?= htmlspecialchars($success) ?></p>
                            <a href="login.php" class="btn btn-dark w-100 py-2 fw-semibold">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Proceed to Admin Login
                            </a>
                        </div>
                    <?php else: ?>
                        <form method="post" action="register.php" novalidate>
                            <div class="mb-3">
                                <label for="name" class="form-label fw-semibold">Full Name *</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-person"></i></span>
                                    <input type="text" id="name" name="name" class="form-control" placeholder="e.g. Lakshmiprasanna" value="<?= htmlspecialchars($name_val) ?>" required autofocus>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label fw-semibold">Official Email Address *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="bi bi-envelope"></i></span>
                                        <input type="email" id="email" name="email" class="form-control" placeholder="admin@domain.com" value="<?= htmlspecialchars($email_val) ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="mobile" class="form-label fw-semibold">Mobile Number *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="bi bi-phone"></i></span>
                                        <input type="tel" id="mobile" name="mobile" class="form-control" placeholder="10-digit mobile" maxlength="10" pattern="[0-9]{10}" value="<?= htmlspecialchars($mobile_val) ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label fw-semibold">Password *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="bi bi-lock"></i></span>
                                        <input type="password" id="password" name="password" class="form-control" minlength="8" placeholder="Min 8 characters" required>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="cpassword" class="form-label fw-semibold">Confirm Password *</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light"><i class="bi bi-lock-fill"></i></span>
                                        <input type="password" id="cpassword" name="cpassword" class="form-control" minlength="8" placeholder="Re-type password" required>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="captcha" class="form-label fw-semibold">Security Verification *</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light font-monospace fw-bold text-dark"><?= $num1 ?> + <?= $num2 ?> = ?</span>
                                    <input type="number" id="captcha" name="captcha" class="form-control" placeholder="Result" required>
                                </div>
                                <div class="form-text small">Solve the simple arithmetic to verify you are human.</div>
                            </div>

                            <button type="submit" class="btn btn-dark w-100 py-2 fw-semibold">
                                <i class="bi bi-person-check-fill me-1"></i> Register as Administrator
                            </button>
                        </form>

                        <div class="d-flex justify-content-between align-items-center mt-4 pt-2 border-top">
                            <span class="text-muted small">Already have an admin account?</span>
                            <a href="login.php" class="text-decoration-none small text-dark fw-bold">
                                <i class="bi bi-box-arrow-in-right me-1"></i>Admin Login
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="mt-3 pt-2 border-top">
                        <a href="../index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
