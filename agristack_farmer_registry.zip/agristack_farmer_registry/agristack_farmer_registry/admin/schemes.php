<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_scheme'])) {
    $name = $_POST['scheme_name'];
    $desc = $_POST['description'];
    $elig = $_POST['eligibility'];
    $benf = $_POST['benefits'];
    $docs = $_POST['required_documents'];
    
    $stmt = $pdo->prepare("INSERT INTO schemes (scheme_name, description, eligibility, benefits, required_documents) VALUES (?,?,?,?,?)");
    $stmt->execute([$name, $desc, $elig, $benf, $docs]);
    
    logAudit($pdo, getUserId(), 'admin', 'Scheme Added', "Added scheme: $name");
    $message = "Scheme added successfully.";
}

$schemes = $pdo->query("SELECT * FROM schemes ORDER BY id DESC")->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Manage Schemes</h2>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addSchemeModal"><i class="bi bi-plus-circle"></i> Add Scheme</button>
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($schemes as $s): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-header bg-success text-white fw-bold">
                        <?= htmlspecialchars($s['scheme_name']) ?>
                        <span class="badge bg-light text-dark float-end"><?= $s['status'] ?></span>
                    </div>
                    <div class="card-body">
                        <p class="small mb-1"><strong>Desc:</strong> <?= htmlspecialchars($s['description']) ?></p>
                        <p class="small mb-1"><strong>Elig:</strong> <?= htmlspecialchars($s['eligibility']) ?></p>
                        <p class="small mb-0"><strong>Benf:</strong> <?= htmlspecialchars($s['benefits']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Add Scheme Modal -->
<div class="modal fade" id="addSchemeModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Add Demo Scheme</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="post">
      <div class="modal-body">
          <div class="mb-3"><label>Scheme Name</label><input type="text" name="scheme_name" class="form-control" required></div>
          <div class="mb-3"><label>Description</label><textarea name="description" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Eligibility</label><textarea name="eligibility" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Benefits</label><textarea name="benefits" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Required Documents</label><input type="text" name="required_documents" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="add_scheme" class="btn btn-success">Save Scheme</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
