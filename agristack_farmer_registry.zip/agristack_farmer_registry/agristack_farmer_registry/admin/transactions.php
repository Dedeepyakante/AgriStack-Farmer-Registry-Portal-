<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../config/csrf.php';
require_once '../config/esign.php';
require_once '../includes/esign_provider.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$adminUserId = getUserId();
$flash_success = $_SESSION['flash_success'] ?? null;
$flash_error   = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// Admin creates a new confirmed transaction for a farmer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_transaction'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrf)) {
        $_SESSION['flash_error'] = 'Invalid CSRF token. Please try again.';
        header("Location: transactions.php");
        exit;
    }

    $farmerId      = (int)($_POST['farmer_id'] ?? 0);
    $buyerName     = trim($_POST['buyer_name'] ?? '');
    $buyerContact  = trim($_POST['buyer_contact'] ?? '');
    $buyerEmail    = trim($_POST['buyer_email'] ?? '');
    $crop          = trim($_POST['crop'] ?? '');
    $quantity      = (float)($_POST['quantity'] ?? 0);
    $quantityUnit  = trim($_POST['quantity_unit'] ?? 'Quintals');
    $agreedPrice   = (float)($_POST['agreed_price'] ?? 0);
    $deliveryTerms = trim($_POST['delivery_terms'] ?? '');

    if ($farmerId <= 0 || empty($buyerName) || empty($crop) || $quantity <= 0 || $agreedPrice <= 0 || empty($deliveryTerms)) {
        $_SESSION['flash_error'] = 'Please select a farmer and fill in all transaction fields with valid quantities and prices.';
    } else {
        $txData = [
            'farmer_id'      => $farmerId,
            'buyer_name'     => $buyerName,
            'buyer_contact'  => $buyerContact,
            'buyer_email'    => $buyerEmail,
            'crop'           => $crop,
            'quantity'       => $quantity,
            'quantity_unit'  => $quantityUnit,
            'agreed_price'   => $agreedPrice,
            'delivery_terms' => $deliveryTerms
        ];
        try {
            $txId = createMarketTransaction($pdo, $txData, $adminUserId);
            $_SESSION['flash_success'] = "Transaction confirmed! Agreement Version 1 created & frozen for signing. Status: 'Awaiting signatures'.";
            header("Location: transactions.php");
            exit;
        } catch (Exception $e) {
            $_SESSION['flash_error'] = "Failed to create transaction: " . $e->getMessage();
        }
    }
}

// Admin modifies transaction terms -> Creates a NEW version and requires both parties to sign again
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modify_terms'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrf)) {
        $_SESSION['flash_error'] = 'Invalid CSRF token.';
        header("Location: transactions.php");
        exit;
    }

    $txId = (int)($_POST['transaction_id'] ?? 0);
    $newTerms = [
        'buyer_name'     => trim($_POST['buyer_name'] ?? ''),
        'buyer_contact'  => trim($_POST['buyer_contact'] ?? ''),
        'buyer_email'    => trim($_POST['buyer_email'] ?? ''),
        'crop'           => trim($_POST['crop'] ?? ''),
        'quantity'       => (float)($_POST['quantity'] ?? 0),
        'quantity_unit'  => trim($_POST['quantity_unit'] ?? 'Quintals'),
        'agreed_price'   => (float)($_POST['agreed_price'] ?? 0),
        'delivery_terms' => trim($_POST['delivery_terms'] ?? '')
    ];

    $result = modifyTransactionTerms($pdo, $txId, $newTerms, $adminUserId);
    if ($result['success']) {
        $_SESSION['flash_success'] = $result['message'];
    } else {
        $_SESSION['flash_error'] = $result['error'];
    }
    header("Location: transactions.php");
    exit;
}

// Retrieve farmers for modal dropdown
$farmers = $pdo->query("SELECT id, name, farmer_id, email, mobile FROM users WHERE role='farmer' ORDER BY name ASC")->fetchAll();

// Retrieve all market transactions
$transactions = getAllMarketTransactions($pdo);

// Statistics
$totalTx    = count($transactions);
$awaitingTx = 0;
$partialTx  = 0;
$fullyTx    = 0;

foreach ($transactions as $t) {
    $st = $t['active_agreement']['agreement_status'] ?? 'Awaiting signatures';
    if ($st === 'Fully signed') $fullyTx++;
    elseif ($st === 'Partially signed') $partialTx++;
    else $awaitingTx++;
}

$csrfToken = getCsrfToken();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="mb-1"><i class="bi bi-receipt text-success me-2"></i>Market Transactions &amp; emSigner Agreements</h2>
                <p class="text-muted mb-0">Multi-party transaction agreements, external emSigner workflows, and three-way signing audit</p>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-success fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#adminNewTxModal">
                    <i class="bi bi-plus-circle me-1"></i>New Transaction
                </button>
                <a href="https://demo.emsigner.com/" target="_blank" class="btn btn-outline-dark fw-semibold shadow-sm">
                    <i class="bi bi-box-arrow-up-right me-1"></i>Open emSigner
                </a>
            </div>
        </div>

        <?php if($flash_success): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($flash_error): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics Overview -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white">
                    <span class="text-muted small text-uppercase fw-semibold">Total Transactions</span>
                    <h3 class="fw-bold mb-0 text-dark"><?= $totalTx ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-warning border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Awaiting Signatures</span>
                    <h3 class="fw-bold mb-0 text-warning"><?= $awaitingTx ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-info border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Partially Signed</span>
                    <h3 class="fw-bold mb-0 text-info"><?= $partialTx ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 bg-white border-start border-success border-4">
                    <span class="text-muted small text-uppercase fw-semibold">Fully Signed</span>
                    <h3 class="fw-bold mb-0 text-success"><?= $fullyTx ?></h3>
                </div>
            </div>
        </div>

        <!-- 3-Way Signing Status Architecture Card -->
        <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #0b2545 0%, #134074 100%); color: #ffffff;">
            <div class="card-body p-4">
                <div class="d-flex align-items-start gap-3">
                    <span class="badge bg-white text-dark p-2 rounded-circle fs-3 flex-shrink-0">
                        <i class="bi bi-shield-check text-success"></i>
                    </span>
                    <div>
                        <h5 class="fw-bold mb-1">Three-Way Signing Status Tracking &amp; Versioning Rules</h5>
                        <p class="mb-2 opacity-90 small">
                            AgriLink rigorously tracks three separate signing actions through <strong>emSigner</strong> (<strong>https://demo.emsigner.com/</strong>):
                        </p>
                        <div class="row g-2 small mb-2">
                            <div class="col-md-4">
                                <div class="p-2 bg-white bg-opacity-10 rounded">
                                    <strong>1. Admin Document Approval:</strong> Verified cryptographic signature of farmer's uploaded records (Patta/KYC).
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-2 bg-white bg-opacity-10 rounded">
                                    <strong>2. Farmer Transaction Signature:</strong> Signed by farmer from their authenticated account (Admins cannot sign for farmer).
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="p-2 bg-white bg-opacity-10 rounded">
                                    <strong>3. Admin Transaction Signature:</strong> Signed by authorized admin for the same agreement version.
                                </div>
                            </div>
                        </div>
                        <div class="p-2 rounded bg-white bg-opacity-15 small">
                            <i class="bi bi-lock-fill text-warning me-1"></i>
                            <strong>Immutability &amp; Versioning:</strong> Confirmed agreements are <strong>frozen</strong> for signing. If terms change, a <strong>new version</strong> is generated and both parties must sign again. An agreement is marked <strong>“Fully signed”</strong> only after both signatures are verified for the same version.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions List -->
        <?php if(empty($transactions)): ?>
            <div class="card border-0 shadow-sm text-center p-5">
                <i class="bi bi-receipt fs-1 text-muted mb-3"></i>
                <h4 class="fw-bold text-dark">No Transactions Simulated Yet</h4>
                <p class="text-muted mb-3">Create a market transaction agreement between a registered farmer and an agribusiness buyer to initiate the 3-way emSigner workflow.</p>
                <div>
                    <button type="button" class="btn btn-success fw-bold px-4 py-2" data-bs-toggle="modal" data-bs-target="#adminNewTxModal">
                        <i class="bi bi-plus-lg me-1"></i> Create First Transaction
                    </button>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach($transactions as $tx): 
                    $agr = $tx['active_agreement'];
                    $docApp = $tx['doc_approval'];
                    
                    $isFarmerSigned = ($agr && $agr['farmer_signature_status'] === 'Signed');
                    $isAdminSigned  = ($agr && $agr['admin_signature_status'] === 'Signed');
                    $isFullySigned  = ($agr && $agr['agreement_status'] === 'Fully signed');
                    
                    $statusBadge = 'bg-warning text-dark';
                    if ($agr['agreement_status'] === 'Fully signed') $statusBadge = 'bg-success';
                    elseif ($agr['agreement_status'] === 'Partially signed') $statusBadge = 'bg-info text-dark';
                    elseif ($agr['agreement_status'] === 'Superseded') $statusBadge = 'bg-secondary';
                ?>
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <!-- Header -->
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2 border-bottom">
                            <div class="d-flex align-items-center gap-2 flex-wrap">
                                <span class="badge bg-primary-subtle text-primary font-monospace fs-6 px-3 py-2 border border-primary-subtle">
                                    <?= htmlspecialchars($tx['transaction_code']) ?>
                                </span>
                                <span class="badge bg-dark text-white px-2 py-1">
                                    <i class="bi bi-lock-fill me-1"></i>Version <?= $agr ? $agr['version'] : $tx['current_version'] ?> (Frozen for signing)
                                </span>
                                <span class="badge <?= $statusBadge ?> px-3 py-2 fs-6">
                                    <i class="bi <?= $isFullySigned ? 'bi-check-all' : 'bi-clock-history' ?> me-1"></i>
                                    <?= htmlspecialchars($agr['agreement_status'] ?? 'Awaiting signatures') ?>
                                </span>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <small class="text-muted">Created: <?= date('d M Y, h:i A', strtotime($tx['created_at'])) ?></small>
                                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editTermsModal<?= $tx['id'] ?>" title="Modify terms and create a new version requiring both parties to sign again">
                                    <i class="bi bi-pencil-square me-1"></i>Edit Terms (New Version)
                                </button>
                            </div>
                        </div>

                        <!-- Body: Parties & Terms -->
                        <div class="card-body p-4">
                            <div class="row g-3 mb-4">
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Farmer Details</small>
                                    <strong class="text-dark fs-6"><?= htmlspecialchars($tx['farmer_name']) ?></strong><br>
                                    <span class="badge bg-light text-secondary border font-monospace"><?= htmlspecialchars($tx['farmer_code'] ?: 'ID: ' . $tx['farmer_id']) ?></span>
                                    <?php if(!empty($tx['farmer_email'])): ?>
                                        <small class="text-muted d-block"><?= htmlspecialchars($tx['farmer_email']) ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Buyer Details</small>
                                    <strong class="text-dark fs-6"><?= htmlspecialchars($tx['buyer_name']) ?></strong>
                                    <?php if(!empty($tx['buyer_contact'])): ?>
                                        <small class="text-muted d-block"><?= htmlspecialchars($tx['buyer_contact']) ?></small>
                                    <?php endif; ?>
                                    <?php if(!empty($tx['buyer_email'])): ?>
                                        <small class="text-muted d-block"><?= htmlspecialchars($tx['buyer_email']) ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Crop &amp; Quantity</small>
                                    <strong class="text-dark fs-6"><?= htmlspecialchars($tx['crop']) ?></strong><br>
                                    <span class="text-dark"><?= number_format($tx['quantity'], 2) ?> <?= htmlspecialchars($tx['quantity_unit']) ?></span>
                                    <small class="text-muted d-block">@ ₹<?= number_format($tx['agreed_price'], 2) ?> / unit</small>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Total Value</small>
                                    <strong class="text-success fs-4">₹<?= number_format($tx['total_amount'], 2) ?></strong>
                                </div>
                            </div>

                            <!-- Delivery Terms -->
                            <div class="p-3 bg-light rounded mb-4 border">
                                <strong class="d-block mb-1 text-secondary small text-uppercase"><i class="bi bi-truck me-1"></i>Agreed Delivery &amp; Settlement Terms:</strong>
                                <p class="mb-0 text-dark small"><?= nl2br(htmlspecialchars($tx['delivery_terms'])) ?></p>
                            </div>

                            <!-- All THREE Signing Statuses Display (Strict User Requirement) -->
                            <h6 class="fw-bold text-dark text-uppercase small mb-3 border-bottom pb-2">
                                <i class="bi bi-patch-check-fill text-success me-1"></i>Three Separate Signing Statuses:
                            </h6>
                            <div class="row g-3 mb-3">
                                
                                <!-- Status 1: Admin Document Approval Signature -->
                                <div class="col-md-4">
                                    <div class="p-3 border rounded h-100 bg-white">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold small text-uppercase">1. Admin Document Approval</span>
                                            <span class="badge <?= $docApp['badge_class'] ?>">
                                                <?= htmlspecialchars($docApp['status']) ?>
                                            </span>
                                        </div>
                                        <p class="small text-muted mb-2">
                                            Verification &amp; emSigner signature for farmer's land patta/identity documents.
                                        </p>
                                        <?php if($docApp['is_approved']): ?>
                                            <div class="small text-success">
                                                <i class="bi bi-check-circle me-1"></i><?= htmlspecialchars($docApp['doc_name']) ?><br>
                                                <span class="font-monospace text-muted">Ref: <?= htmlspecialchars($docApp['ref_id']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted mb-2">
                                                <?= htmlspecialchars($docApp['details']) ?>
                                            </div>
                                            <a href="documents.php" class="btn btn-outline-primary btn-sm py-1">
                                                <i class="bi bi-box-arrow-up-right me-1"></i>Review in Document Repository
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Status 2: Farmer Transaction Signature -->
                                <div class="col-md-4">
                                    <div class="p-3 border rounded h-100 <?= $isFarmerSigned ? 'bg-success-subtle border-success-subtle' : 'bg-white' ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold small text-uppercase">2. Farmer Transaction Signature</span>
                                            <?php if($isFarmerSigned): ?>
                                                <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed in emSigner</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Awaiting Farmer</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="small text-muted mb-2">
                                            Signer: <strong><?= htmlspecialchars($tx['farmer_name']) ?></strong>
                                        </p>
                                        <?php if($isFarmerSigned): ?>
                                            <div class="small text-success">
                                                <i class="bi bi-check-circle me-1"></i>Signed on <?= date('d M Y, h:i A', strtotime($agr['farmer_signed_at'])) ?><br>
                                                <span class="font-monospace text-muted">Ref: <?= htmlspecialchars($agr['farmer_signature_ref']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted">
                                                <i class="bi bi-shield-lock me-1"></i>Farmer must perform their own signature from their authenticated account. Admin cannot sign on farmer’s behalf.
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Status 3: Admin Transaction Signature -->
                                <div class="col-md-4">
                                    <div class="p-3 border rounded h-100 <?= $isAdminSigned ? 'bg-success-subtle border-success-subtle' : 'bg-white' ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold small text-uppercase">3. Admin Transaction Signature</span>
                                            <?php if($isAdminSigned): ?>
                                                <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed in emSigner</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Awaiting Admin Signature</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="small text-muted mb-2">
                                            Signer: <strong>Administrator</strong> (AgriLink Official)
                                        </p>
                                        <?php if($isAdminSigned): ?>
                                            <div class="small text-success">
                                                <i class="bi bi-check-circle me-1"></i>Signed on <?= date('d M Y, h:i A', strtotime($agr['admin_signed_at'])) ?><br>
                                                <span class="font-monospace text-muted">Ref: <?= htmlspecialchars($agr['admin_signature_ref']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="d-flex flex-wrap gap-2 mt-2">
                                                <!-- Initiate emSigner API signing session for admin transaction -->
                                                <button type="button"
                                                    class="btn btn-success btn-sm fw-bold shadow-sm btn-initiate-emsigner"
                                                    data-action="admin_transaction"
                                                    data-agr-id="<?= $agr['id'] ?>"
                                                    title="Create emSigner session & dispatch signing invitation email">
                                                    <i class="bi bi-pen me-1"></i>Initiate emSigner Signing
                                                </button>
                                                <!-- Verify Signing Result -->
                                                <button type="button" class="btn btn-outline-success btn-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#verifyAdminTxModal<?= $agr['id'] ?>">
                                                    <i class="bi bi-check2-circle me-1"></i>Verify Signing Result
                                                </button>
                                            </div>
                                            <small class="text-muted d-block mt-2">
                                                Clicking <strong>Initiate emSigner Signing</strong> creates a live signing session via the emSigner API and dispatches an invitation email with the secure signing link.
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>

                            <!-- Footer & Hash -->
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 pt-2 border-top small text-muted">
                                <div>
                                    <i class="bi bi-fingerprint me-1"></i>Agreement Canonical Hash (SHA-256):
                                    <code class="text-secondary"><?= substr($agr['agreement_hash'] ?? '', 0, 28) ?>...</code>
                                </div>
                                <div>
                                    <?php if($isFullySigned): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1">
                                            <i class="bi bi-patch-check-fill me-1"></i>Fully signed for Version <?= $agr['version'] ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-dark border border-warning-subtle px-3 py-1">
                                            <i class="bi bi-hourglass-split me-1"></i>Awaiting signatures (Requires both signatures for v<?= $agr['version'] ?>)
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Verification Modal for Admin Transaction Signature -->
                        <?php if(!$isAdminSigned && $agr): ?>
                        <div class="modal fade text-start" id="verifyAdminTxModal<?= $agr['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="/agristack_farmer_registry/api/verify_signing_result.php">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="action" value="admin_transaction">
                                        <input type="hidden" name="agreement_id" value="<?= $agr['id'] ?>">

                                        <div class="modal-header bg-success text-white">
                                            <h5 class="modal-title"><i class="bi bi-patch-check me-2"></i>Verify Admin Signing Result (emSigner)</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-light border small mb-3">
                                                <strong>Transaction:</strong> <?= htmlspecialchars($tx['transaction_code']) ?> (Version <?= $agr['version'] ?>)<br>
                                                <strong>Farmer:</strong> <?= htmlspecialchars($tx['farmer_name']) ?><br>
                                                <strong>Buyer:</strong> <?= htmlspecialchars($tx['buyer_name']) ?><br>
                                                <strong>Platform:</strong> <a href="https://demo.emsigner.com/" target="_blank">https://demo.emsigner.com/</a>
                                            </div>

                                            <p class="small text-muted mb-3">
                                                Confirm the actual signing result from emSigner. Opening emSigner alone does not sign the agreement. Mark as signed only after the signing operation is completed.
                                            </p>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">emSigner Signing Reference</label>
                                                <input type="text" name="provider_ref_id" class="form-control font-monospace" placeholder="e.g. EMUDHRA-TX-ADMIN-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" value="EMUDHRA-TX-ADMIN-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">emSigner Workflow ID (Optional)</label>
                                                <input type="text" name="workflow_id" class="form-control font-monospace" placeholder="WF-TX-<?= $tx['transaction_code'] ?>-v<?= $agr['version'] ?>-ADMIN" value="WF-TX-<?= $tx['transaction_code'] ?>-v<?= $agr['version'] ?>-ADMIN">
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-success fw-bold">
                                                <i class="bi bi-patch-check-fill me-1"></i>Verify &amp; Confirm Admin Signature
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Modal: Modify Terms (Generates New Version & Requires Both Parties to Sign Again) -->
                        <div class="modal fade" id="editTermsModal<?= $tx['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <form method="POST" action="transactions.php">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="modify_terms" value="1">
                                        <input type="hidden" name="transaction_id" value="<?= $tx['id'] ?>">

                                        <div class="modal-header bg-dark text-white">
                                            <h5 class="modal-title">
                                                <i class="bi bi-arrow-repeat me-2 text-warning"></i>Modify Terms &bull; Create Version <?= ($agr ? $agr['version'] : $tx['current_version']) + 1 ?>
                                            </h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4">
                                            <div class="alert alert-warning small border mb-4">
                                                <i class="bi bi-exclamation-triangle-fill me-1"></i>
                                                <strong>Freeze &amp; Re-Signing Policy:</strong> Modifying agreement terms supersedes Version <?= $agr ? $agr['version'] : $tx['current_version'] ?> and creates <strong>Version <?= ($agr ? $agr['version'] : $tx['current_version']) + 1 ?></strong>.
                                                The new version is frozen for signing and resets both signatures to <strong>Pending (“Awaiting signatures”)</strong>. Both the farmer and admin must sign again through emSigner.
                                            </div>

                                            <div class="row g-3">
                                                <div class="col-md-6">
                                                    <label class="form-label fw-semibold">Buyer Name</label>
                                                    <input type="text" name="buyer_name" class="form-control" value="<?= htmlspecialchars($tx['buyer_name']) ?>" required>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label fw-semibold">Buyer Contact</label>
                                                    <input type="text" name="buyer_contact" class="form-control" value="<?= htmlspecialchars($tx['buyer_contact'] ?? '') ?>">
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label fw-semibold">Buyer Email</label>
                                                    <input type="email" name="buyer_email" class="form-control" value="<?= htmlspecialchars($tx['buyer_email'] ?? '') ?>">
                                                </div>

                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold">Crop</label>
                                                    <input type="text" name="crop" class="form-control" value="<?= htmlspecialchars($tx['crop']) ?>" required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold">Quantity</label>
                                                    <input type="number" step="0.01" min="0.01" name="quantity" class="form-control" value="<?= $tx['quantity'] ?>" required>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold">Unit</label>
                                                    <select name="quantity_unit" class="form-select">
                                                        <option value="Quintals" <?= $tx['quantity_unit']==='Quintals'?'selected':'' ?>>Quintals</option>
                                                        <option value="Metric Tons" <?= $tx['quantity_unit']==='Metric Tons'?'selected':'' ?>>Metric Tons</option>
                                                        <option value="Kg" <?= $tx['quantity_unit']==='Kg'?'selected':'' ?>>Kg</option>
                                                        <option value="Bags" <?= $tx['quantity_unit']==='Bags'?'selected':'' ?>>Bags</option>
                                                    </select>
                                                </div>

                                                <div class="col-md-6">
                                                    <label class="form-label fw-semibold">Agreed Price (₹ per unit)</label>
                                                    <input type="number" step="0.01" min="0.01" name="agreed_price" class="form-control" value="<?= $tx['agreed_price'] ?>" required>
                                                </div>

                                                <div class="col-12">
                                                    <label class="form-label fw-semibold">Delivery &amp; Settlement Terms</label>
                                                    <textarea name="delivery_terms" class="form-control" rows="3" required><?= htmlspecialchars($tx['delivery_terms']) ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-warning fw-bold text-dark">
                                                <i class="bi bi-arrow-repeat me-1"></i>Save Terms &amp; Create Version <?= ($agr ? $agr['version'] : $tx['current_version']) + 1 ?>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</div>

<!-- Modal: Admin Creates New Transaction -->
<div class="modal fade" id="adminNewTxModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="transactions.php">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="create_transaction" value="1">

                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="bi bi-receipt me-2"></i>Create &amp; Confirm New Transaction Agreement</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <p class="text-muted small mb-4">
                        Confirm transaction parameters between a registered farmer and an agribusiness buyer.
                        This will generate a <strong>frozen Agreement (Version 1)</strong> in <strong>“Awaiting signatures”</strong> status.
                    </p>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Select Farmer <span class="text-danger">*</span></label>
                            <select name="farmer_id" class="form-select" required>
                                <option value="">-- Choose Registered Farmer --</option>
                                <?php foreach($farmers as $f): ?>
                                    <option value="<?= $f['id'] ?>">
                                        <?= htmlspecialchars($f['name']) ?> (<?= htmlspecialchars($f['farmer_id'] ?: 'ID: ' . $f['id']) ?> - <?= htmlspecialchars($f['mobile']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Buyer / Agribusiness Name <span class="text-danger">*</span></label>
                            <input type="text" name="buyer_name" class="form-control" placeholder="e.g. AgriCorp Wholesale Ltd" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Buyer Contact</label>
                            <input type="text" name="buyer_contact" class="form-control" placeholder="e.g. 9812345678">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Buyer Email</label>
                            <input type="email" name="buyer_email" class="form-control" placeholder="procurement@agricorp.com">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Crop / Produce <span class="text-danger">*</span></label>
                            <input type="text" name="crop" class="form-control" placeholder="e.g. Cotton (Bt Medium Staple)" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Quantity <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.01" name="quantity" class="form-control" placeholder="e.g. 50.00" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Unit</label>
                            <select name="quantity_unit" class="form-select">
                                <option value="Quintals" selected>Quintals</option>
                                <option value="Metric Tons">Metric Tons</option>
                                <option value="Kg">Kilograms (Kg)</option>
                                <option value="Bags">Bags (50kg)</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Agreed Price (₹ per unit) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.01" name="agreed_price" class="form-control" placeholder="e.g. 7100.00" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Delivery &amp; Settlement Terms <span class="text-danger">*</span></label>
                            <textarea name="delivery_terms" class="form-control" rows="3" required>Farmgate inspection within 5 days of picking. Grade-A quality assurance. Full settlement via Direct Benefit Transfer within 3 business days.</textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success fw-bold">
                        <i class="bi bi-check2-circle me-1"></i>Confirm &amp; Freeze Agreement
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
