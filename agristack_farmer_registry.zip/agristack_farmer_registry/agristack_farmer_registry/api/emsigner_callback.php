<?php
/**
 * AgriLink / AgriStack Farmer Registry - emSigner Browser Return / Callback Handler
 * 
 * Handles return redirect from external emSigner signing platform:
 * 1. Reads reference number and signing action.
 * 2. Queries or verifies workflow status on the backend.
 * 3. Associates signature stamp with document, transaction, signer, and version.
 * 4. Sets user notification and redirects back to portal page.
 */

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/../includes/EmSignerClient.php';
require_once __DIR__ . '/../includes/esign_provider.php';

$refId   = trim($_GET['ref'] ?? $_POST['ref'] ?? $_GET['ReferenceNo'] ?? '');
$action  = trim($_GET['action'] ?? '');
$wfId    = (int)($_GET['WorkflowId'] ?? $_GET['WorkFlowId'] ?? 0);
$status  = strtolower(trim($_GET['status'] ?? $_GET['Status'] ?? ''));

$currentUserId = getUserId();
$currentUserRole = getUserRole();

if (empty($refId)) {
    $_SESSION['flash_error'] = 'Invalid emSigner callback: Missing reference number.';
    header('Location: /agristack_farmer_registry/');
    exit;
}

// Check workflow status from emSigner API if workflowId is provided
$verifiedViaApi = false;
if ($wfId > 0 && EmSignerClient::isConfigured()) {
    $info = EmSignerClient::getWorkflowInfo($wfId, $refId);
    if (!empty($info['success']) && !empty($info['data'])) {
        $wfStatus = strtolower($info['data']['WorkflowStatus'] ?? '');
        if (in_array($wfStatus, ['completed', 'signed', 'approved'])) {
            $verifiedViaApi = true;
        }
    }
}

// Fallback/direct verification based on reference type and action
if (str_starts_with($refId, 'DOC-') || $action === 'admin_document_approval') {
    $docId = (int)($_GET['doc_id'] ?? preg_replace('/\D/', '', explode('-', $refId)[1] ?? '0'));
    if ($docId > 0) {
        $adminId = ($currentUserRole === 'admin') ? $currentUserId : 1;
        $res = verifyDocumentApprovalSignature($pdo, $docId, $adminId, $refId, (string)$wfId, 'Verified via emSigner Callback');
        if ($res['success']) {
            $_SESSION['flash_success'] = 'Document digital signature verified successfully via emSigner!';
        } else {
            $_SESSION['flash_error'] = 'Signature verification failed: ' . ($res['error'] ?? 'Unknown error');
        }
    }
    header('Location: /agristack_farmer_registry/admin/documents.php');
    exit;
}

if (str_starts_with($refId, 'AGR-FARMER-') || $action === 'farmer_transaction') {
    $agrId = (int)($_GET['agr_id'] ?? 0);
    if ($agrId <= 0 && preg_match('/^AGR-FARMER-(\d+)-/', $refId, $m)) {
        $agrId = (int)$m[1];
    }
    if ($agrId > 0 && $currentUserId) {
        $res = verifyFarmerTransactionSignature($pdo, $agrId, $currentUserId, $refId, (string)$wfId);
        if ($res['success']) {
            $_SESSION['flash_success'] = 'Market agreement digitally signed and verified via emSigner!';
        } else {
            $_SESSION['flash_error'] = 'Verification failed: ' . ($res['error'] ?? 'Unknown error');
        }
    }
    header('Location: /agristack_farmer_registry/farmer/transactions.php');
    exit;
}

if (str_starts_with($refId, 'AGR-ADMIN-') || $action === 'admin_transaction') {
    $agrId = (int)($_GET['agr_id'] ?? 0);
    if ($agrId <= 0 && preg_match('/^AGR-ADMIN-(\d+)-/', $refId, $m)) {
        $agrId = (int)$m[1];
    }
    if ($agrId > 0) {
        $adminId = ($currentUserRole === 'admin') ? $currentUserId : 1;
        $res = verifyAdminTransactionSignature($pdo, $agrId, $adminId, $refId, (string)$wfId);
        if ($res['success']) {
            $_SESSION['flash_success'] = 'Trade agreement countersigned and verified via emSigner!';
        } else {
            $_SESSION['flash_error'] = 'Verification failed: ' . ($res['error'] ?? 'Unknown error');
        }
    }
    header('Location: /agristack_farmer_registry/admin/transactions.php');
    exit;
}

if (str_starts_with($refId, 'APP-') || $action === 'scheme_application') {
    $appId = $_GET['app_id'] ?? '';
    if (empty($appId) && preg_match('/^APP-([A-Z0-9]+)-/', $refId, $m)) {
        $appId = $m[1];
    }
    if (!empty($appId) && $currentUserId) {
        // Record verified provider signature for application
        $stampFile = generateEsignSvgStamp(
            $_SESSION['name'] ?? 'Farmer',
            $refId,
            date('d M Y, h:i A'),
            $refId,
            $_SESSION['email'] ?? 'farmer@agristack.gov.in',
            'DIGITALLY SIGNED VIA EMSIGNER'
        );
        $esignId = recordEsignature(
            $pdo,
            $currentUserId,
            $stampFile,
            'verified_provider',
            $appId,
            null,
            'emSigner',
            $refId,
            'Completed',
            json_encode(['workflow_id' => $wfId, 'callback' => true]),
            null,
            null,
            'scheme_application',
            (string)$wfId
        );
        $_SESSION['flash_success'] = "Application {$appId} has been digitally signed and verified via emSigner!";
    }
    header('Location: /agristack_farmer_registry/farmer/esign.php');
    exit;
}

$_SESSION['flash_success'] = 'emSigner signature operation processed.';
header('Location: /agristack_farmer_registry/');
exit;
