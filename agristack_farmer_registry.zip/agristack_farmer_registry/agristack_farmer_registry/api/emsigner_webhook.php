<?php
/**
 * AgriLink / AgriStack Farmer Registry - emSigner Webhook Receiver
 * 
 * Receives official webhook callbacks from emSigner:
 * https://demo.emsigner.com/ / https://demoapi.emsigner.com/
 * 
 * Verifies authenticity (HMAC SHA-256 header when secret configured)
 * and updates:
 * 1. Admin document approval signature
 * 2. Farmer transaction signature
 * 3. Admin transaction signature
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/../includes/esign_provider.php';

$rawBody = file_get_contents('php://input');

// Handle testing ping / empty body
if (empty($rawBody)) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Empty request payload. Expected JSON webhook from emSigner.'
    ]);
    exit;
}

// Security Check: Optional HMAC signature verification
$signatureHeader = $_SERVER['HTTP_X_EMSIGNER_SIGNATURE'] ?? $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? null;
if (!empty(ESIGN_WEBHOOK_SECRET) && $signatureHeader) {
    $expectedSignature = hash_hmac('sha256', $rawBody, ESIGN_WEBHOOK_SECRET);
    if (!hash_equals($expectedSignature, $signatureHeader)) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid webhook signature.']);
        exit;
    }
}

$payload = json_decode($rawBody, true);
if (!$payload) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload.']);
    exit;
}

// Log incoming webhook event in audit logs for transparency
$event = $payload['event'] ?? $payload['Event'] ?? 'DocumentSigned';
$refId = $payload['data']['ReferenceNumber'] ?? $payload['ReferenceNumber'] ?? $payload['ref'] ?? '';
$workflowId = $payload['data']['WorkflowId'] ?? $payload['WorkflowId'] ?? '';
$status = strtolower($payload['data']['Status'] ?? $payload['Status'] ?? 'completed');
$action = $payload['data']['Action'] ?? $payload['action'] ?? '';

// Only proceed on successful signing
if (!in_array($status, ['completed', 'signed', 'success'])) {
    echo json_encode([
        'status'  => 'ignored',
        'message' => "Webhook received for status '{$status}'; no signing action taken."
    ]);
    exit;
}

// Determine target based on action or reference prefix
if ($action === 'admin_document_approval' || str_starts_with($refId, 'DOC-') || isset($payload['data']['document_id'])) {
    $docId = (int)($payload['data']['document_id'] ?? preg_replace('/\D/', '', $refId));
    $adminId = (int)($payload['data']['admin_id'] ?? 1); // default admin fallback if not passed
    $result = verifyDocumentApprovalSignature($pdo, $docId, $adminId, $refId, $workflowId, 'Verified via emSigner Webhook');
} elseif ($action === 'farmer_transaction' || str_starts_with($refId, 'AGR-FARMER-') || isset($payload['data']['agreement_id_farmer'])) {
    $agreementId = (int)($payload['data']['agreement_id_farmer'] ?? $payload['data']['agreement_id'] ?? 0);
    $farmerId = (int)($payload['data']['farmer_id'] ?? 0);
    $result = verifyFarmerTransactionSignature($pdo, $agreementId, $farmerId, $refId, $workflowId);
} elseif ($action === 'admin_transaction' || str_starts_with($refId, 'AGR-ADMIN-') || isset($payload['data']['agreement_id_admin'])) {
    $agreementId = (int)($payload['data']['agreement_id_admin'] ?? $payload['data']['agreement_id'] ?? 0);
    $adminId = (int)($payload['data']['admin_id'] ?? 1);
    $result = verifyAdminTransactionSignature($pdo, $agreementId, $adminId, $refId, $workflowId);
} else {
    $result = ['success' => false, 'error' => 'Unrecognized emSigner webhook action or reference identifier.'];
}

if ($result['success']) {
    http_response_code(200);
    echo json_encode([
        'status'  => 'success',
        'message' => $result['message'],
        'details' => $result
    ]);
} else {
    http_response_code(422);
    echo json_encode([
        'status'  => 'error',
        'message' => $result['error']
    ]);
}
