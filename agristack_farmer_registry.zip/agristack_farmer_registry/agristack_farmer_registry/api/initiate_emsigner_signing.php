<?php
/**
 * AgriLink / AgriStack Farmer Registry - Initiate emSigner Session Endpoint
 * 
 * Initiates an official emSigner embedded signing session:
 * 1. Validates user session, role, and CSRF token.
 * 2. Prepares the document / agreement PDF.
 * 3. Calls official emSigner API (POST /api/InitiateEmbeddedSigning).
 * 4. Dispatches signing invitation email with session URL to signer's registered email.
 * 5. Returns signing session URL and redirects or responds to AJAX caller.
 * 
 * Rules:
 * - Credentials are kept strictly on server and NEVER returned to browser.
 * - Farmers must sign from their own authenticated account.
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/csrf.php';
require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/../includes/EmSignerClient.php';
require_once __DIR__ . '/../includes/esign_provider.php';

function jsonOut(bool $success, string $message, array $extra = []) {
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonOut(false, 'Method Not Allowed. POST required.');
}

if (!isLoggedIn()) {
    http_response_code(401);
    jsonOut(false, 'Authentication required.');
}

// Verify CSRF
$token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!verifyCsrfToken($token)) {
    http_response_code(403);
    jsonOut(false, 'Invalid or expired CSRF token.');
}

$action = trim($_POST['action'] ?? '');
$currentUserId = getUserId();
$currentUserRole = getUserRole();

// Determine base callback URL for redirect after signing
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
$baseUrl = "{$scheme}://{$host}/agristack_farmer_registry";

switch ($action) {

    // ========================================================================
    // 1. ADMIN DOCUMENT APPROVAL SIGNING
    // ========================================================================
    case 'admin_document_approval':
        if ($currentUserRole !== 'admin') {
            http_response_code(403);
            jsonOut(false, 'Access denied: Only administrators can initiate document approval signing.');
        }

        $docId = (int)($_POST['document_id'] ?? 0);
        if ($docId <= 0) {
            jsonOut(false, 'Invalid document identifier.');
        }

        $stmt = $pdo->prepare("SELECT d.*, u.name as farmer_name, u.email as farmer_email FROM documents d JOIN users u ON d.user_id = u.id WHERE d.id = ?");
        $stmt->execute([$docId]);
        $doc = $stmt->fetch();
        if (!$doc) {
            jsonOut(false, 'Document not found.');
        }

        // Get admin user info
        $adminStmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
        $adminStmt->execute([$currentUserId]);
        $admin = $adminStmt->fetch();
        $adminEmail = $admin['email'] ?? (!empty(SMTP_FROM_EMAIL) ? SMTP_FROM_EMAIL : 'admin@agristack.gov.in');
        $adminName  = $admin['name'] ?? 'Administrator';

        // Prepare PDF file
        $filePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'documents' . DIRECTORY_SEPARATOR . $doc['file_path'];
        $pdfBytes = '';
        if (file_exists($filePath) && strtolower(pathinfo($filePath, PATHINFO_EXTENSION)) === 'pdf') {
            $pdfBytes = file_get_contents($filePath);
        } else {
            // Generate valid agreement/approval wrapper PDF
            $pdfBytes = EmSignerClient::generateAgreementPdf("AgriStack Document Verification: " . $doc['document_name'], [
                "Document ID: " . $doc['id'],
                "Farmer Name: " . $doc['farmer_name'],
                "Farmer Email: " . ($doc['farmer_email'] ?: 'N/A'),
                "Original Filename: " . $doc['document_name'],
                "Reviewing Official: " . $adminName,
                "Verification Timestamp: " . date('d M Y, h:i A')
            ]);
        }

        $refNo = 'DOC-' . $doc['id'] . '-' . date('YmdHis');
        $callbackUrl = "{$baseUrl}/api/emsigner_callback.php?ref=" . urlencode($refNo) . '&action=admin_document_approval&doc_id=' . $docId;

        $session = EmSignerClient::initiateSigningSession([
            'reference_no'     => $refNo,
            'document_name'    => 'Doc_' . $doc['id'] . '_Verification.pdf',
            'file_data_base64' => base64_encode($pdfBytes),
            'signer_email'     => $adminEmail,
            'signer_name'      => $adminName,
            'initiator_name'   => 'AgriStack System',
            'initiator_email'  => $adminEmail,
            'redirect_url'     => $callbackUrl
        ]);

        if (!$session['success']) {
            jsonOut(false, 'emSigner Error: ' . $session['error']);
        }

        // Save workflow ID & reference in database
        $up = $pdo->prepare("UPDATE documents SET admin_emsigner_workflow_id = ?, admin_signature_ref = ? WHERE id = ?");
        $up->execute([$session['workflow_id'], $refNo, $docId]);

        // Send invitation email
        EmSignerClient::sendSigningInvitationEmail(
            $adminEmail,
            $adminName,
            $session['signing_url'],
            "Farmer Document: {$doc['document_name']} ({$doc['farmer_name']})",
            $refNo
        );

        jsonOut(true, 'emSigner signing session generated and invitation email dispatched.', [
            'signing_url'  => $session['signing_url'],
            'workflow_id'  => $session['workflow_id'],
            'reference_no' => $refNo
        ]);
        break;

    // ========================================================================
    // 2. FARMER TRANSACTION AGREEMENT SIGNING
    // ========================================================================
    case 'farmer_transaction':
        if ($currentUserRole !== 'farmer') {
            http_response_code(403);
            jsonOut(false, 'Access denied: Only the farmer can sign farmer transaction agreements.');
        }

        $agreementId = (int)($_POST['agreement_id'] ?? 0);
        if ($agreementId <= 0) {
            jsonOut(false, 'Invalid agreement identifier.');
        }

        $stmt = $pdo->prepare("SELECT a.*, t.transaction_code, u.name as farmer_name, u.email as farmer_email 
                               FROM transaction_agreements a 
                               JOIN transactions t ON a.transaction_id = t.id 
                               JOIN users u ON a.farmer_id = u.id 
                               WHERE a.id = ? AND a.farmer_id = ?");
        $stmt->execute([$agreementId, $currentUserId]);
        $agr = $stmt->fetch();
        if (!$agr) {
            jsonOut(false, 'Agreement record not found or not owned by authenticated farmer.');
        }

        $farmerEmail = $agr['farmer_email'];
        if (empty($farmerEmail)) {
            jsonOut(false, 'Your profile does not have a registered email address required by emSigner.');
        }

        // Generate agreement PDF
        $pdfBytes = EmSignerClient::generateAgreementPdf("Agricultural Trade Agreement: " . $agr['transaction_code'], [
            "Agreement Version: v" . $agr['version'],
            "Farmer Name: " . $agr['farmer_name'],
            "Buyer Name: " . $agr['buyer_name'],
            "Commodity / Crop: " . $agr['crop'],
            "Quantity: " . number_format((float)$agr['quantity'], 2) . " " . $agr['quantity_unit'],
            "Agreed Rate: Rs " . number_format((float)$agr['agreed_price'], 2) . " per unit",
            "Total Contract Value: Rs " . number_format((float)$agr['total_amount'], 2),
            "Delivery Terms: " . $agr['delivery_terms'],
            "Contract Hash (SHA-256): " . $agr['agreement_hash']
        ]);

        $refNo = 'AGR-FARMER-' . $agr['id'] . '-v' . $agr['version'] . '-' . date('YmdHis');
        $callbackUrl = "{$baseUrl}/api/emsigner_callback.php?ref=" . urlencode($refNo) . '&action=farmer_transaction&agr_id=' . $agreementId;

        $session = EmSignerClient::initiateSigningSession([
            'reference_no'     => $refNo,
            'document_name'    => 'Agreement_' . $agr['transaction_code'] . '_v' . $agr['version'] . '.pdf',
            'file_data_base64' => base64_encode($pdfBytes),
            'signer_email'     => $farmerEmail,
            'signer_name'      => $agr['farmer_name'],
            'initiator_name'   => 'AgriStack Agricultural Registry',
            'initiator_email'  => $farmerEmail,
            'redirect_url'     => $callbackUrl
        ]);

        if (!$session['success']) {
            jsonOut(false, 'emSigner Error: ' . $session['error']);
        }

        // Save workflow ID in agreement
        $up = $pdo->prepare("UPDATE transaction_agreements SET farmer_emsigner_workflow_id = ?, farmer_signature_ref = ? WHERE id = ?");
        $up->execute([$session['workflow_id'], $refNo, $agreementId]);

        // Send invitation email
        EmSignerClient::sendSigningInvitationEmail(
            $farmerEmail,
            $agr['farmer_name'],
            $session['signing_url'],
            "Agreement {$agr['transaction_code']} (v{$agr['version']})",
            $refNo
        );

        jsonOut(true, 'emSigner signing session generated and invitation email dispatched.', [
            'signing_url'  => $session['signing_url'],
            'workflow_id'  => $session['workflow_id'],
            'reference_no' => $refNo
        ]);
        break;

    // ========================================================================
    // 3. ADMIN TRANSACTION AGREEMENT SIGNING
    // ========================================================================
    case 'admin_transaction':
        if ($currentUserRole !== 'admin') {
            http_response_code(403);
            jsonOut(false, 'Access denied: Only administrators can countersign transactions.');
        }

        $agreementId = (int)($_POST['agreement_id'] ?? 0);
        if ($agreementId <= 0) {
            jsonOut(false, 'Invalid agreement identifier.');
        }

        $stmt = $pdo->prepare("SELECT a.*, t.transaction_code, u.name as farmer_name 
                               FROM transaction_agreements a 
                               JOIN transactions t ON a.transaction_id = t.id 
                               JOIN users u ON a.farmer_id = u.id 
                               WHERE a.id = ?");
        $stmt->execute([$agreementId]);
        $agr = $stmt->fetch();
        if (!$agr) {
            jsonOut(false, 'Agreement record not found.');
        }

        $adminStmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
        $adminStmt->execute([$currentUserId]);
        $admin = $adminStmt->fetch();
        $adminEmail = $admin['email'] ?? (!empty(SMTP_FROM_EMAIL) ? SMTP_FROM_EMAIL : 'admin@agristack.gov.in');
        $adminName  = $admin['name'] ?? 'Administrator';

        $pdfBytes = EmSignerClient::generateAgreementPdf("Agricultural Trade Agreement (Admin Counter-Signature): " . $agr['transaction_code'], [
            "Agreement Version: v" . $agr['version'],
            "Farmer: " . $agr['farmer_name'],
            "Buyer: " . $agr['buyer_name'],
            "Crop: " . $agr['crop'],
            "Quantity: " . number_format((float)$agr['quantity'], 2) . " " . $agr['quantity_unit'],
            "Contract Value: Rs " . number_format((float)$agr['total_amount'], 2),
            "Counter-Signing Admin: " . $adminName,
            "Verification Timestamp: " . date('d M Y, h:i A')
        ]);

        $refNo = 'AGR-ADMIN-' . $agr['id'] . '-v' . $agr['version'] . '-' . date('YmdHis');
        $callbackUrl = "{$baseUrl}/api/emsigner_callback.php?ref=" . urlencode($refNo) . '&action=admin_transaction&agr_id=' . $agreementId;

        $session = EmSignerClient::initiateSigningSession([
            'reference_no'     => $refNo,
            'document_name'    => 'Agreement_' . $agr['transaction_code'] . '_Admin_v' . $agr['version'] . '.pdf',
            'file_data_base64' => base64_encode($pdfBytes),
            'signer_email'     => $adminEmail,
            'signer_name'      => $adminName,
            'initiator_name'   => 'AgriStack System',
            'initiator_email'  => $adminEmail,
            'redirect_url'     => $callbackUrl
        ]);

        if (!$session['success']) {
            jsonOut(false, 'emSigner Error: ' . $session['error']);
        }

        $up = $pdo->prepare("UPDATE transaction_agreements SET admin_emsigner_workflow_id = ?, admin_signature_ref = ? WHERE id = ?");
        $up->execute([$session['workflow_id'], $refNo, $agreementId]);

        EmSignerClient::sendSigningInvitationEmail(
            $adminEmail,
            $adminName,
            $session['signing_url'],
            "Agreement Counter-Signature {$agr['transaction_code']} (v{$agr['version']})",
            $refNo
        );

        jsonOut(true, 'emSigner signing session generated and invitation email dispatched.', [
            'signing_url'  => $session['signing_url'],
            'workflow_id'  => $session['workflow_id'],
            'reference_no' => $refNo
        ]);
        break;

    // ========================================================================
    // 4. SCHEME APPLICATION SIGNING
    // ========================================================================
    case 'scheme_application':
        if ($currentUserRole !== 'farmer') {
            http_response_code(403);
            jsonOut(false, 'Access denied: Only the applicant farmer can sign scheme applications.');
        }

        $appId = trim($_POST['application_id'] ?? '');
        if (empty($appId)) {
            jsonOut(false, 'Invalid application identifier.');
        }

        $stmt = $pdo->prepare("SELECT a.*, s.scheme_name, u.name as farmer_name, u.email as farmer_email, u.farmer_id 
                               FROM scheme_applications a 
                               JOIN schemes s ON a.scheme_id = s.id 
                               JOIN users u ON a.user_id = u.id 
                               WHERE a.application_id = ? AND a.user_id = ?");
        $stmt->execute([$appId, $currentUserId]);
        $app = $stmt->fetch();
        if (!$app) {
            jsonOut(false, 'Application record not found or not owned by user.');
        }

        $farmerEmail = $app['farmer_email'];
        if (empty($farmerEmail)) {
            jsonOut(false, 'Your profile does not have an email address required for emSigner.');
        }

        $pdfBytes = EmSignerClient::generateAgreementPdf("Agricultural Scheme Application: " . $app['scheme_name'], [
            "Application ID: " . $app['application_id'],
            "Scheme Name: " . $app['scheme_name'],
            "Applicant Name: " . $app['farmer_name'],
            "Farmer ID: " . $app['farmer_id'],
            "Submission Date: " . date('d M Y, h:i A', strtotime($app['applied_at'])),
            "Status: " . $app['status']
        ]);

        $refNo = 'APP-' . $app['application_id'] . '-' . date('YmdHis');
        $callbackUrl = "{$baseUrl}/api/emsigner_callback.php?ref=" . urlencode($refNo) . '&action=scheme_application&app_id=' . urlencode($appId);

        $session = EmSignerClient::initiateSigningSession([
            'reference_no'     => $refNo,
            'document_name'    => 'Application_' . $app['application_id'] . '.pdf',
            'file_data_base64' => base64_encode($pdfBytes),
            'signer_email'     => $farmerEmail,
            'signer_name'      => $app['farmer_name'],
            'initiator_name'   => 'AgriStack Scheme Management',
            'initiator_email'  => $farmerEmail,
            'redirect_url'     => $callbackUrl
        ]);

        if (!$session['success']) {
            jsonOut(false, 'emSigner Error: ' . $session['error']);
        }

        EmSignerClient::sendSigningInvitationEmail(
            $farmerEmail,
            $app['farmer_name'],
            $session['signing_url'],
            "Scheme Application [{$app['application_id']}] {$app['scheme_name']}",
            $refNo
        );

        jsonOut(true, 'emSigner signing session generated and invitation email dispatched.', [
            'signing_url'  => $session['signing_url'],
            'workflow_id'  => $session['workflow_id'],
            'reference_no' => $refNo
        ]);
        break;

    default:
        jsonOut(false, 'Unrecognized signing action.');
        break;
}
