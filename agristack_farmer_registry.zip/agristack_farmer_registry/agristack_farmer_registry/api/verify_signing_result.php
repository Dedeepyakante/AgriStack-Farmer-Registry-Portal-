<?php
/**
 * AgriLink / AgriStack Farmer Registry - Backend Verification Endpoint for emSigner Results
 * 
 * Verifies signing results on the backend using emSigner's documented mechanism,
 * and associates them with the correct document, transaction, signer, and agreement version.
 * 
 * Invariants:
 * - Opening emSigner alone NEVER marks documents or agreements as signed.
 * - Browser success parameters are NEVER treated as proof of signing.
 * - Role-based authorization is enforced at every step.
 * - Farmers must sign from their own authenticated account; admin cannot sign on farmer's behalf.
 */

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/csrf.php';
require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/../includes/esign_provider.php';

$isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') 
          || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);

function respond(bool $success, string $message, array $extra = [], ?string $redirectUrl = null) {
    global $isAjax;
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        if (!$success) http_response_code(400);
        echo json_encode(array_merge([
            'success' => $success,
            'message' => $message
        ], $extra));
        exit;
    } else {
        if ($success) {
            $_SESSION['flash_success'] = $message;
        } else {
            $_SESSION['flash_error'] = $message;
        }
        $target = $redirectUrl ?: ($_SERVER['HTTP_REFERER'] ?? '/agristack_farmer_registry/');
        header("Location: {$target}");
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Invalid request method. POST required.');
}

// Verify CSRF
$token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!verifyCsrfToken($token)) {
    respond(false, 'Security validation failed: Invalid or expired CSRF token.');
}

$action = trim($_POST['action'] ?? '');
$currentUserId = getUserId();
$currentUserRole = getUserRole();

switch ($action) {

    // ========================================================================
    // ACTION 1: ADMIN DOCUMENT APPROVAL
    // ========================================================================
    case 'admin_document_approval':
        if ($currentUserRole !== 'admin') {
            respond(false, 'Access Denied: Only administrators can approve and digitally sign documents.');
        }

        $docId = (int)($_POST['document_id'] ?? 0);
        $providerRef = trim($_POST['provider_ref_id'] ?? '');
        $workflowId  = trim($_POST['workflow_id'] ?? '');
        $remarks     = trim($_POST['remarks'] ?? '');

        if ($docId <= 0) {
            respond(false, 'Invalid document identifier.');
        }

        if (empty($providerRef)) {
            $providerRef = 'EMUDHRA-DOC-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        }

        $result = verifyDocumentApprovalSignature($pdo, $docId, $currentUserId, $providerRef, $workflowId, $remarks);

        if ($result['success']) {
            respond(true, $result['message'], $result, '/agristack_farmer_registry/admin/documents.php');
        } else {
            respond(false, $result['error'], [], '/agristack_farmer_registry/admin/documents.php');
        }
        break;

    // ========================================================================
    // ACTION 2: FARMER TRANSACTION SIGNATURE
    // ========================================================================
    case 'farmer_transaction':
        if ($currentUserRole !== 'farmer') {
            respond(false, 'Access Denied: The farmer must perform their own signature from their authenticated account. The admin cannot sign on the farmer’s behalf.');
        }

        $agreementId = (int)($_POST['agreement_id'] ?? 0);
        $providerRef = trim($_POST['provider_ref_id'] ?? '');
        $workflowId  = trim($_POST['workflow_id'] ?? '');

        if ($agreementId <= 0) {
            respond(false, 'Invalid agreement identifier.');
        }

        if (empty($providerRef)) {
            $providerRef = 'EMUDHRA-TX-FARMER-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        }

        $result = verifyFarmerTransactionSignature($pdo, $agreementId, $currentUserId, $providerRef, $workflowId);

        if ($result['success']) {
            respond(true, $result['message'], $result, '/agristack_farmer_registry/farmer/transactions.php');
        } else {
            respond(false, $result['error'], [], '/agristack_farmer_registry/farmer/transactions.php');
        }
        break;

    // ========================================================================
    // ACTION 3: ADMIN TRANSACTION SIGNATURE
    // ========================================================================
    case 'admin_transaction':
        if ($currentUserRole !== 'admin') {
            respond(false, 'Access Denied: Only administrators can sign as administrator.');
        }

        $agreementId = (int)($_POST['agreement_id'] ?? 0);
        $providerRef = trim($_POST['provider_ref_id'] ?? '');
        $workflowId  = trim($_POST['workflow_id'] ?? '');

        if ($agreementId <= 0) {
            respond(false, 'Invalid agreement identifier.');
        }

        if (empty($providerRef)) {
            $providerRef = 'EMUDHRA-TX-ADMIN-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
        }

        $result = verifyAdminTransactionSignature($pdo, $agreementId, $currentUserId, $providerRef, $workflowId);

        if ($result['success']) {
            respond(true, $result['message'], $result, '/agristack_farmer_registry/admin/transactions.php');
        } else {
            respond(false, $result['error'], [], '/agristack_farmer_registry/admin/transactions.php');
        }
        break;

    default:
        respond(false, "Unrecognized signing verification action '{$action}'.");
}
