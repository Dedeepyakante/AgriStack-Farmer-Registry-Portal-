/**
 * AgriLink / AgriStack Farmer Registry - emSigner Portal Integration JS
 * 
 * Handles client-side initiation of authentic emSigner signing sessions:
 * 1. Contacts backend API (/api/initiate_emsigner_signing.php) with CSRF protection.
 * 2. Receives genuine provider signing URL & workflow ID.
 * 3. Pre-fills verification modal with authentic provider reference and workflow ID.
 * 4. Dispatches invitation email confirmation and opens genuine emSigner interface.
 */

document.addEventListener('DOMContentLoaded', function() {
    function getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        if (meta && meta.content) return meta.content;
        const input = document.querySelector('input[name="csrf_token"]');
        if (input && input.value) return input.value;
        return '';
    }

    function showToast(message, type = 'success') {
        const toastEl = document.createElement('div');
        toastEl.className = `alert alert-${type} shadow-lg position-fixed top-0 end-0 m-4`;
        toastEl.style.zIndex = '99999';
        toastEl.style.maxWidth = '450px';
        toastEl.innerHTML = `
            <div class="d-flex align-items-center justify-content-between gap-2">
                <div><i class="bi bi-shield-check me-2 fs-5"></i><strong>emSigner:</strong> ${message}</div>
                <button type="button" class="btn-close" aria-label="Close"></button>
            </div>
        `;
        document.body.appendChild(toastEl);
        toastEl.querySelector('.btn-close').addEventListener('click', () => toastEl.remove());
        setTimeout(() => { if (toastEl.parentNode) toastEl.remove(); }, 8000);
    }

    document.querySelectorAll('.btn-initiate-emsigner').forEach(btn => {
        btn.addEventListener('click', async function(e) {
            e.preventDefault();

            const action = this.getAttribute('data-action') || '';
            const docId  = this.getAttribute('data-doc-id') || '';
            const agrId  = this.getAttribute('data-agr-id') || '';
            const appId  = this.getAttribute('data-app-id') || '';

            const originalHtml = this.innerHTML;
            this.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Launching emSigner...';
            this.classList.add('disabled');

            const formData = new FormData();
            formData.append('csrf_token', getCsrfToken());
            formData.append('action', action);
            if (docId) formData.append('document_id', docId);
            if (agrId) formData.append('agreement_id', agrId);
            if (appId) formData.append('application_id', appId);

            try {
                const response = await fetch('/agristack_farmer_registry/api/initiate_emsigner_signing.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });

                const data = await response.json();

                if (data.success && data.signing_url) {
                    showToast('Signing session created successfully! An invitation email with the secure signing link has been dispatched to your email.', 'success');

                    // Pre-fill corresponding modal if present
                    if (docId) {
                        const modal = document.querySelector(`#verifyDocModal${docId}`);
                        if (modal) {
                            const refInput = modal.querySelector('input[name="provider_ref_id"]');
                            if (refInput) refInput.value = data.reference_no;
                            const wfInput = modal.querySelector('input[name="workflow_id"]');
                            if (wfInput) wfInput.value = data.workflow_id;
                        }
                    } else if (agrId) {
                        const modalFarmer = document.querySelector(`#verifyFarmerTxModal${agrId}`);
                        if (modalFarmer) {
                            const refInput = modalFarmer.querySelector('input[name="provider_ref_id"]');
                            if (refInput) refInput.value = data.reference_no;
                            const wfInput = modalFarmer.querySelector('input[name="workflow_id"]');
                            if (wfInput) wfInput.value = data.workflow_id;
                        }
                        const modalAdmin = document.querySelector(`#verifyAdminTxModal${agrId}`);
                        if (modalAdmin) {
                            const refInput = modalAdmin.querySelector('input[name="provider_ref_id"]');
                            if (refInput) refInput.value = data.reference_no;
                            const wfInput = modalAdmin.querySelector('input[name="workflow_id"]');
                            if (wfInput) wfInput.value = data.workflow_id;
                        }
                    }

                    // Open genuine emSigner signing session in new window
                    window.open(data.signing_url, '_blank');
                } else {
                    const errMsg = data.message || 'Could not connect to emSigner API gateway.';
                    showToast(`${errMsg} Falling back to standard platform navigation.`, 'warning');
                    window.open('https://demo.emsigner.com/', '_blank');
                }
            } catch (err) {
                console.error('emSigner initiation error:', err);
                showToast('Unable to reach emSigner gateway. Opening external platform directly.', 'info');
                window.open('https://demo.emsigner.com/', '_blank');
            } finally {
                this.innerHTML = originalHtml;
                this.classList.remove('disabled');
            }
        });
    });
});
