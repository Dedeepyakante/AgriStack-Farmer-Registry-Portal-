﻿document.addEventListener('DOMContentLoaded', function() {
    // Basic frontend interactions
});
