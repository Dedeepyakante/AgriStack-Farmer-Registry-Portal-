<?php
/**
 * Google OAuth 2.0 Callback Handler
 * AgriStack Farmer Registry Portal
 */
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/google.php';
require_once __DIR__ . '/../includes/functions.php';

// ── Security: validate state to prevent CSRF ──────────────────────────────────
$returnedState = $_GET['state'] ?? '';
$storedState   = $_SESSION['google_oauth_state'] ?? '';

if (empty($returnedState) || $returnedState !== $storedState) {
    $_SESSION['login_error'] = 'Invalid OAuth state. Please try logging in again.';
    header('Location: ../login.php');
    exit;
}
unset($_SESSION['google_oauth_state']);

// ── Handle OAuth errors from Google ──────────────────────────────────────────
if (isset($_GET['error'])) {
    $errDesc = htmlspecialchars($_GET['error_description'] ?? $_GET['error']);
    $_SESSION['login_error'] = 'Google Sign-In was cancelled or failed: ' . $errDesc;
    header('Location: ../login.php');
    exit;
}

// ── Exchange authorization code for access token ──────────────────────────────
$code = $_GET['code'] ?? '';
if (empty($code)) {
    $_SESSION['login_error'] = 'No authorization code received from Google.';
    header('Location: ../login.php');
    exit;
}

$tokenResponse = file_get_contents(GOOGLE_TOKEN_URL, false, stream_context_create([
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query([
            'code'          => $code,
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
        ]),
        'ignore_errors' => true,
    ]
]));

if ($tokenResponse === false) {
    $_SESSION['login_error'] = 'Failed to contact Google servers. Please try again.';
    header('Location: ../login.php');
    exit;
}

$tokenData = json_decode($tokenResponse, true);
if (empty($tokenData['access_token'])) {
    $errMsg = $tokenData['error_description'] ?? $tokenData['error'] ?? 'Unknown error';
    $_SESSION['login_error'] = 'Google token exchange failed: ' . htmlspecialchars($errMsg);
    header('Location: ../login.php');
    exit;
}

// ── Fetch user profile from Google ───────────────────────────────────────────
$userInfoResponse = file_get_contents(GOOGLE_USERINFO_URL, false, stream_context_create([
    'http' => [
        'method' => 'GET',
        'header' => 'Authorization: Bearer ' . $tokenData['access_token'] . "\r\n",
        'ignore_errors' => true,
    ]
]));

if ($userInfoResponse === false) {
    $_SESSION['login_error'] = 'Failed to retrieve Google profile information.';
    header('Location: ../login.php');
    exit;
}

$googleUser = json_decode($userInfoResponse, true);
$googleId    = $googleUser['sub']   ?? '';
$googleEmail = $googleUser['email'] ?? '';
$googleName  = $googleUser['name']  ?? '';

if (empty($googleId) || empty($googleEmail)) {
    $_SESSION['login_error'] = 'Google did not return your email address. Please grant email permission and try again.';
    header('Location: ../login.php');
    exit;
}

// ── Look up existing farmer by google_id or email ────────────────────────────
// First check if 'google_id' column exists in users table, add if not
try {
    $pdo->query("SELECT google_id FROM users LIMIT 1");
} catch (PDOException $e) {
    // Column doesn't exist — add it
    $pdo->exec("ALTER TABLE users ADD COLUMN google_id VARCHAR(100) DEFAULT NULL AFTER email");
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE (google_id = ? OR email = ?) AND role = 'farmer'");
$stmt->execute([$googleId, $googleEmail]);
$user = $stmt->fetch();

if ($user) {
    // ── Existing farmer: update google_id if not set, then log in ────────────
    if (empty($user['google_id'])) {
        $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?")->execute([$googleId, $user['id']]);
    }

    if (isset($user['status']) && $user['status'] !== 'active') {
        $_SESSION['login_error'] = 'Your account is inactive. Please contact support.';
        header('Location: ../login.php');
        exit;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role']    = $user['role'];
    $_SESSION['name']    = $user['name'];

    logAudit($pdo, $user['id'], 'farmer', 'Google SSO Login', 'Farmer logged in via Google OAuth.');

    header('Location: ../farmer/dashboard.php');
    exit;

} else {
    // ── New Google user: check if there's an admin with same email ────────────
    $adminCheck = $pdo->prepare("SELECT id FROM users WHERE email = ? AND role = 'admin'");
    $adminCheck->execute([$googleEmail]);
    if ($adminCheck->fetch()) {
        $_SESSION['login_error'] = 'This Google account (' . htmlspecialchars($googleEmail) . ') is registered as an Administrator. <a href="admin/login.php" class="alert-link">Admin Login</a>';
        header('Location: ../login.php');
        exit;
    }

    // ── Auto-register new farmer via Google SSO ───────────────────────────────
    $farmerId = generateFarmerId($pdo);
    $dummyHash = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT); // random, cannot be used for login

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            "INSERT INTO users (farmer_id, name, email, mobile, password_hash, role, google_id, status)
             VALUES (?, ?, ?, '', ?, 'farmer', ?, 'active')"
        );
        $stmt->execute([$farmerId, $googleName, $googleEmail, $dummyHash, $googleId]);
        $newUserId = $pdo->lastInsertId();

        $pdo->prepare(
            "INSERT INTO farmer_profiles (user_id, dob, gender, address, district, state) VALUES (?, NULL, NULL, '', '', '')"
        )->execute([$newUserId]);

        logAudit($pdo, $newUserId, 'farmer', 'Google SSO Registration', "Auto-registered via Google: $googleEmail (Farmer ID: $farmerId)");

        $pdo->commit();

        session_regenerate_id(true);
        $_SESSION['user_id'] = $newUserId;
        $_SESSION['role']    = 'farmer';
        $_SESSION['name']    = $googleName;

        // Flag so dashboard can prompt the farmer to complete their profile
        $_SESSION['google_new_registration'] = true;
        $_SESSION['farmer_id_assigned']      = $farmerId;

        header('Location: ../farmer/dashboard.php');
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['login_error'] = 'Google Sign-In failed during account creation. Please try again. (' . htmlspecialchars($e->getMessage()) . ')';
        header('Location: ../login.php');
        exit;
    }
}
