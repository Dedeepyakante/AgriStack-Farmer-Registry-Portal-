<?php
$base_dir = "C:\\xampp\\htdocs\\agristack_farmer_registry";

$files = [];

$files["database.sql"] = <<<SQL
-- phpMyAdmin SQL Dump
-- Database: agristack_farmer_registry
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_id` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(15) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('farmer','admin') NOT NULL DEFAULT 'farmer',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `farmer_id` (`farmer_id`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `farmer_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `address` text DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `profile_completed` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_farmer_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `identity_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `document_type` varchar(50) NOT NULL,
  `document_path` varchar(255) NOT NULL,
  `extracted_photo_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Verified','Rejected') NOT NULL DEFAULT 'Pending',
  `admin_remarks` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified_at` timestamp NULL DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_identity_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `farms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `farm_name` varchar(100) NOT NULL,
  `survey_number` varchar(50) NOT NULL,
  `village` varchar(100) NOT NULL,
  `mandal` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `land_area` decimal(10,2) NOT NULL,
  `land_unit` enum('Acres','Hectares') NOT NULL,
  `ownership_type` enum('Owned','Leased') NOT NULL,
  `crop_type` varchar(100) DEFAULT NULL,
  `irrigation_type` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_farms_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `document_name` varchar(100) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_size` int(11) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Uploaded','Reviewed') NOT NULL DEFAULT 'Uploaded',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_docs_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `schemes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `eligibility` text NOT NULL,
  `benefits` text NOT NULL,
  `required_documents` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `scheme_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_id` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `scheme_id` int(11) NOT NULL,
  `farm_id` int(11) DEFAULT NULL,
  `status` enum('Draft','Submitted','Under Review','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  `admin_remarks` text DEFAULT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `application_id` (`application_id`),
  KEY `user_id` (`user_id`),
  KEY `scheme_id` (`scheme_id`),
  CONSTRAINT `fk_app_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_app_schemes` FOREIGN KEY (`scheme_id`) REFERENCES `schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `esignatures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `signature_path` varchar(255) NOT NULL,
  `signed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_esign_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `dbt_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(20) NOT NULL,
  `application_id` varchar(20) NOT NULL,
  `farmer_id` varchar(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Success','Failed') NOT NULL DEFAULT 'Pending',
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `fk_notif_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `student_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(100) NOT NULL DEFAULT '[ENTER STUDENT NAME]',
  `register_number` varchar(50) NOT NULL DEFAULT '[ENTER REGISTER NUMBER]',
  `department` varchar(100) NOT NULL DEFAULT 'CSE – Artificial Intelligence and Machine Learning',
  `college_name` varchar(150) NOT NULL DEFAULT '[ENTER COLLEGE NAME]',
  `guide_name` varchar(100) NOT NULL DEFAULT '[ENTER GUIDE NAME]',
  `team_members` text NOT NULL DEFAULT '[ENTER TEAM MEMBERS]',
  `academic_year` varchar(10) NOT NULL DEFAULT '2026',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Data
INSERT INTO `users` (`farmer_id`, `name`, `email`, `mobile`, `password_hash`, `role`) VALUES
(NULL, 'Demo Admin', 'admin@agristack-demo.local', '9999999999', '$2y$10\$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'admin'),
('AGRIF20260001', 'Demo Farmer', 'farmer@agristack-demo.local', '8888888888', '$2y$10\$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'farmer');

INSERT INTO `farmer_profiles` (`user_id`, `dob`, `gender`, `address`, `district`, `state`, `profile_completed`) VALUES
(2, '1985-05-15', 'Male', '123 Farm Road', 'Demo District', 'Demo State', 1);

INSERT INTO `student_details` (`id`) VALUES (1);

INSERT INTO `schemes` (`scheme_name`, `description`, `eligibility`, `benefits`, `required_documents`) VALUES
('Farmer Support Scheme', 'Financial assistance to farmers for agricultural activities.', 'All registered farmers with verified eKYC.', 'Demo ₹5000 support per acre.', 'Identity Document, Land Records'),
('Crop Insurance Assistance', 'Insurance coverage for crop failure.', 'Farmers with at least 1 registered farm.', 'Varies by crop.', 'Farm Registration, Identity Document');

COMMIT;
SQL;

$files["config/database.php"] = <<<PHP
<?php
\$host = 'localhost';
\$db   = 'agristack_farmer_registry';
\$user = 'root';
\$pass = '';
\$charset = 'utf8mb4';

\$dsn = "mysql:host=\$host;dbname=\$db;charset=\$charset";
\$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     \$pdo = new PDO(\$dsn, \$user, \$pass, \$options);
} catch (\PDOException \$e) {
     throw new \PDOException(\$e->getMessage(), (int)\$e->getCode());
}
?>
PHP;

$files["config/auth.php"] = <<<PHP
<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset(\$_SESSION['user_id']);
}

function getUserId() {
    return \$_SESSION['user_id'] ?? null;
}

function getUserRole() {
    return \$_SESSION['role'] ?? null;
}

function requireAuth() {
    if (!isLoggedIn()) {
        header("Location: /agristack_farmer_registry/login.php");
        exit;
    }
}

function requireRole(\$role) {
    requireAuth();
    if (getUserRole() !== \$role) {
        die("Unauthorized access. You are not authorized to access this page.");
    }
}
?>
PHP;

$files["config/csrf.php"] = <<<PHP
<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty(\$_SESSION['csrf_token'])) {
    \$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function getCsrfToken() {
    return \$_SESSION['csrf_token'];
}

function verifyCsrfToken(\$token) {
    return hash_equals(\$_SESSION['csrf_token'], \$token);
}
?>
PHP;

$files["includes/functions.php"] = <<<PHP
<?php
function sanitizeInput(\$data) {
    return htmlspecialchars(strip_tags(trim(\$data)));
}

function generateFarmerId(\$pdo) {
    \$year = date('Y');
    \$stmt = \$pdo->query("SELECT COUNT(*) FROM users WHERE role='farmer'");
    \$count = \$stmt->fetchColumn() + 1;
    return "AGRIF" . \$year . str_pad(\$count, 4, '0', STR_PAD_LEFT);
}

function generateApplicationId(\$pdo) {
    \$year = date('Y');
    \$stmt = \$pdo->query("SELECT COUNT(*) FROM scheme_applications");
    \$count = \$stmt->fetchColumn() + 1;
    return "APP" . \$year . str_pad(\$count, 5, '0', STR_PAD_LEFT);
}

function generateTransactionId(\$pdo) {
    \$year = date('Y');
    \$stmt = \$pdo->query("SELECT COUNT(*) FROM dbt_transactions");
    \$count = \$stmt->fetchColumn() + 1;
    return "DBT" . \$year . str_pad(\$count, 5, '0', STR_PAD_LEFT);
}

function logAudit(\$pdo, \$user_id, \$role, \$action, \$description) {
    \$ip = \$_SERVER['REMOTE_ADDR'] ?? null;
    \$stmt = \$pdo->prepare("INSERT INTO audit_logs (user_id, role, action, description, ip_address) VALUES (?, ?, ?, ?, ?)");
    \$stmt->execute([\$user_id, \$role, \$action, \$description, \$ip]);
}

function sendNotification(\$pdo, \$user_id, \$title, \$message) {
    \$stmt = \$pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    \$stmt->execute([\$user_id, \$title, \$message]);
}

function getUnreadNotificationsCount(\$pdo, \$user_id) {
    \$stmt = \$pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    \$stmt->execute([\$user_id]);
    return \$stmt->fetchColumn();
}
?>
PHP;

$files["assets/css/style.css"] = <<<CSS
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
}
.sidebar {
    min-height: 100vh;
    background-color: #198754;
    color: white;
}
.sidebar a {
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    padding: 10px 15px;
    display: block;
    border-radius: 5px;
    margin-bottom: 5px;
}
.sidebar a:hover, .sidebar a.active {
    background-color: rgba(255,255,255,0.2);
    color: white;
}
.dashboard-card {
    border-left: 4px solid #198754;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
}
.topbar {
    background-color: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.disclaimer-banner {
    background-color: #ffc107;
    color: #000;
    text-align: center;
    padding: 5px;
    font-size: 0.9em;
    font-weight: bold;
}
CSS;

$files["assets/js/main.js"] = <<<JS
document.addEventListener('DOMContentLoaded', function() {
    // Basic frontend interactions can go here
});
JS;

foreach (\$files as \$path => \$content) {
    \$full_path = \$base_dir . '/' . \$path;
    \$dir = dirname(\$full_path);
    if (!is_dir(\$dir)) {
        mkdir(\$dir, 0777, true);
    }
    file_put_contents(\$full_path, \$content);
}

echo "Files created successfully.";
?>
