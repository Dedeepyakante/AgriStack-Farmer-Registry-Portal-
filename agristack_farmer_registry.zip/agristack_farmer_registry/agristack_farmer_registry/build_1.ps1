$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "config/database.php" = @'
<?php
$host = 'localhost';
$db   = 'agristack_farmer_registry';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>
'@

    "config/auth.php" = @'
<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function requireAuth() {
    if (!isLoggedIn()) {
        header("Location: /agristack_farmer_registry/login.php");
        exit;
    }
}

function requireRole($role) {
    requireAuth();
    if (getUserRole() !== $role) {
        die("Unauthorized access. You are not authorized to access this page.");
    }
}
?>
'@

    "config/csrf.php" = @'
<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function getCsrfToken() {
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    return hash_equals($_SESSION['csrf_token'], $token);
}
?>
'@

    "includes/functions.php" = @'
<?php
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateFarmerId($pdo) {
    $year = date('Y');
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role='farmer'");
    $count = $stmt->fetchColumn() + 1;
    return "AGRIF" . $year . str_pad($count, 4, '0', STR_PAD_LEFT);
}

function generateApplicationId($pdo) {
    $year = date('Y');
    $stmt = $pdo->query("SELECT COUNT(*) FROM scheme_applications");
    $count = $stmt->fetchColumn() + 1;
    return "APP" . $year . str_pad($count, 5, '0', STR_PAD_LEFT);
}

function generateTransactionId($pdo) {
    $year = date('Y');
    $stmt = $pdo->query("SELECT COUNT(*) FROM dbt_transactions");
    $count = $stmt->fetchColumn() + 1;
    return "DBT" . $year . str_pad($count, 5, '0', STR_PAD_LEFT);
}

function logAudit($pdo, $user_id, $role, $action, $description) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, role, action, description, ip_address) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $role, $action, $description, $ip]);
}

function sendNotification($pdo, $user_id, $title, $message) {
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $title, $message]);
}

function getUnreadNotificationsCount($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn();
}
?>
'@

    "assets/css/style.css" = @'
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
}
.sidebar {
    min-height: 100vh;
    background-color: #198754;
    color: white;
}
.sidebar a {
    color: rgba(255,255,255,0.8);
    text-decoration: none;
    padding: 10px 15px;
    display: block;
    border-radius: 5px;
    margin-bottom: 5px;
}
.sidebar a:hover, .sidebar a.active {
    background-color: rgba(255,255,255,0.2);
    color: white;
}
.dashboard-card {
    border-left: 4px solid #198754;
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
}
.topbar {
    background-color: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.disclaimer-banner {
    background-color: #ffc107;
    color: #000;
    text-align: center;
    padding: 5px;
    font-size: 0.9em;
    font-weight: bold;
}
'@

    "assets/js/main.js" = @'
document.addEventListener('DOMContentLoaded', function() {
    // Basic frontend interactions
});
'@
}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Files created successfully."
