$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "includes/header.php" = @'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgriStack Farmer Registry Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="/agristack_farmer_registry/assets/css/style.css">
</head>
<body>
<div class="disclaimer-banner">
    Academic Prototype — Not an official UIDAI, AgriStack or Government of India application.
</div>
'@

    "includes/footer.php" = @'
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="/agristack_farmer_registry/assets/js/main.js"></script>
</body>
</html>
'@

    "includes/navbar.php" = @'
<nav class="navbar navbar-expand-lg navbar-light topbar">
    <div class="container-fluid">
        <a class="navbar-brand text-success fw-bold" href="/agristack_farmer_registry/index.php">AgriStack Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if(isLoggedIn()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="bi bi-bell"></i> 
                            <span class="badge bg-danger rounded-pill">0</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/login.php">Farmer Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/admin/login.php">Admin Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white px-3 ms-2" href="/agristack_farmer_registry/register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
'@

    "includes/sidebar.php" = @'
<?php
$role = getUserRole();
?>
<div class="sidebar p-3">
    <h5 class="text-center text-white mb-4"><i class="bi bi-person-circle fs-2"></i><br><small><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></small></h5>
    
    <?php if ($role === 'farmer'): ?>
        <a href="/agristack_farmer_registry/farmer/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="/agristack_farmer_registry/farmer/profile.php"><i class="bi bi-person me-2"></i> Profile</a>
        <a href="/agristack_farmer_registry/farmer/ekyc.php"><i class="bi bi-fingerprint me-2"></i> eKYC</a>
        <a href="/agristack_farmer_registry/farmer/farms.php"><i class="bi bi-geo-alt me-2"></i> Farm Registry</a>
        <a href="/agristack_farmer_registry/farmer/geotag.php"><i class="bi bi-pin-map me-2"></i> Geo-Tagging</a>
        <a href="/agristack_farmer_registry/farmer/documents.php"><i class="bi bi-file-earmark-text me-2"></i> Documents</a>
        <a href="/agristack_farmer_registry/farmer/esign.php"><i class="bi bi-pen me-2"></i> eSign</a>
        <a href="/agristack_farmer_registry/farmer/schemes.php"><i class="bi bi-journal-text me-2"></i> Schemes</a>
        <a href="/agristack_farmer_registry/farmer/applications.php"><i class="bi bi-ui-checks me-2"></i> Applications</a>
        <a href="/agristack_farmer_registry/farmer/notifications.php"><i class="bi bi-bell me-2"></i> Notifications</a>
        <a href="/agristack_farmer_registry/farmer/dossier.php"><i class="bi bi-file-person me-2"></i> Farmer Dossier</a>
    <?php elseif ($role === 'admin'): ?>
        <a href="/agristack_farmer_registry/admin/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="/agristack_farmer_registry/admin/farmers.php"><i class="bi bi-people me-2"></i> Farmers</a>
        <a href="/agristack_farmer_registry/admin/ekyc.php"><i class="bi bi-fingerprint me-2"></i> eKYC Review</a>
        <a href="/agristack_farmer_registry/admin/documents.php"><i class="bi bi-file-earmark-text me-2"></i> Documents</a>
        <a href="/agristack_farmer_registry/admin/applications.php"><i class="bi bi-ui-checks me-2"></i> Applications</a>
        <a href="/agristack_farmer_registry/admin/schemes.php"><i class="bi bi-journal-text me-2"></i> Schemes</a>
        <a href="/agristack_farmer_registry/admin/dbt.php"><i class="bi bi-cash-stack me-2"></i> DBT Sandbox</a>
        <a href="/agristack_farmer_registry/admin/notifications.php"><i class="bi bi-bell me-2"></i> Notifications</a>
        <a href="/agristack_farmer_registry/admin/audit-logs.php"><i class="bi bi-list-columns-reverse me-2"></i> Audit Logs</a>
        <a href="/agristack_farmer_registry/admin/project-info.php"><i class="bi bi-info-circle me-2"></i> Project Info</a>
    <?php endif; ?>
    <hr class="border-white">
    <a href="/agristack_farmer_registry/logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
</div>
'@

    "index.php" = @'
<?php
require_once 'config/auth.php';
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$stmt = $pdo->query("SELECT * FROM student_details LIMIT 1");
$project = $stmt->fetch();
?>
<div class="container mt-5">
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h1 class="display-4 text-success fw-bold">AgriStack Farmer Registry Portal</h1>
            <p class="lead mt-3">An academic prototype designed to demonstrate digital farmer registration, identity verification workflows, farm registration, geo-tagging, agricultural scheme applications, eSign, paperless documentation and DBT transaction simulation.</p>
            <div class="mt-4">
                <a href="register.php" class="btn btn-success btn-lg me-2">Farmer Registration</a>
                <a href="login.php" class="btn btn-outline-success btn-lg">Farmer Login</a>
            </div>
        </div>
        <div class="col-md-6">
            <img src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Agriculture" class="img-fluid rounded shadow">
        </div>
    </div>

    <div class="row text-center my-5">
        <h2 class="mb-4">Features & Workflow</h2>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-person-vcard fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Digital Registry & eKYC</h5>
                    <p class="card-text text-muted">Register and complete demo identity verification to receive a unique Farmer ID.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-geo-alt fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Farm Geo-Tagging</h5>
                    <p class="card-text text-muted">Register land records and accurately geo-tag farm locations on the map.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-ui-checks fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Scheme Applications</h5>
                    <p class="card-text text-muted">Apply for agricultural schemes seamlessly with paperless eSign.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-cash-stack fs-1 text-success mb-3"></i>
                    <h5 class="card-title">DBT Simulation</h5>
                    <p class="card-text text-muted">Experience Direct Benefit Transfer workflows via a sandbox environment.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row my-5">
        <div class="col-12">
            <div class="card bg-light border-0">
                <div class="card-body p-5 text-center">
                    <h3 class="mb-3">About This Project</h3>
                    <p>This portal is developed strictly as a B.Tech academic prototype for educational purposes.</p>
                    <div class="row justify-content-center mt-4">
                        <div class="col-md-8 text-start">
                            <ul class="list-group list-group-flush bg-transparent">
                                <li class="list-group-item bg-transparent"><strong>Student Name:</strong> <?= htmlspecialchars($project['student_name']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Register Number:</strong> <?= htmlspecialchars($project['register_number']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Department:</strong> <?= htmlspecialchars($project['department']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>College:</strong> <?= htmlspecialchars($project['college_name']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Guide Name:</strong> <?= htmlspecialchars($project['guide_name']) ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
'@

    "logout.php" = @'
<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

if (isset($_SESSION['user_id'])) {
    logAudit($pdo, $_SESSION['user_id'], $_SESSION['role'], 'Logout', 'User logged out successfully.');
}

session_unset();
session_destroy();
header("Location: index.php");
exit;
?>
'@
}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Includes and Public files created successfully."
