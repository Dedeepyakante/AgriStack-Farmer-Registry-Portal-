$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "login.php" = @'
<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $mobile = $_POST['mobile'] ?? '';
    $password = $_POST['password'] ?? '';
    $captcha = $_POST['captcha'] ?? '';
    
    if ($captcha != $_SESSION['captcha_answer']) {
        $error = 'Invalid CAPTCHA.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE mobile = ? AND role = 'farmer'");
        $stmt->execute([$mobile]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            
            require_once 'includes/functions.php';
            logAudit($pdo, $user['id'], $user['role'], 'Login', 'Farmer logged in successfully.');
            
            header("Location: farmer/dashboard.php");
            exit;
        } else {
            $error = 'Invalid mobile number or password.';
        }
    }
}

// Generate simple captcha
$num1 = rand(1, 10);
$num2 = rand(1, 10);
$_SESSION['captcha_answer'] = $num1 + $num2;
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header bg-success text-white text-center">
                    <h4>Farmer Login</h4>
                </div>
                <div class="card-body p-4">
                    <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
                    <form method="post">
                        <div class="mb-3">
                            <label>Mobile Number</label>
                            <input type="text" name="mobile" class="form-control" required pattern="[0-9]{10}">
                        </div>
                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Solve: <?= $num1 ?> + <?= $num2 ?> = ?</label>
                            <input type="number" name="captcha" class="form-control" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-success w-100">Login</button>
                    </form>
                    <hr>
                    <div class="text-center mb-3">
                        <span class="text-muted">OR</span>
                    </div>
                    <form method="post" action="sso_demo.php" class="text-center">
                        <button type="submit" class="btn btn-outline-primary w-100">Continue with Demo SSO</button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="forgot-password.php" class="text-decoration-none">Forgot Password?</a> | 
                        <a href="register.php" class="text-decoration-none">Register New Farmer</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
'@

    "sso_demo.php" = @'
<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// This is a dummy SSO simulation page.
$stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'farmer' LIMIT 1");
$stmt->execute();
$user = $stmt->fetch();

if ($user) {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['name'] = $user['name'];
    
    logAudit($pdo, $user['id'], $user['role'], 'SSO Login', 'Farmer logged in via Demo SSO.');
    
    header("Location: farmer/dashboard.php");
    exit;
} else {
    die("No demo farmer account exists yet to simulate SSO.");
}
?>
'@

    "register.php" = @'
<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $mobile = trim($_POST['mobile'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $district = trim($_POST['district'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $password = $_POST['password'] ?? '';
    $cpassword = $_POST['cpassword'] ?? '';
    $captcha = $_POST['captcha'] ?? '';

    if ($captcha != $_SESSION['captcha_answer']) {
        $error = 'Invalid CAPTCHA.';
    } elseif ($password !== $cpassword) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        if ($stmt->fetch()) {
            $error = 'Mobile number already registered.';
        } else {
            require_once 'includes/functions.php';
            $farmer_id = generateFarmerId($pdo);
            $hash = password_hash($password, PASSWORD_DEFAULT);

            try {
                $pdo->beginTransaction();
                
                $stmt = $pdo->prepare("INSERT INTO users (farmer_id, name, email, mobile, password_hash, role) VALUES (?, ?, ?, ?, ?, 'farmer')");
                $stmt->execute([$farmer_id, $name, $email, $mobile, $hash]);
                $user_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO farmer_profiles (user_id, dob, gender, address, district, state) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $dob, $gender, $address, $district, $state]);
                
                logAudit($pdo, $user_id, 'farmer', 'Registration', "Registered with Farmer ID $farmer_id");
                
                $pdo->commit();
                $success = "Registration Successful! Your Farmer ID is: <b>$farmer_id</b>";
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Registration failed. ' . $e->getMessage();
            }
        }
    }
}

$num1 = rand(1, 10);
$num2 = rand(1, 10);
$_SESSION['captcha_answer'] = $num1 + $num2;
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow mb-5">
                <div class="card-header bg-success text-white text-center">
                    <h4>Farmer Registration</h4>
                </div>
                <div class="card-body p-4">
                    <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
                    <?php if($success): ?>
                        <div class="alert alert-success text-center">
                            <h4><?= $success ?></h4>
                            <p>Please keep this ID for future reference.</p>
                            <a href="login.php" class="btn btn-success mt-3">Go to Login</a>
                        </div>
                    <?php else: ?>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Full Name *</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Mobile Number *</label>
                                <input type="text" name="mobile" class="form-control" required pattern="[0-9]{10}">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Email Address</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Date of Birth *</label>
                                <input type="date" name="dob" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Gender *</label>
                                <select name="gender" class="form-select" required>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label>Address *</label>
                                <textarea name="address" class="form-control" required></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>District *</label>
                                <input type="text" name="district" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>State *</label>
                                <input type="text" name="state" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Password *</label>
                                <input type="password" name="password" class="form-control" required minlength="8">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Confirm Password *</label>
                                <input type="password" name="cpassword" class="form-control" required minlength="8">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Solve: <?= $num1 ?> + <?= $num2 ?> = ? *</label>
                                <input type="number" name="captcha" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Register</button>
                    </form>
                    <div class="text-center mt-3">
                        Already registered? <a href="login.php" class="text-decoration-none">Login here</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
'@

    "forgot-password.php" = @'
<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$message = '';
$step = 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_otp'])) {
        $mobile = $_POST['mobile'];
        $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ? AND role = 'farmer'");
        $stmt->execute([$mobile]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['reset_user_id'] = $user['id'];
            $_SESSION['reset_otp'] = '123456'; // Demo OTP
            $step = 2;
        } else {
            $message = "Mobile number not found.";
        }
    } elseif (isset($_POST['verify_otp'])) {
        $otp = $_POST['otp'];
        if ($otp === $_SESSION['reset_otp']) {
            $step = 3;
        } else {
            $message = "Invalid OTP.";
            $step = 2;
        }
    } elseif (isset($_POST['reset_pwd'])) {
        $pwd = $_POST['password'];
        $cpwd = $_POST['cpassword'];
        if ($pwd === $cpwd && strlen($pwd) >= 8) {
            $hash = password_hash($pwd, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $stmt->execute([$hash, $_SESSION['reset_user_id']]);
            $message = "Password updated successfully. You can now login.";
            unset($_SESSION['reset_user_id'], $_SESSION['reset_otp']);
            $step = 1;
        } else {
            $message = "Passwords do not match or are less than 8 characters.";
            $step = 3;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-header bg-success text-white text-center">
                    <h4>Demo Password Reset</h4>
                </div>
                <div class="card-body p-4">
                    <?php if($message): ?><div class="alert alert-info"><?= htmlspecialchars($message) ?></div><?php endif; ?>
                    
                    <?php if($step === 1): ?>
                    <form method="post">
                        <div class="mb-3">
                            <label>Registered Mobile Number</label>
                            <input type="text" name="mobile" class="form-control" required pattern="[0-9]{10}">
                        </div>
                        <button type="submit" name="send_otp" class="btn btn-success w-100">Send Demo OTP</button>
                    </form>
                    <?php elseif($step === 2): ?>
                    <div class="alert alert-warning text-center fw-bold">Demo OTP: 123456</div>
                    <form method="post">
                        <div class="mb-3">
                            <label>Enter OTP</label>
                            <input type="text" name="otp" class="form-control" required>
                        </div>
                        <button type="submit" name="verify_otp" class="btn btn-success w-100">Verify OTP</button>
                    </form>
                    <?php elseif($step === 3): ?>
                    <form method="post">
                        <div class="mb-3">
                            <label>New Password</label>
                            <input type="password" name="password" class="form-control" required minlength="8">
                        </div>
                        <div class="mb-3">
                            <label>Confirm Password</label>
                            <input type="password" name="cpassword" class="form-control" required minlength="8">
                        </div>
                        <button type="submit" name="reset_pwd" class="btn btn-success w-100">Reset Password</button>
                    </form>
                    <?php endif; ?>
                    <div class="text-center mt-3">
                        <a href="login.php" class="text-decoration-none">Back to Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
'@

    "admin/login.php" = @'
<?php
session_start();
require_once '../config/database.php';
require_once '../includes/header.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['name'] = $user['name'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = 'Invalid admin credentials.';
    }
}
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white text-center">
                    <h4>Admin Login</h4>
                </div>
                <div class="card-body p-4">
                    <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
                    <form method="post">
                        <div class="mb-3">
                            <label>Admin Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-dark w-100">Secure Login</button>
                    </form>
                    <div class="mt-3 text-center">
                        <a href="../index.php">Back to Portal Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Auth files created successfully."
