$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "farmer/dashboard.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM farmer_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$stmt = $pdo->prepare("SELECT status FROM identity_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$ekyc = $stmt->fetchColumn() ?: 'Not Submitted';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms_count = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM scheme_applications WHERE user_id = ?");
$stmt->execute([$user_id]);
$app_count = $stmt->fetchColumn();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Farmer Dashboard</h2>
        <div class="alert alert-success border-0 shadow-sm">
            <h5>Welcome, <?= htmlspecialchars($user['name']) ?>!</h5>
            <strong>Farmer ID:</strong> <?= htmlspecialchars($user['farmer_id']) ?>
        </div>

        <h5 class="mt-4 mb-3">Progress Tracker</h5>
        <div class="d-flex justify-content-between text-center mb-5 overflow-auto pb-3">
            <div class="border p-2 bg-success text-white rounded"><i class="bi bi-check-circle"></i><br><small>Registered</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= $profile ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-person"></i><br><small>Profile</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($ekyc=='Verified') ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-fingerprint"></i><br><small>eKYC</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($farms_count>0) ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-geo-alt"></i><br><small>Farms</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($app_count>0) ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-ui-checks"></i><br><small>Schemes</small></div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0">
                    <div class="card-body">
                        <h6 class="text-muted text-uppercase mb-2">eKYC Status</h6>
                        <h4 class="mb-0 text-primary"><?= $ekyc ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0">
                    <div class="card-body">
                        <h6 class="text-muted text-uppercase mb-2">Registered Farms</h6>
                        <h4 class="mb-0 text-success"><?= $farms_count ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0">
                    <div class="card-body">
                        <h6 class="text-muted text-uppercase mb-2">Scheme Applications</h6>
                        <h4 class="mb-0 text-warning"><?= $app_count ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/profile.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dob = trim($_POST['dob'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $district = trim($_POST['district'] ?? '');
    $state = trim($_POST['state'] ?? '');
    
    $stmt = $pdo->prepare("UPDATE farmer_profiles SET dob=?, gender=?, address=?, district=?, state=?, profile_completed=1 WHERE user_id=?");
    if($stmt->execute([$dob, $gender, $address, $district, $state, $user_id])){
        $message = "Profile updated successfully.";
        require_once '../includes/functions.php';
        logAudit($pdo, $user_id, 'farmer', 'Profile Update', 'Farmer updated their demographic profile.');
    }
}

$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Profile</h2>
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Farmer ID</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($profile['farmer_id']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Full Name</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($profile['name']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Mobile</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($profile['mobile']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($profile['email']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($profile['dob'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Gender</label>
                            <select name="gender" class="form-select" required>
                                <option value="Male" <?= ($profile['gender']??'')=='Male'?'selected':'' ?>>Male</option>
                                <option value="Female" <?= ($profile['gender']??'')=='Female'?'selected':'' ?>>Female</option>
                                <option value="Other" <?= ($profile['gender']??'')=='Other'?'selected':'' ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label>Address</label>
                            <textarea name="address" class="form-control" required><?= htmlspecialchars($profile['address'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>District</label>
                            <input type="text" name="district" class="form-control" value="<?= htmlspecialchars($profile['district'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>State</label>
                            <input type="text" name="state" class="form-control" value="<?= htmlspecialchars($profile['state'] ?? '') ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-3">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/ekyc.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $doc_type = $_POST['document_type'];
    $file = $_FILES['document'];
    
    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, $allowed) && $file['size'] <= 5000000) {
        $filename = uniqid('ekyc_') . '.' . $ext;
        $dest = '../uploads/ekyc/' . $filename;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $photo_path = null;
            if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
                // Simulated photo extraction
                $photo_path = 'extracted_' . $filename;
                copy($dest, '../uploads/ekyc/' . $photo_path);
            }
            
            $stmt = $pdo->prepare("INSERT INTO identity_verifications (user_id, document_type, document_path, extracted_photo_path) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $doc_type, $filename, $photo_path]);
            
            require_once '../includes/functions.php';
            logAudit($pdo, $user_id, 'farmer', 'eKYC Submission', "Uploaded $doc_type for eKYC.");
            sendNotification($pdo, 1, 'New eKYC Submission', "Farmer ID has submitted eKYC documents for review.");
            
            $message = "Document uploaded successfully. Photo extraction simulation completed.";
        } else {
            $error = "Failed to move uploaded file.";
        }
    } else {
        $error = "Invalid file type or size exceeded (Max 5MB).";
    }
}

$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$ekyc_history = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">eKYC & Identity Verification</h2>
        <div class="alert alert-warning border-0">
            <strong>Note:</strong> This is a demo eKYC workflow. The system will attempt simulated automatic photo extraction from your uploaded document. Do NOT upload real sensitive IDs.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        
        <div class="card shadow-sm border-0 mb-5">
            <div class="card-body p-4">
                <form method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Identity Document Type</label>
                            <select name="document_type" class="form-select" required>
                                <option value="Demo Aadhaar">Demo Aadhaar</option>
                                <option value="Demo PAN">Demo PAN</option>
                                <option value="Voter ID">Voter ID</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Upload Document (JPG, PNG, PDF - Max 5MB)</label>
                            <input type="file" name="document" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required id="ekyc-upload">
                        </div>
                    </div>
                    <div id="preview-area" class="mt-3 mb-3 text-center" style="display:none;">
                        <h5>Document Preview</h5>
                        <img id="img-preview" src="" style="max-height: 200px; max-width:100%; border:1px solid #ccc; padding:5px; border-radius:5px;" class="d-none">
                        <p id="extraction-notice" class="text-muted mt-2 small">Simulated face extraction will be performed upon submission.</p>
                    </div>
                    <button type="submit" class="btn btn-success">Submit for Verification</button>
                </form>
            </div>
        </div>

        <h4 class="mb-3">Verification History</h4>
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Extracted Photo</th>
                        <th>Admin Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($ekyc_history as $hist): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($hist['submitted_at'])) ?></td>
                        <td><?= htmlspecialchars($hist['document_type']) ?></td>
                        <td>
                            <?php 
                                $badge = 'bg-secondary';
                                if($hist['status']=='Verified') $badge = 'bg-success';
                                if($hist['status']=='Rejected') $badge = 'bg-danger';
                            ?>
                            <span class="badge <?= $badge ?>"><?= $hist['status'] ?></span>
                        </td>
                        <td>
                            <?php if($hist['extracted_photo_path']): ?>
                                <img src="../uploads/ekyc/<?= htmlspecialchars($hist['extracted_photo_path']) ?>" height="40" class="rounded">
                            <?php else: ?>
                                <span class="text-muted small">Not possible (PDF/Demo Limitation)</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($hist['admin_remarks'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
document.getElementById('ekyc-upload').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(file){
        document.getElementById('preview-area').style.display = 'block';
        if(file.type.startsWith('image/')){
            const reader = new FileReader();
            reader.onload = function(e){
                document.getElementById('img-preview').src = e.target.result;
                document.getElementById('img-preview').classList.remove('d-none');
            }
            reader.readAsDataURL(file);
        } else {
            document.getElementById('img-preview').classList.add('d-none');
        }
    }
});
</script>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/documents.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $doc_name = trim($_POST['document_name']);
    $file = $_FILES['document'];
    
    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, $allowed) && $file['size'] <= 5000000) {
        $filename = uniqid('doc_') . '.' . $ext;
        $dest = '../uploads/documents/' . $filename;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $stmt = $pdo->prepare("INSERT INTO documents (user_id, document_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $doc_name, $filename, $ext, $file['size']]);
            require_once '../includes/functions.php';
            logAudit($pdo, $user_id, 'farmer', 'Document Upload', "Uploaded document: $doc_name");
            $message = "Document uploaded successfully.";
        } else {
            $error = "Upload failed.";
        }
    } else {
        $error = "Invalid file or size exceeded.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM documents WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$docs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Documents</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data" class="row align-items-end">
                    <div class="col-md-5">
                        <label>Document Name (e.g. Land Patta)</label>
                        <input type="text" name="document_name" class="form-control" required>
                    </div>
                    <div class="col-md-5">
                        <label>File (JPG, PNG, PDF)</label>
                        <input type="file" name="document" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">Upload</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Document Name</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($docs as $doc): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($doc['uploaded_at'])) ?></td>
                        <td><?= htmlspecialchars($doc['document_name']) ?></td>
                        <td><?= strtoupper(htmlspecialchars($doc['file_type'])) ?></td>
                        <td><?= round($doc['file_size']/1024, 2) ?> KB</td>
                        <td>
                            <a href="../uploads/documents/<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/farms.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $farm_name = trim($_POST['farm_name']);
    $survey_number = trim($_POST['survey_number']);
    $village = trim($_POST['village']);
    $mandal = trim($_POST['mandal']);
    $district = trim($_POST['district']);
    $state = trim($_POST['state']);
    $land_area = $_POST['land_area'];
    $land_unit = $_POST['land_unit'];
    $ownership_type = $_POST['ownership_type'];
    $crop_type = trim($_POST['crop_type']);
    $irrigation = trim($_POST['irrigation_type']);
    
    $stmt = $pdo->prepare("INSERT INTO farms (user_id, farm_name, survey_number, village, mandal, district, state, land_area, land_unit, ownership_type, crop_type, irrigation_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$user_id, $farm_name, $survey_number, $village, $mandal, $district, $state, $land_area, $land_unit, $ownership_type, $crop_type, $irrigation]);
    
    require_once '../includes/functions.php';
    logAudit($pdo, $user_id, 'farmer', 'Farm Registered', "Farm '$farm_name' registered.");
    $message = "Farm registered successfully.";
}

$stmt = $pdo->prepare("SELECT * FROM farms WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Farm Registry</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="mb-4 text-end">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addFarmModal"><i class="bi bi-plus-circle"></i> Add Farm</button>
        </div>

        <div class="row">
            <?php foreach($farms as $farm): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 border-start border-4 border-success h-100">
                    <div class="card-body">
                        <h5 class="card-title text-success"><?= htmlspecialchars($farm['farm_name']) ?></h5>
                        <p class="mb-1"><strong>Survey No:</strong> <?= htmlspecialchars($farm['survey_number']) ?></p>
                        <p class="mb-1"><strong>Location:</strong> <?= htmlspecialchars($farm['village'].', '.$farm['mandal'].', '.$farm['district']) ?></p>
                        <p class="mb-1"><strong>Area:</strong> <?= htmlspecialchars($farm['land_area'].' '.$farm['land_unit']) ?> (<?= $farm['ownership_type'] ?>)</p>
                        <p class="mb-2"><strong>Crop:</strong> <?= htmlspecialchars($farm['crop_type']) ?> | <strong>Irrigation:</strong> <?= htmlspecialchars($farm['irrigation_type']) ?></p>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <?php if($farm['latitude'] && $farm['longitude']): ?>
                                <span class="badge bg-success"><i class="bi bi-geo-alt-fill"></i> Geo-Tagged</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark"><i class="bi bi-geo-alt"></i> Not Geo-Tagged</span>
                                <a href="geotag.php?farm_id=<?= $farm['id'] ?>" class="btn btn-sm btn-outline-success">Tag Now</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($farms)): ?>
                <div class="col-12"><div class="alert alert-info">No farms registered yet. Click "Add Farm" to begin.</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Farm Modal -->
<div class="modal fade" id="addFarmModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Register New Farm</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="post">
      <div class="modal-body row">
          <div class="col-md-6 mb-3"><label>Farm Name (Identifier)</label><input type="text" name="farm_name" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Survey Number / Khata No</label><input type="text" name="survey_number" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Village</label><input type="text" name="village" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Mandal/Taluk</label><input type="text" name="mandal" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>District</label><input type="text" name="district" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>State</label><input type="text" name="state" class="form-control" required></div>
          <div class="col-md-4 mb-3"><label>Land Area</label><input type="number" step="0.01" name="land_area" class="form-control" required></div>
          <div class="col-md-4 mb-3"><label>Unit</label><select name="land_unit" class="form-select" required><option>Acres</option><option>Hectares</option></select></div>
          <div class="col-md-4 mb-3"><label>Ownership</label><select name="ownership_type" class="form-select" required><option>Owned</option><option>Leased</option></select></div>
          <div class="col-md-6 mb-3"><label>Current Crop</label><input type="text" name="crop_type" class="form-control"></div>
          <div class="col-md-6 mb-3"><label>Irrigation Source</label><input type="text" name="irrigation_type" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-success">Save Farm</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/geotag.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $farm_id = $_POST['farm_id'];
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    
    // Verify ownership
    $stmt = $pdo->prepare("SELECT id FROM farms WHERE id = ? AND user_id = ?");
    $stmt->execute([$farm_id, $user_id]);
    if ($stmt->fetch()) {
        $update = $pdo->prepare("UPDATE farms SET latitude = ?, longitude = ? WHERE id = ?");
        $update->execute([$lat, $lng, $farm_id]);
        require_once '../includes/functions.php';
        logAudit($pdo, $user_id, 'farmer', 'Geo-Tagging', "Farm ID $farm_id geo-tagged.");
        $message = "Location saved successfully!";
    }
}

$stmt = $pdo->prepare("SELECT * FROM farms WHERE user_id = ? AND latitude IS NULL");
$stmt->execute([$user_id]);
$pending_farms = $stmt->fetchAll();

$farm_id_sel = $_GET['farm_id'] ?? ($pending_farms[0]['id'] ?? '');
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Farm Geo-Tagging</h2>
        <div class="alert alert-info">
            Please allow browser location access to capture your farm's coordinates.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <form method="post" id="geoForm">
                            <div class="mb-3">
                                <label>Select Farm to Tag</label>
                                <select name="farm_id" class="form-select" required>
                                    <?php foreach($pending_farms as $pf): ?>
                                        <option value="<?= $pf['id'] ?>" <?= $farm_id_sel==$pf['id']?'selected':'' ?>><?= htmlspecialchars($pf['farm_name']) ?> (<?= htmlspecialchars($pf['survey_number']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Latitude</label>
                                <input type="text" id="lat" name="lat" class="form-control" readonly required>
                            </div>
                            <div class="mb-3">
                                <label>Longitude</label>
                                <input type="text" id="lng" name="lng" class="form-control" readonly required>
                            </div>
                            <button type="button" class="btn btn-primary w-100 mb-2" onclick="getLocation()"><i class="bi bi-geo"></i> Capture Current Location</button>
                            <button type="submit" class="btn btn-success w-100" id="saveBtn" disabled>Save Location</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <div id="map" style="height: 400px; width: 100%; border-radius: 5px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let map, marker;
document.addEventListener("DOMContentLoaded", function() {
    map = L.map('map').setView([20.5937, 78.9629], 5); // Default India center
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
});

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function showPosition(position) {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    
    document.getElementById('lat').value = lat;
    document.getElementById('lng').value = lng;
    document.getElementById('saveBtn').disabled = false;
    
    map.setView([lat, lng], 16);
    if(marker) map.removeLayer(marker);
    marker = L.marker([lat, lng]).addTo(map).bindPopup("Captured Farm Location").openPopup();
}

function showError(error) {
    let msg = "An unknown error occurred.";
    switch(error.code) {
        case error.PERMISSION_DENIED: msg = "User denied the request for Geolocation."; break;
        case error.POSITION_UNAVAILABLE: msg = "Location information is unavailable."; break;
        case error.TIMEOUT: msg = "The request to get user location timed out."; break;
    }
    alert(msg);
}
</script>
<?php require_once '../includes/footer.php'; ?>
'@
}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Farmer Portal Part 1 files created successfully."
