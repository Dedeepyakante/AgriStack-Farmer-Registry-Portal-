$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "farmer/schemes.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_scheme'])) {
    $scheme_id = $_POST['scheme_id'];
    $farm_id = $_POST['farm_id'] ?? null;
    
    // Check if already applied
    $chk = $pdo->prepare("SELECT id FROM scheme_applications WHERE user_id=? AND scheme_id=?");
    $chk->execute([$user_id, $scheme_id]);
    
    if($chk->fetch()) {
        $message = "You have already applied for this scheme.";
    } else {
        require_once '../includes/functions.php';
        $app_id = generateApplicationId($pdo);
        $stmt = $pdo->prepare("INSERT INTO scheme_applications (application_id, user_id, scheme_id, farm_id, status) VALUES (?, ?, ?, ?, 'Submitted')");
        $stmt->execute([$app_id, $user_id, $scheme_id, $farm_id]);
        
        logAudit($pdo, $user_id, 'farmer', 'Scheme Application', "Applied for scheme ID $scheme_id (App ID: $app_id).");
        sendNotification($pdo, 1, 'New Scheme Application', "Application $app_id received."); // Notify Admin
        
        $message = "Successfully applied! Your Application ID is $app_id.";
    }
}

$stmt = $pdo->query("SELECT * FROM schemes WHERE status = 'Active'");
$schemes = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT id, farm_name FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Agricultural Schemes</h2>
        <div class="alert alert-warning border-0">
            <strong>Demo Scheme:</strong> These are not official current government schemes.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($schemes as $scheme): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white text-success fw-bold fs-5">
                        <?= htmlspecialchars($scheme['scheme_name']) ?>
                    </div>
                    <div class="card-body">
                        <p class="mb-2"><strong>Description:</strong> <?= htmlspecialchars($scheme['description']) ?></p>
                        <p class="mb-2"><strong>Eligibility:</strong> <?= htmlspecialchars($scheme['eligibility']) ?></p>
                        <p class="mb-2"><strong>Benefits:</strong> <?= htmlspecialchars($scheme['benefits']) ?></p>
                        <p class="mb-3 text-muted small"><strong>Req. Docs:</strong> <?= htmlspecialchars($scheme['required_documents']) ?></p>
                        
                        <form method="post">
                            <input type="hidden" name="scheme_id" value="<?= $scheme['id'] ?>">
                            <div class="mb-3">
                                <label class="small">Select Farm (if applicable)</label>
                                <select name="farm_id" class="form-select form-select-sm">
                                    <option value="">-- None --</option>
                                    <?php foreach($farms as $f): ?>
                                        <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['farm_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" name="apply_scheme" class="btn btn-success w-100">Apply Now</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/applications.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT a.*, s.scheme_name, f.farm_name FROM scheme_applications a 
                       JOIN schemes s ON a.scheme_id = s.id 
                       LEFT JOIN farms f ON a.farm_id = f.id 
                       WHERE a.user_id = ? ORDER BY a.id DESC");
$stmt->execute([$user_id]);
$apps = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Scheme Applications</h2>
        
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>App ID</th>
                        <th>Scheme</th>
                        <th>Farm</th>
                        <th>Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($apps as $app): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($app['applied_at'])) ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($app['application_id']) ?></td>
                        <td><?= htmlspecialchars($app['scheme_name']) ?></td>
                        <td><?= htmlspecialchars($app['farm_name'] ?? 'N/A') ?></td>
                        <td>
                            <?php 
                                $badge = 'bg-secondary';
                                if($app['status']=='Approved') $badge = 'bg-success';
                                if($app['status']=='Rejected') $badge = 'bg-danger';
                                if($app['status']=='Under Review') $badge = 'bg-warning text-dark';
                            ?>
                            <span class="badge <?= $badge ?>"><?= $app['status'] ?></span>
                        </td>
                        <td><?= htmlspecialchars($app['admin_remarks'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($apps)): ?>
                        <tr><td colspan="6" class="text-center py-4">No applications found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/esign.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['esign_canvas'])) {
        $data_uri = $_POST['signature_data'];
        $encoded_image = explode(",", $data_uri)[1];
        $decoded_image = base64_decode($encoded_image);
        $filename = uniqid('esign_') . '.png';
        file_put_contents('../uploads/signatures/' . $filename, $decoded_image);
        
        $stmt = $pdo->prepare("INSERT INTO esignatures (user_id, signature_path) VALUES (?, ?)");
        $stmt->execute([$user_id, $filename]);
        
        require_once '../includes/functions.php';
        logAudit($pdo, $user_id, 'farmer', 'eSign', "Completed eSign via Canvas.");
        $message = "Electronic signature saved successfully.";
    } elseif (isset($_FILES['esign_upload'])) {
        $file = $_FILES['esign_upload'];
        $allowed = ['jpg', 'jpeg', 'png'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed) && $file['size'] <= 2000000) {
            $filename = uniqid('esign_') . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], '../uploads/signatures/' . $filename)) {
                $stmt = $pdo->prepare("INSERT INTO esignatures (user_id, signature_path) VALUES (?, ?)");
                $stmt->execute([$user_id, $filename]);
                
                require_once '../includes/functions.php';
                logAudit($pdo, $user_id, 'farmer', 'eSign', "Completed eSign via Image Upload.");
                $message = "Electronic signature uploaded successfully.";
            }
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM esignatures WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$esign = $stmt->fetch();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">eSign Module</h2>
        <div class="alert alert-warning border-0">
            <strong>Demo eSign — Academic Prototype.</strong> This is not a legally certified electronic signature.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <?php if($esign): ?>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body text-center">
                <h5 class="text-success"><i class="bi bi-check-circle-fill"></i> eSign Completed</h5>
                <p class="text-muted">Signed on: <?= date('d M Y H:i', strtotime($esign['signed_at'])) ?></p>
                <img src="../uploads/signatures/<?= htmlspecialchars($esign['signature_path']) ?>" class="img-fluid border rounded bg-light" style="max-height: 150px;">
            </div>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-bold">Method 1: Draw Signature</div>
                    <div class="card-body text-center">
                        <canvas id="sigCanvas" width="300" height="150" class="border rounded bg-light mb-3" style="cursor: crosshair; touch-action: none;"></canvas>
                        <br>
                        <button class="btn btn-sm btn-outline-secondary" onclick="clearCanvas()">Clear</button>
                        <form method="post" id="sigForm" class="mt-3">
                            <input type="hidden" name="signature_data" id="sigData">
                            <input type="hidden" name="esign_canvas" value="1">
                            <button type="button" class="btn btn-success" onclick="saveSignature()">Save Drawn Signature</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-bold">Method 2: Upload Signature Image</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label>Allowed: JPG, PNG (Max 2MB)</label>
                                <input type="file" name="esign_upload" class="form-control" accept=".jpg,.jpeg,.png" required>
                            </div>
                            <button type="submit" class="btn btn-success w-100 mt-4">Upload Signature</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const canvas = document.getElementById('sigCanvas');
const ctx = canvas.getContext('2d');
let isDrawing = false;

ctx.lineWidth = 2;
ctx.lineCap = 'round';
ctx.strokeStyle = '#000';

function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const evt = e.touches ? e.touches[0] : e;
    return {
        x: evt.clientX - rect.left,
        y: evt.clientY - rect.top
    };
}

canvas.addEventListener('mousedown', startDraw);
canvas.addEventListener('touchstart', startDraw);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('touchmove', draw);
canvas.addEventListener('mouseup', stopDraw);
canvas.addEventListener('touchend', stopDraw);
canvas.addEventListener('mouseout', stopDraw);

function startDraw(e) {
    e.preventDefault();
    isDrawing = true;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
}

function draw(e) {
    if (!isDrawing) return;
    e.preventDefault();
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
}

function stopDraw(e) {
    if (!isDrawing) return;
    e.preventDefault();
    isDrawing = false;
    ctx.closePath();
}

function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function saveSignature() {
    const dataURL = canvas.toDataURL('image/png');
    // Check if canvas is actually empty (a simple check, not perfect but works for demo)
    if(dataURL.length < 3000) {
        alert("Please draw a signature first.");
        return;
    }
    document.getElementById('sigData').value = dataURL;
    document.getElementById('sigForm').submit();
}
</script>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/notifications.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();

if (isset($_GET['mark_all'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$user_id]);
    header("Location: notifications.php");
    exit;
}

if (isset($_GET['read_id'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['read_id'], $user_id]);
    header("Location: notifications.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Notifications</h2>
            <a href="?mark_all=1" class="btn btn-sm btn-outline-success">Mark All as Read</a>
        </div>
        
        <div class="list-group shadow-sm border-0">
            <?php foreach($notifications as $n): ?>
                <a href="?read_id=<?= $n['id'] ?>" class="list-group-item list-group-item-action <?= $n['is_read'] ? 'bg-light text-muted' : '' ?>">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1 <?= $n['is_read'] ? '' : 'fw-bold' ?>"><?= htmlspecialchars($n['title']) ?></h6>
                        <small><?= date('d M, H:i', strtotime($n['created_at'])) ?></small>
                    </div>
                    <p class="mb-1"><?= htmlspecialchars($n['message']) ?></p>
                </a>
            <?php endforeach; ?>
            <?php if(empty($notifications)): ?>
                <div class="list-group-item text-center py-4">No notifications found.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "farmer/dossier.php" = @'
<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$ekyc = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM scheme_applications a JOIN schemes s ON a.scheme_id = s.id WHERE a.user_id = ?");
$stmt->execute([$user_id]);
$apps = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM esignatures WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$esign = $stmt->fetch();
?>
<style>
@media print {
    .no-print { display: none !important; }
    .sidebar { display: none !important; }
    .container { max-width: 100% !important; margin: 0 !important; }
}
</style>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4 bg-white" id="printableArea">
        <div class="text-end mb-4 no-print">
            <button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer"></i> Print Farmer Dossier</button>
        </div>
        
        <div class="text-center mb-4 border-bottom pb-3">
            <h2 class="fw-bold">AgriStack Farmer Dossier</h2>
            <p class="mb-0 text-muted">Generated on <?= date('d M Y H:i:s') ?></p>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <h4><i class="bi bi-person-lines-fill text-success"></i> Basic Details</h4>
                <table class="table table-bordered table-sm">
                    <tr><th width="30%">Farmer ID</th><td><?= htmlspecialchars($profile['farmer_id']) ?></td></tr>
                    <tr><th>Name</th><td><?= htmlspecialchars($profile['name']) ?></td></tr>
                    <tr><th>Mobile / Email</th><td><?= htmlspecialchars($profile['mobile']) ?> / <?= htmlspecialchars($profile['email']) ?></td></tr>
                    <tr><th>DOB / Gender</th><td><?= htmlspecialchars($profile['dob']) ?> / <?= htmlspecialchars($profile['gender']) ?></td></tr>
                    <tr><th>Address</th><td><?= htmlspecialchars($profile['address'].', '.$profile['district'].', '.$profile['state']) ?></td></tr>
                </table>
            </div>
            <div class="col-md-4 text-center">
                <?php if($ekyc && $ekyc['extracted_photo_path']): ?>
                    <img src="../uploads/ekyc/<?= htmlspecialchars($ekyc['extracted_photo_path']) ?>" class="img-thumbnail" style="height:150px">
                <?php else: ?>
                    <div class="border p-5 text-muted bg-light"><i class="bi bi-person fs-1"></i><br>No Photo</div>
                <?php endif; ?>
                <div class="mt-2 fw-bold">eKYC Status: <span class="text-<?= $ekyc['status']=='Verified'?'success':($ekyc['status']=='Rejected'?'danger':'warning') ?>"><?= $ekyc['status'] ?? 'Not Submitted' ?></span></div>
            </div>
        </div>

        <h4 class="mt-4"><i class="bi bi-geo-alt-fill text-success"></i> Registered Farms</h4>
        <table class="table table-bordered table-sm">
            <thead><tr class="bg-light"><th>Name</th><th>Survey No</th><th>Area</th><th>Location</th><th>Geo-Tag</th></tr></thead>
            <tbody>
                <?php foreach($farms as $f): ?>
                <tr>
                    <td><?= htmlspecialchars($f['farm_name']) ?></td>
                    <td><?= htmlspecialchars($f['survey_number']) ?></td>
                    <td><?= htmlspecialchars($f['land_area'].' '.$f['land_unit']) ?></td>
                    <td><?= htmlspecialchars($f['village'].', '.$f['district']) ?></td>
                    <td><?= $f['latitude'] ? $f['latitude'].', '.$f['longitude'] : 'No' ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($farms)): ?><tr><td colspan="5">No farms registered.</td></tr><?php endif; ?>
            </tbody>
        </table>

        <h4 class="mt-4"><i class="bi bi-ui-checks text-success"></i> Applications</h4>
        <table class="table table-bordered table-sm">
            <thead><tr class="bg-light"><th>App ID</th><th>Scheme Name</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php foreach($apps as $a): ?>
                <tr>
                    <td><?= htmlspecialchars($a['application_id']) ?></td>
                    <td><?= htmlspecialchars($a['scheme_name']) ?></td>
                    <td><?= htmlspecialchars($a['status']) ?></td>
                    <td><?= date('d M Y', strtotime($a['applied_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($apps)): ?><tr><td colspan="4">No applications submitted.</td></tr><?php endif; ?>
            </tbody>
        </table>

        <div class="mt-5 border-top pt-4">
            <div class="row align-items-center">
                <div class="col-8">
                    <p class="small text-muted">This is an electronically generated academic dossier. The details are self-certified by the farmer and verified by demo admin where applicable.</p>
                </div>
                <div class="col-4 text-center">
                    <?php if($esign): ?>
                        <img src="../uploads/signatures/<?= htmlspecialchars($esign['signature_path']) ?>" style="height: 60px;">
                        <br><small>Digitally Signed (<?= date('d M Y', strtotime($esign['signed_at'])) ?>)</small>
                    <?php else: ?>
                        <div class="border-bottom border-dark mt-4 mx-3"></div>
                        <small>Signature Missing</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@
}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Farmer Portal Part 2 files created successfully."
