$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "admin/dashboard.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$stats = [
    'farmers' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='farmer'")->fetchColumn(),
    'pending_ekyc' => $pdo->query("SELECT COUNT(*) FROM identity_verifications WHERE status='Pending'")->fetchColumn(),
    'farms' => $pdo->query("SELECT COUNT(*) FROM farms")->fetchColumn(),
    'pending_apps' => $pdo->query("SELECT COUNT(*) FROM scheme_applications WHERE status IN ('Submitted', 'Under Review')")->fetchColumn(),
    'dbt_tx' => $pdo->query("SELECT COUNT(*) FROM dbt_transactions")->fetchColumn()
];
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Admin Dashboard</h2>
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="card bg-success text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-people fs-1 mb-2"></i>
                        <h5>Total Farmers</h5>
                        <h2 class="fw-bold"><?= $stats['farmers'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-warning text-dark border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-fingerprint fs-1 mb-2"></i>
                        <h5>Pending eKYC</h5>
                        <h2 class="fw-bold"><?= $stats['pending_ekyc'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-info text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-geo-alt fs-1 mb-2"></i>
                        <h5>Registered Farms</h5>
                        <h2 class="fw-bold"><?= $stats['farms'] ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-danger text-white border-0 shadow h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-ui-checks fs-1 mb-2"></i>
                        <h5>Pending Apps</h5>
                        <h2 class="fw-bold"><?= $stats['pending_apps'] ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/farmers.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$search = $_GET['search'] ?? '';
$query = "SELECT u.id, u.farmer_id, u.name, u.mobile, p.state FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.role='farmer'";
if($search){
    $query .= " AND (u.name LIKE '%$search%' OR u.farmer_id LIKE '%$search%')";
}
$query .= " ORDER BY u.id DESC";

$farmers = $pdo->query($query)->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Registered Farmers</h2>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="get" class="d-flex w-50">
                    <input type="text" name="search" class="form-control me-2" placeholder="Search Name or Farmer ID" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-outline-success">Search</button>
                </form>
            </div>
        </div>

        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Farmer ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>State</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($farmers as $f): ?>
                    <tr>
                        <td class="fw-bold"><?= htmlspecialchars($f['farmer_id']) ?></td>
                        <td><?= htmlspecialchars($f['name']) ?></td>
                        <td><?= htmlspecialchars($f['mobile']) ?></td>
                        <td><?= htmlspecialchars($f['state'] ?? '-') ?></td>
                        <td>
                            <a href="farmer-view.php?id=<?= $f['id'] ?>" class="btn btn-sm btn-success"><i class="bi bi-eye"></i> View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/farmer-view.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ? AND u.role='farmer'");
$stmt->execute([$id]);
$farmer = $stmt->fetch();

if(!$farmer) die("Farmer not found.");
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Farmer Details</h2>
            <a href="farmers.php" class="btn btn-outline-secondary">Back</a>
        </div>
        
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="text-success border-bottom pb-2 mb-3">Basic Information</h5>
                <div class="row">
                    <div class="col-md-4 mb-2"><strong>Farmer ID:</strong> <?= htmlspecialchars($farmer['farmer_id']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Name:</strong> <?= htmlspecialchars($farmer['name']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Mobile:</strong> <?= htmlspecialchars($farmer['mobile']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Email:</strong> <?= htmlspecialchars($farmer['email']) ?></div>
                    <div class="col-md-4 mb-2"><strong>DOB:</strong> <?= htmlspecialchars($farmer['dob']) ?></div>
                    <div class="col-md-4 mb-2"><strong>Gender:</strong> <?= htmlspecialchars($farmer['gender']) ?></div>
                    <div class="col-md-12 mt-2"><strong>Address:</strong> <?= htmlspecialchars($farmer['address'].', '.$farmer['district'].', '.$farmer['state']) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/ekyc.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $id = $_POST['ekyc_id'];
    $uid = $_POST['user_id'];
    $action = $_POST['action'];
    $remarks = $_POST['remarks'];
    
    $status = $action === 'verify' ? 'Verified' : 'Rejected';
    $stmt = $pdo->prepare("UPDATE identity_verifications SET status=?, admin_remarks=?, verified_at=NOW(), verified_by=? WHERE id=?");
    $stmt->execute([$status, $remarks, getUserId(), $id]);
    
    logAudit($pdo, getUserId(), 'admin', "eKYC $status", "eKYC ID $id marked as $status.");
    sendNotification($pdo, $uid, "eKYC Status Update", "Your eKYC document has been $status. Remarks: $remarks");
    
    $message = "eKYC marked as $status successfully.";
}

$stmt = $pdo->query("SELECT v.*, u.name, u.farmer_id FROM identity_verifications v JOIN users u ON v.user_id = u.id WHERE v.status = 'Pending' ORDER BY v.id ASC");
$pending = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">eKYC Review</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($pending as $p): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-warning fw-bold">
                        <?= htmlspecialchars($p['farmer_id']) ?> - <?= htmlspecialchars($p['name']) ?>
                    </div>
                    <div class="card-body">
                        <p><strong>Type:</strong> <?= htmlspecialchars($p['document_type']) ?></p>
                        <p><strong>Submitted:</strong> <?= date('d M Y H:i', strtotime($p['submitted_at'])) ?></p>
                        
                        <div class="mb-3">
                            <a href="../uploads/ekyc/<?= htmlspecialchars($p['document_path']) ?>" target="_blank" class="btn btn-sm btn-primary">View Full Document</a>
                            <?php if($p['extracted_photo_path']): ?>
                                <button class="btn btn-sm btn-info" data-bs-toggle="collapse" data-bs-target="#photo-<?= $p['id'] ?>">Show Detected Photo</button>
                            <?php endif; ?>
                        </div>
                        
                        <?php if($p['extracted_photo_path']): ?>
                        <div class="collapse mb-3" id="photo-<?= $p['id'] ?>">
                            <img src="../uploads/ekyc/<?= htmlspecialchars($p['extracted_photo_path']) ?>" class="img-thumbnail" style="max-height: 120px;">
                        </div>
                        <?php endif; ?>
                        
                        <form method="post" class="mt-3">
                            <input type="hidden" name="ekyc_id" value="<?= $p['id'] ?>">
                            <input type="hidden" name="user_id" value="<?= $p['user_id'] ?>">
                            <div class="mb-2">
                                <input type="text" name="remarks" class="form-control" placeholder="Admin remarks (Optional)">
                            </div>
                            <button type="submit" name="action" value="verify" class="btn btn-success"><i class="bi bi-check-lg"></i> Verify</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger"><i class="bi bi-x-lg"></i> Reject</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($pending)): ?>
                <div class="col-12"><div class="alert alert-info">No pending eKYC requests.</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/documents.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

if (isset($_GET['mark'])) {
    $id = $_GET['mark'];
    $stmt = $pdo->prepare("UPDATE documents SET status = 'Reviewed' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: documents.php");
    exit;
}

$stmt = $pdo->query("SELECT d.*, u.name, u.farmer_id FROM documents d JOIN users u ON d.user_id = u.id ORDER BY d.id DESC LIMIT 50");
$docs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Document Repository</h2>
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Date</th>
                        <th>Farmer</th>
                        <th>Document Name</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($docs as $doc): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($doc['uploaded_at'])) ?></td>
                        <td><?= htmlspecialchars($doc['name']) ?> (<?= htmlspecialchars($doc['farmer_id']) ?>)</td>
                        <td><?= htmlspecialchars($doc['document_name']) ?></td>
                        <td><?= strtoupper($doc['file_type']) ?></td>
                        <td>
                            <span class="badge <?= $doc['status']=='Reviewed'?'bg-success':'bg-warning text-dark' ?>"><?= $doc['status'] ?></span>
                        </td>
                        <td>
                            <a href="../uploads/documents/<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-sm btn-primary">View</a>
                            <?php if($doc['status'] == 'Uploaded'): ?>
                                <a href="?mark=<?= $doc['id'] ?>" class="btn btn-sm btn-success">Mark Reviewed</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/applications.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_id = $_POST['app_id'];
    $user_id = $_POST['user_id'];
    $status = $_POST['status'];
    $remarks = $_POST['remarks'];
    
    $stmt = $pdo->prepare("UPDATE scheme_applications SET status=?, admin_remarks=? WHERE id=?");
    $stmt->execute([$status, $remarks, $app_id]);
    
    logAudit($pdo, getUserId(), 'admin', 'App Review', "Application ID $app_id status changed to $status.");
    sendNotification($pdo, $user_id, "Application Status Updated", "Your application status is now $status. Remarks: $remarks");
    
    $message = "Application updated successfully.";
}

$stmt = $pdo->query("SELECT a.*, u.name, u.farmer_id, s.scheme_name, f.farm_name FROM scheme_applications a 
                     JOIN users u ON a.user_id = u.id 
                     JOIN schemes s ON a.scheme_id = s.id 
                     LEFT JOIN farms f ON a.farm_id = f.id 
                     ORDER BY a.id DESC");
$apps = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Scheme Applications Review</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="accordion" id="appAccordion">
            <?php foreach($apps as $index => $app): ?>
            <div class="accordion-item mb-2 border rounded shadow-sm">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>">
                        <strong><?= htmlspecialchars($app['application_id']) ?></strong>&nbsp;-&nbsp;<?= htmlspecialchars($app['scheme_name']) ?>&nbsp;(<?= htmlspecialchars($app['farmer_id']) ?>)
                        <span class="badge ms-auto <?= $app['status']=='Approved'?'bg-success':($app['status']=='Rejected'?'bg-danger':'bg-warning text-dark') ?>">
                            <?= $app['status'] ?>
                        </span>
                    </button>
                </h2>
                <div id="collapse<?= $index ?>" class="accordion-collapse collapse" data-bs-parent="#appAccordion">
                    <div class="accordion-body">
                        <div class="row mb-3">
                            <div class="col-md-4"><strong>Farmer:</strong> <?= htmlspecialchars($app['name']) ?></div>
                            <div class="col-md-4"><strong>Farm:</strong> <?= htmlspecialchars($app['farm_name'] ?? 'N/A') ?></div>
                            <div class="col-md-4"><strong>Applied On:</strong> <?= date('d M Y', strtotime($app['applied_at'])) ?></div>
                        </div>
                        
                        <form method="post" class="border p-3 rounded bg-light">
                            <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                            <input type="hidden" name="user_id" value="<?= $app['user_id'] ?>">
                            <div class="row align-items-end">
                                <div class="col-md-4">
                                    <label>Update Status</label>
                                    <select name="status" class="form-select">
                                        <option value="Under Review" <?= $app['status']=='Under Review'?'selected':'' ?>>Under Review</option>
                                        <option value="Approved" <?= $app['status']=='Approved'?'selected':'' ?>>Approved</option>
                                        <option value="Rejected" <?= $app['status']=='Rejected'?'selected':'' ?>>Rejected</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Admin Remarks</label>
                                    <input type="text" name="remarks" class="form-control" value="<?= htmlspecialchars($app['admin_remarks'] ?? '') ?>">
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@
}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Admin Portal Part 1 files created successfully."
