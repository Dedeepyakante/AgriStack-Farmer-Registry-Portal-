$base_dir = "C:\xampp\htdocs\agristack_farmer_registry"

$files = @{
    "admin/schemes.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_scheme'])) {
    $name = $_POST['scheme_name'];
    $desc = $_POST['description'];
    $elig = $_POST['eligibility'];
    $benf = $_POST['benefits'];
    $docs = $_POST['required_documents'];
    
    $stmt = $pdo->prepare("INSERT INTO schemes (scheme_name, description, eligibility, benefits, required_documents) VALUES (?,?,?,?,?)");
    $stmt->execute([$name, $desc, $elig, $benf, $docs]);
    
    logAudit($pdo, getUserId(), 'admin', 'Scheme Added', "Added scheme: $name");
    $message = "Scheme added successfully.";
}

$schemes = $pdo->query("SELECT * FROM schemes ORDER BY id DESC")->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Manage Schemes</h2>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addSchemeModal"><i class="bi bi-plus-circle"></i> Add Scheme</button>
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($schemes as $s): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-header bg-success text-white fw-bold">
                        <?= htmlspecialchars($s['scheme_name']) ?>
                        <span class="badge bg-light text-dark float-end"><?= $s['status'] ?></span>
                    </div>
                    <div class="card-body">
                        <p class="small mb-1"><strong>Desc:</strong> <?= htmlspecialchars($s['description']) ?></p>
                        <p class="small mb-1"><strong>Elig:</strong> <?= htmlspecialchars($s['eligibility']) ?></p>
                        <p class="small mb-0"><strong>Benf:</strong> <?= htmlspecialchars($s['benefits']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Add Scheme Modal -->
<div class="modal fade" id="addSchemeModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Add Demo Scheme</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="post">
      <div class="modal-body">
          <div class="mb-3"><label>Scheme Name</label><input type="text" name="scheme_name" class="form-control" required></div>
          <div class="mb-3"><label>Description</label><textarea name="description" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Eligibility</label><textarea name="eligibility" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Benefits</label><textarea name="benefits" class="form-control" required></textarea></div>
          <div class="mb-3"><label>Required Documents</label><input type="text" name="required_documents" class="form-control" required></div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="add_scheme" class="btn btn-success">Save Scheme</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/dbt.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['initiate_dbt'])) {
    $app_id = $_POST['app_id'];
    $farmer_id = $_POST['farmer_id'];
    $amount = $_POST['amount'];
    
    // Check if already paid successfully
    $chk = $pdo->prepare("SELECT id FROM dbt_transactions WHERE application_id = ? AND status = 'Success'");
    $chk->execute([$app_id]);
    
    if($chk->fetch()) {
        $error = "A successful DBT transaction already exists for this application.";
    } else {
        $tx_id = generateTransactionId($pdo);
        $stmt = $pdo->prepare("INSERT INTO dbt_transactions (transaction_id, application_id, farmer_id, amount, status) VALUES (?,?,?,?,'Success')");
        $stmt->execute([$tx_id, $app_id, $farmer_id, $amount]);
        
        // Find user to notify
        $usr = $pdo->prepare("SELECT id FROM users WHERE farmer_id = ?");
        $usr->execute([$farmer_id]);
        $u = $usr->fetch();
        if($u) sendNotification($pdo, $u['id'], "DBT Transferred", "Demo DBT of Rs.$amount credited for Application $app_id. TX ID: $tx_id");
        
        logAudit($pdo, getUserId(), 'admin', 'DBT Transfer', "DBT of Rs.$amount sent to $farmer_id (App: $app_id).");
        $message = "Demo DBT transaction initiated successfully! TX ID: $tx_id";
    }
}

// Get Approved applications ready for DBT
$approved_apps = $pdo->query("SELECT a.application_id, u.farmer_id, u.name, s.scheme_name FROM scheme_applications a JOIN users u ON a.user_id = u.id JOIN schemes s ON a.scheme_id = s.id WHERE a.status = 'Approved'")->fetchAll();
$transactions = $pdo->query("SELECT * FROM dbt_transactions ORDER BY id DESC")->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">DBT Sandbox <small class="text-muted">(Simulation Only)</small></h2>
        <div class="alert alert-danger fw-bold border-0 text-center">
            DBT Sandbox — No real money is transferred. This is an academic simulation.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        
        <div class="row">
            <div class="col-md-5">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-primary text-white fw-bold">Initiate Demo DBT</div>
                    <div class="card-body">
                        <form method="post">
                            <div class="mb-3">
                                <label>Select Approved Application</label>
                                <select name="app_id" class="form-select" required onchange="setFarmerId(this)">
                                    <option value="">-- Select --</option>
                                    <?php foreach($approved_apps as $a): ?>
                                        <option value="<?= $a['application_id'] ?>" data-farmer="<?= $a['farmer_id'] ?>">
                                            <?= $a['application_id'] ?> (<?= htmlspecialchars($a['name']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Farmer ID</label>
                                <input type="text" name="farmer_id" id="farmer_id" class="form-control" readonly required>
                            </div>
                            <div class="mb-3">
                                <label>Transfer Amount (Demo Rs.)</label>
                                <input type="number" name="amount" class="form-control" required min="1">
                            </div>
                            <button type="submit" name="initiate_dbt" class="btn btn-primary w-100"><i class="bi bi-send"></i> Process Transfer</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-7">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">Recent Transactions</div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Txn ID</th>
                                        <th>App ID</th>
                                        <th>Farmer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($transactions as $t): ?>
                                    <tr>
                                        <td class="fw-bold"><?= $t['transaction_id'] ?></td>
                                        <td><?= $t['application_id'] ?></td>
                                        <td><?= $t['farmer_id'] ?></td>
                                        <td>₹<?= number_format($t['amount'], 2) ?></td>
                                        <td><span class="badge bg-success"><?= $t['status'] ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if(empty($transactions)): ?>
                                        <tr><td colspan="5" class="text-center py-3">No transactions simulated yet.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function setFarmerId(sel) {
    if(sel.selectedIndex > 0) {
        document.getElementById('farmer_id').value = sel.options[sel.selectedIndex].getAttribute('data-farmer');
    } else {
        document.getElementById('farmer_id').value = '';
    }
}
</script>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/notifications.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
if (isset($_GET['mark_all'])) {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$user_id]);
    header("Location: notifications.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100");
$stmt->execute([$user_id]);
$notifs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Admin Notifications</h2>
            <a href="?mark_all=1" class="btn btn-outline-success">Mark All as Read</a>
        </div>
        <div class="list-group shadow-sm border-0">
            <?php foreach($notifs as $n): ?>
                <div class="list-group-item <?= $n['is_read'] ? 'bg-light text-muted' : '' ?>">
                    <div class="d-flex justify-content-between">
                        <h6 class="<?= $n['is_read'] ? '' : 'fw-bold' ?>"><?= htmlspecialchars($n['title']) ?></h6>
                        <small><?= date('d M H:i', strtotime($n['created_at'])) ?></small>
                    </div>
                    <p class="mb-0"><?= htmlspecialchars($n['message']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/audit-logs.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$stmt = $pdo->query("SELECT a.*, u.name, u.farmer_id FROM audit_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.id DESC LIMIT 200");
$logs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">System Audit Logs</h2>
        
        <div class="table-responsive bg-white rounded shadow-sm border-0">
            <table class="table table-hover table-sm mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Timestamp</th>
                        <th>Role</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($logs as $log): ?>
                    <tr>
                        <td style="white-space:nowrap;"><?= $log['created_at'] ?></td>
                        <td><span class="badge bg-secondary"><?= htmlspecialchars($log['role']) ?></span></td>
                        <td><?= htmlspecialchars($log['name'] ?? 'System') ?> <?= $log['farmer_id']?"({$log['farmer_id']})":"" ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($log['action']) ?></td>
                        <td><?= htmlspecialchars($log['description']) ?></td>
                        <td><?= htmlspecialchars($log['ip_address']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "admin/project-info.php" = @'
<?php
require_once '../config/auth.php';
requireRole('admin');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE student_details SET student_name=?, register_number=?, department=?, college_name=?, guide_name=?, team_members=?, academic_year=? WHERE id=1");
    $stmt->execute([$_POST['student_name'], $_POST['register_number'], $_POST['department'], $_POST['college_name'], $_POST['guide_name'], $_POST['team_members'], $_POST['academic_year']]);
    $message = "Project information updated successfully.";
}

$project = $pdo->query("SELECT * FROM student_details WHERE id=1")->fetch();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Academic Project Information</h2>
        <?php if($message): ?><div class="alert alert-success"><?= $message ?></div><?php endif; ?>
        
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label>Student Name</label><input type="text" name="student_name" class="form-control" value="<?= htmlspecialchars($project['student_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Register Number</label><input type="text" name="register_number" class="form-control" value="<?= htmlspecialchars($project['register_number']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Department</label><input type="text" name="department" class="form-control" value="<?= htmlspecialchars($project['department']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>College/University Name</label><input type="text" name="college_name" class="form-control" value="<?= htmlspecialchars($project['college_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Guide Name</label><input type="text" name="guide_name" class="form-control" value="<?= htmlspecialchars($project['guide_name']) ?>"></div>
                        <div class="col-md-6 mb-3"><label>Academic Year</label><input type="text" name="academic_year" class="form-control" value="<?= htmlspecialchars($project['academic_year']) ?>"></div>
                        <div class="col-12 mb-3"><label>Team Members</label><textarea name="team_members" class="form-control"><?= htmlspecialchars($project['team_members']) ?></textarea></div>
                    </div>
                    <button type="submit" class="btn btn-success">Save Information</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
'@

    "README.md" = @'
# AgriStack Farmer Registry Portal

## Academic Prototype Disclaimer
This is an academic prototype designed for a B.Tech final-year project. It demonstrates digital farmer registration, identity verification workflows, farm registration, geo-tagging, agricultural scheme applications, eSign, paperless documentation, and DBT transaction simulation.
**This is NOT an official UIDAI, AgriStack, or Government of India application.**

## Technology Stack
- Frontend: HTML5, CSS3, JavaScript, Bootstrap 5, Leaflet.js
- Backend: PHP 8+
- Database: MySQL
- Server: XAMPP (Apache + MySQL)

## Features
- **Farmer Portal:** Registration, Demo SSO, eKYC (Simulated photo extraction), Farm Registry, Geo-Tagging, Scheme Application, eSign (Canvas/Upload), Printable Dossier.
- **Admin Portal:** Dashboard, Farmer Verification, eKYC Review, Document Review, Application Review, DBT Sandbox (Simulation), Audit Logs.

## Setup Instructions
1. Clone or extract this project to `C:\xampp\htdocs\agristack_farmer_registry`
2. Start Apache and MySQL via XAMPP Control Panel.
3. Import `database.sql` into a new database named `agristack_farmer_registry` using phpMyAdmin or CLI.
4. Access the application at: `http://localhost/agristack_farmer_registry/`

## Demo Credentials
**Admin Account:**
- Email: admin@agristack-demo.local
- Password: Admin@12345

**Farmer Account:**
- Mobile: 8888888888
- Password: Farmer@12345
- Demo SSO can also be used for farmer login.

## Limitations
- eKYC uses basic image handling to simulate photo extraction.
- eSign is a canvas drawing tool and is not legally certified.
- DBT Sandbox is a simulation; no real money is transferred.
- SSO is a direct session generation simulation, not a real OAuth flow.
'@

}

foreach ($item in $files.GetEnumerator()) {
    $full_path = Join-Path $base_dir $item.Key
    $dir = Split-Path $full_path
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }
    Set-Content -Path $full_path -Value $item.Value -Encoding UTF8
}

Write-Host "Admin Portal Part 2 & README created successfully."
