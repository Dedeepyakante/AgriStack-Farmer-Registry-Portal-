# UIDAI Trusted Offline e-KYC Public Certificates Store

Place official UIDAI Offline Public Key Certificates in this folder (`.cer`, `.pem`, or `.crt` format).

### 1. Which Certificate is Required?
- **Required:** The official **UIDAI Offline Public Key Certificate** (e.g. `uidai_offline_publickey_26022019.cer` or newer active offline public key certificates published by UIDAI).
- **Purpose:** Used specifically to verify digital signatures (`<ds:Signature>`) on **Aadhaar Paperless Offline e-KYC XML** files and RSA signatures on Aadhaar Secure QR codes.
- **DO NOT USE:** `uidai_auth_prod.cer` or `uidai_auth_encrypt.cer`. Those certificates are for PID block encryption in online 1:1 authentication (AUA/KUA) and **cannot** be used to verify offline e-KYC XML signatures.

### 2. Official UIDAI Download Source:
- Official Portal: **[https://uidai.gov.in](https://uidai.gov.in)**
- Section: Navigate to **Ecosystem** -> **Data & Downloads** -> **Offline e-KYC Public Key Certificates** (or **Aadhaar Online Services** / **MyAadhaar** portal: **[https://myaadhaar.uidai.gov.in](https://myaadhaar.uidai.gov.in)**).
- Official file reference: `uidai_offline_publickey_26022019.cer` (or latest published version).

### 3. File Formats Supported:
- Both **DER binary** (`.cer`) and **PEM ASCII** (`.pem` / `.crt`) formats are supported automatically by the verifier.
- Once placed here, the verifier will automatically load, normalize, and match incoming XML signatures against this trusted certificate store.
