<?php
if(session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function requireAuth() {
    if (!isLoggedIn()) {
        header("Location: /agristack_farmer_registry/login.php");
        exit;
    }
}

function requireRole($role) {
    requireAuth();
    if (getUserRole() !== $role) {
        if (getUserRole() === 'admin') {
            header("Location: /agristack_farmer_registry/admin/dashboard.php");
            exit;
        } elseif (getUserRole() === 'farmer') {
            header("Location: /agristack_farmer_registry/farmer/dashboard.php");
            exit;
        } else {
            header("Location: /agristack_farmer_registry/login.php");
            exit;
        }
    }
}
