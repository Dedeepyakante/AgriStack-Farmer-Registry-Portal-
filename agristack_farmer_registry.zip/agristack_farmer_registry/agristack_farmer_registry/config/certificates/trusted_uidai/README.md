# UIDAI Trusted Certifying Authority Store

This directory contains official public certificates for validating:
1. **Aadhaar Paperless Offline e-KYC (XML)** digital signatures (`<ds:Signature>`).
2. **Aadhaar Secure QR** RSA digital signatures.

### Official Certificate Sources:
- Official UIDAI Portal: https://myaadhaar.uidai.gov.in/
- UIDAI Developer Ecosystem: https://uidai.gov.in/

### Security Policy:
- Certificates in this directory are considered **authoritative trusted anchors**.
- The backend will **NEVER** trust an embedded certificate solely because it appears inside an uploaded XML or QR payload.
- In **production mode**, all uploaded documents must chain or match a certificate in this directory.
- Test certificates stored in `../test_fixtures/` are strictly isolated for unit testing and are rejected in production.
