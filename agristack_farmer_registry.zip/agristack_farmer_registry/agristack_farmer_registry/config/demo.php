<?php
/**
 * AgriLink / AgriStack Farmer Registry - Demo Mode Configuration
 * 
 * Controls whether custom demonstration e-KYC files (AgriLinkDemoEKYC) are allowed.
 * - When DEMO_MODE is true: Separate demo upload path is active.
 * - When DEMO_MODE is false: Demo files are strictly rejected with "Demo files are disabled".
 */

if (!defined('DEMO_MODE')) {
    define('DEMO_MODE', true);
}

/**
 * Check if demo mode is enabled on the server
 */
function isDemoModeEnabled(): bool {
    if (isset($GLOBALS['OVERRIDE_DEMO_MODE'])) {
        return (bool)$GLOBALS['OVERRIDE_DEMO_MODE'];
    }
    return defined('DEMO_MODE') && DEMO_MODE === true;
}
