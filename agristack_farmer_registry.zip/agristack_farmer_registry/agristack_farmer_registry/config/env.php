<?php
/**
 * AgriLink / AgriStack Farmer Registry - Environment Variable Loader
 * 
 * Secure backend-only .env file parser.
 * - Loads root-level .env file
 * - Populates $_ENV, $_SERVER, and putenv()
 * - Never prints or leaks credentials to HTTP output
 */

if (!function_exists('loadEnv')) {
    function loadEnv(?string $filePath = null): bool {
        if ($filePath === null) {
            $candidates = [
                dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env',
                dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . '.env',
            ];
            if (!empty($_SERVER['DOCUMENT_ROOT'])) {
                $candidates[] = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\') . DIRECTORY_SEPARATOR . 'agristack_farmer_registry' . DIRECTORY_SEPARATOR . '.env';
            }
            foreach ($candidates as $cand) {
                if (file_exists($cand) && is_readable($cand)) {
                    $filePath = $cand;
                    break;
                }
            }
            if ($filePath === null) {
                $filePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
            }
        }

        if (!file_exists($filePath) || !is_readable($filePath)) {
            return false;
        }

        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return false;
        }

        foreach ($lines as $line) {
            $line = trim($line);

            // Skip empty lines and comment lines
            if ($line === '' || str_starts_with($line, '#') || str_starts_with($line, ';')) {
                continue;
            }

            // Split on first '='
            $eqPos = strpos($line, '=');
            if ($eqPos === false) {
                continue;
            }

            $key   = trim(substr($line, 0, $eqPos));
            $value = trim(substr($line, $eqPos + 1));

            // Remove optional 'export ' prefix
            if (str_starts_with(strtolower($key), 'export ')) {
                $key = trim(substr($key, 7));
            }

            // Validate identifier
            if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $key)) {
                continue;
            }

            // Strip unquoted trailing comments
            if (!str_starts_with($value, '"') && !str_starts_with($value, "'")) {
                $commentPos = strpos($value, '#');
                if ($commentPos !== false) {
                    $value = trim(substr($value, 0, $commentPos));
                }
            }

            // Handle quoted strings
            if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                $value = substr($value, 1, -1);
            }

            // Clean accidental JSON copy-paste artifacts (e.g. \"\r\n}\r\n, trailing commas, braces, escaped quotes)
            if (preg_match('/^([a-zA-Z0-9_\-]+)(\\\\"|\\\\r|\\\\n|[",}\]\s])+$/', $value, $m)) {
                $value = $m[1];
            } else {
                $value = trim($value, " \t\n\r\0\x0B\"',");
            }

            // Set into superglobals and environment
            $_ENV[$key]    = $value;
            $_SERVER[$key] = $value;
            putenv("{$key}={$value}");
        }

        return true;
    }
}

if (!function_exists('env')) {
    /**
     * Retrieve an environment variable with fallback
     */
    function env(string $key, $default = null) {
        if (array_key_exists($key, $_ENV)) {
            return $_ENV[$key];
        }
        if (array_key_exists($key, $_SERVER)) {
            return $_SERVER[$key];
        }
        $val = getenv($key);
        if ($val !== false) {
            return $val;
        }
        return $default;
    }
}

// Auto-load .env when included
loadEnv();
