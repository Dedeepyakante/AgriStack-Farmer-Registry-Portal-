<?php
/**
 * AgriLink / AgriStack Farmer Registry - emSigner Digital Signature Configuration
 * 
 * Official External Provider: emSigner by eMudhra
 * Platform URL: https://demo.emsigner.com/
 * Sandbox API: https://demoapi.emsigner.com/api/
 * 
 * Architecture Rules:
 * 1. All signing occurs externally on https://demo.emsigner.com/
 * 2. Opening emSigner alone never approves or signs documents or agreements.
 * 3. Browser redirect parameters are never accepted as proof of signing.
 * 4. Actual signing results must be verified on the backend before marking any status.
 * 5. Credentials are kept strictly server-side and role-based access is enforced.
 */

require_once __DIR__ . '/env.php';

// External emSigner Platform & Direct Navigation URL
define('EMSIGNER_URL', env('EMSIGNER_URL', 'https://demo.emsigner.com/'));
define('ESIGN_PROVIDER_NAME', 'emSigner');

// Backend Provider API Settings (Kept strictly on server; never exposed to browser or JS)
// Official emSigner credentials loaded securely from backend .env
define('EMSIGNER_APP_NAME', env('EMSIGNER_APP_NAME', env('ESIGN_APP_NAME', 'AgriLink')));
define('ESIGN_APP_NAME', EMSIGNER_APP_NAME);

define('EMSIGNER_SECRET_CODE', env('EMSIGNER_SECRET_CODE', env('ESIGN_CLIENT_SECRET', '')));
define('ESIGN_CLIENT_SECRET', EMSIGNER_SECRET_CODE);

define('EMSIGNER_AUTH_KEY', env('EMSIGNER_AUTH_KEY', env('ESIGN_AUTH_TOKEN', env('ESIGN_CLIENT_ID', ''))));
define('ESIGN_AUTH_TOKEN', EMSIGNER_AUTH_KEY);
define('ESIGN_CLIENT_ID', EMSIGNER_AUTH_KEY);

define('EMSIGNER_BASE_URL', env('EMSIGNER_BASE_URL', env('ESIGN_API_BASE_URL', 'https://demoapi.emsigner.com/api/')));
define('ESIGN_API_BASE_URL', EMSIGNER_BASE_URL);

define('EMSIGNER_WEBHOOK_SECRET', env('EMSIGNER_WEBHOOK_SECRET', env('ESIGN_WEBHOOK_SECRET', 'agristack_emsigner_hmac_secret_2026')));
define('ESIGN_WEBHOOK_SECRET', EMSIGNER_WEBHOOK_SECRET);

define('EMSIGNER_ENVIRONMENT', env('EMSIGNER_ENVIRONMENT', env('ESIGN_ENVIRONMENT', 'sandbox')));
define('ESIGN_ENVIRONMENT', EMSIGNER_ENVIRONMENT);

// Provider activation: explicit ENV setting, or auto-enabled when real credentials are provided
$envProviderEnabled = env('EMSIGNER_PROVIDER_ENABLED', env('ESIGN_PROVIDER_ENABLED', null));
if ($envProviderEnabled !== null) {
    define('ESIGN_PROVIDER_ENABLED', filter_var($envProviderEnabled, FILTER_VALIDATE_BOOLEAN));
} else {
    // Enabled automatically if credentials are provided and are not dummy placeholder values
    $isConfigured = !empty(EMSIGNER_AUTH_KEY) 
                 && !empty(EMSIGNER_SECRET_CODE)
                 && !in_array(strtolower(EMSIGNER_AUTH_KEY), ['your_auth_key', 'your_auth_token', 'your_client_id'])
                 && !in_array(strtolower(EMSIGNER_SECRET_CODE), ['your_secret_code', 'your_client_secret']);
    define('ESIGN_PROVIDER_ENABLED', $isConfigured);
}

/**
 * Check if official emSigner API integration is fully configured on the backend
 */
function isVerifiedEsignConfigured(): bool {
    return defined('ESIGN_PROVIDER_ENABLED') && ESIGN_PROVIDER_ENABLED === true 
        && !empty(ESIGN_API_BASE_URL) 
        && !empty(EMSIGNER_AUTH_KEY) 
        && !empty(EMSIGNER_SECRET_CODE)
        && !in_array(strtolower(EMSIGNER_AUTH_KEY), ['your_auth_key', 'your_auth_token', 'your_client_id'])
        && !in_array(strtolower(EMSIGNER_SECRET_CODE), ['your_secret_code', 'your_client_secret']);
}

/**
 * Returns emSigner integration state and human-readable explanation
 * NOTE: Credentials (Auth Key, Secret Code) are NEVER exposed here or returned to client
 */
function getEmSignerIntegrationState(): array {
    $configured = isVerifiedEsignConfigured();
    return [
        'is_configured' => $configured,
        'mode'          => $configured ? 'api_gateway' : 'direct_link',
        'platform_url'  => EMSIGNER_URL,
        'provider_name' => ESIGN_PROVIDER_NAME,
        'environment'   => ESIGN_ENVIRONMENT,
        'notice'        => 'Navigating to emSigner opens the external signing platform (https://demo.emsigner.com/). '
                         . 'Document transfer, automatic return, and signature confirmation are not yet connected without live API gateway credentials. '
                         . 'Opening emSigner alone does not approve or sign records; backend verification of the actual signing result is mandatory.'
    ];
}

/**
 * Resolve the signing URL for an action.
 * Returns provider-generated signing URL when integration is configured,
 * or falls back to https://demo.emsigner.com/ with explicit disconnected notice.
 */
function getEmSignerSigningUrl(string $actionType, string $referenceId = '', array $signerInfo = []): string {
    if (isVerifiedEsignConfigured()) {
        // When official API credentials are active, generate session URL via API
        return ESIGN_API_BASE_URL . 'gateway/sign?action=' . urlencode($actionType) . '&ref=' . urlencode($referenceId);
    }
    // Direct link fallback per user specification
    return EMSIGNER_URL;
}

/**
 * Generate a canonical SHA-256 hash of transaction agreement terms to ensure immutability
 */
function generateAgreementTermsHash(array $terms): string {
    $canonical = [
        'farmer_id'      => (string)($terms['farmer_id'] ?? ''),
        'buyer_name'     => trim((string)($terms['buyer_name'] ?? '')),
        'crop'           => trim((string)($terms['crop'] ?? '')),
        'quantity'       => number_format((float)($terms['quantity'] ?? 0), 2, '.', ''),
        'quantity_unit'  => trim((string)($terms['quantity_unit'] ?? 'Quintals')),
        'agreed_price'   => number_format((float)($terms['agreed_price'] ?? 0), 2, '.', ''),
        'total_amount'   => number_format((float)($terms['total_amount'] ?? 0), 2, '.', ''),
        'delivery_terms' => trim((string)($terms['delivery_terms'] ?? ''))
    ];
    ksort($canonical);
    return hash('sha256', json_encode($canonical));
}
