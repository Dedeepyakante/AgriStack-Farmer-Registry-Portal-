<?php
/**
 * Google OAuth 2.0 Configuration
 * AgriStack Farmer Registry Portal
 * 
 * SETUP INSTRUCTIONS:
 * 1. Go to https://console.cloud.google.com/
 * 2. Create a new project or select existing
 * 3. Enable "Google+ API" or "Google Identity" 
 * 4. Go to Credentials > Create OAuth 2.0 Client ID
 * 5. Application type: Web application
 * 6. Add Authorized redirect URI: http://localhost/agristack_farmer_registry/auth/google-callback.php
 * 7. Copy Client ID and Client Secret below
 */

define('GOOGLE_CLIENT_ID',     '148831915996-v5tjhhi0mvuschts0cpujjec04a3slgf.apps.googleusercontent.com');  // e.g. 123456789-xxxx.apps.googleusercontent.com
define('GOOGLE_CLIENT_SECRET', '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');  // e.g. GOCSPX-xxxxxxxxxx
define('GOOGLE_REDIRECT_URI',  'http://localhost/agristack_farmer_registry/auth/google-callback.php');

define('GOOGLE_AUTH_URL',  'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USERINFO_URL', 'https://www.googleapis.com/oauth2/v3/userinfo');

/**
 * Returns true if Google OAuth is properly configured
 */
function googleOAuthConfigured(): bool {
    return !empty(GOOGLE_CLIENT_ID) && !empty(GOOGLE_CLIENT_SECRET);
}

/**
 * Build Google OAuth authorization URL
 */
function buildGoogleAuthUrl(string $state): string {
    $params = http_build_query([
        'client_id'     => GOOGLE_CLIENT_ID,
        'redirect_uri'  => GOOGLE_REDIRECT_URI,
        'response_type' => 'code',
        'scope'         => 'openid email profile',
        'access_type'   => 'online',
        'state'         => $state,
        'prompt'        => 'select_account',  // Force account chooser
    ]);
    return GOOGLE_AUTH_URL . '?' . $params;
}
