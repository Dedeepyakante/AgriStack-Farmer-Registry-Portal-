<?php
/**
 * AgriStack Farmer Registry Portal - Mailer & Notification System
 * 
 * SETUP INSTRUCTIONS FOR REAL GMAIL / SMTP:
 * 1. Go to your Google Account (https://myaccount.google.com/)
 * 2. Go to Security -> 2-Step Verification -> App Passwords
 * 3. Generate a 16-character App Password (e.g. "abcd efgh ijkl mnop")
 * 4. Set SMTP_ENABLED to true and fill in SMTP_USER and SMTP_PASS below.
 */

define('SMTP_ENABLED', true); // Change to true for live email delivery
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587); // 587 for TLS, 465 for SSL
define('SMTP_USER', 'lakshmiprasannarojakari@gmail.com'); // Enter your Gmail: e.g. lakshmiprasannarojakari@gmail.com
define('SMTP_PASS', 'gatgepiahffxyqqi'); // Enter your 16-character Google App Password
define('SMTP_ENCRYPTION', 'tls'); // 'tls' or 'ssl'
define('SMTP_FROM_EMAIL', 'lakshmiprasannarojakari@gmail.com');
define('SMTP_FROM_NAME', 'AgriStack Farmer Registry');

/**
 * Check if real mailer credentials are fully configured
 */
function isMailerConfigured(): bool {
    return defined('SMTP_ENABLED') && SMTP_ENABLED === true && !empty(SMTP_USER) && !empty(SMTP_PASS);
}

/**
 * Direct Socket-based SMTP mail client for reliable sending on XAMPP/Windows without sendmail.exe
 */
function sendDirectSmtp(string $toEmail, string $subject, string $bodyText, string $recipientName = ''): bool {
    $host     = SMTP_HOST;
    $port     = (int)SMTP_PORT;
    $username = SMTP_USER;
    $password = str_replace(' ', '', SMTP_PASS); // strip spaces from Google app passwords
    $fromEmail = !empty(SMTP_FROM_EMAIL) ? SMTP_FROM_EMAIL : $username;
    $fromName  = SMTP_FROM_NAME;

    $remoteHost = ($port === 465) ? "ssl://{$host}" : "tcp://{$host}";
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        ]
    ]);
    $socket = @stream_socket_client("{$remoteHost}:{$port}", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $context);
    if (!$socket) {
        return false;
    }

    $read = function() use ($socket) {
        $response = "";
        while ($str = fgets($socket, 515)) {
            $response .= $str;
            if (substr($str, 3, 1) === " ") break;
        }
        return $response;
    };

    $write = function($cmd) use ($socket) {
        fputs($socket, $cmd . "\r\n");
    };

    $read(); // Initial greeting
    $write("EHLO " . gethostname());
    $read();

    if ($port === 587 || SMTP_ENCRYPTION === 'tls') {
        $write("STARTTLS");
        $tlsResp = $read();
        if (substr($tlsResp, 0, 3) === '220') {
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                fclose($socket);
                return false;
            }
            $write("EHLO " . gethostname());
            $read();
        }
    }

    $write("AUTH LOGIN");
    $read();
    $write(base64_encode($username));
    $read();
    $write(base64_encode($password));
    $authResp = $read();
    if (substr($authResp, 0, 3) !== "235") {
        fclose($socket);
        return false;
    }

    $write("MAIL FROM: <{$fromEmail}>");
    $read();
    $write("RCPT TO: <{$toEmail}>");
    $read();
    $write("DATA");
    $read();

    $headers  = "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <{$fromEmail}>\r\n";
    $headers .= "To: {$toEmail}\r\n";
    $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $headers .= "Date: " . date('r') . "\r\n";

    $write($headers . "\r\n" . $bodyText . "\r\n.");
    $dataResp = $read();
    $write("QUIT");
    $read();
    fclose($socket);

    return (substr($dataResp, 0, 3) === '250');
}

/**
 * General purpose Email Sender supporting Real SMTP / Gmail and Demo Outbox logging.
 */
function sendPortalEmail(string $toEmail, string $subject, string $bodyText, string $recipientName = ''): array {
    $timestamp = date('Y-m-d H:i:s');

    // Always log formatted message to demo_email_outbox.txt for audit & academic prototype grading
    $outboxFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'demo_email_outbox.txt';
    $entry = "====================================================\n"
           . "DISPATCHED AT: {$timestamp}\n"
           . "TO EMAIL: {$toEmail}" . ($recipientName ? " ({$recipientName})" : "") . "\n"
           . "SUBJECT: {$subject}\n"
           . "----------------------------------------------------\n"
           . "{$bodyText}\n"
           . "====================================================\n\n";

    @file_put_contents($outboxFile, $entry, FILE_APPEND);

    if (isMailerConfigured()) {
        $sent = sendDirectSmtp($toEmail, $subject, $bodyText, $recipientName);
        if ($sent) {
            return [
                'success' => true,
                'mode'    => 'smtp',
                'message' => "Email sent directly to {$toEmail} via SMTP."
            ];
        }
    }

    return [
        'success' => true,
        'mode'    => 'demo',
        'message' => "Email logged to demo outbox ('demo_email_outbox.txt')."
    ];
}

/**
 * Dispatch OTP via Email or SMS.
 */
function sendOTPMessage(string $destination, string $otp, string $type = 'email', string $recipientName = 'User'): array {
    $timestamp = date('Y-m-d H:i:s');
    $expiryMinutes = 15;
    
    if ($type === 'email') {
        $subject = "AgriStack Portal - Password Reset OTP";
        $body = "Hello {$recipientName},\n\n"
              . "Your One-Time Password (OTP) for resetting your AgriStack Portal password is: {$otp}\n\n"
              . "This OTP is valid for {$expiryMinutes} minutes. Do not share this code with anyone.\n\n"
              . "Regards,\n"
              . "AgriStack Administration\n"
              . "Timestamp: {$timestamp}";

        return sendPortalEmail($destination, $subject, $body, $recipientName);
    } else {
        // SMS handling
        $smsBody = "AgriStack OTP: {$otp} is your password reset code. Valid for {$expiryMinutes} mins.";
        $outboxFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'demo_sms_outbox.txt';
        $entry = "====================================================\n"
               . "DISPATCHED AT: {$timestamp}\n"
               . "TO MOBILE: {$destination}\n"
               . "----------------------------------------------------\n"
               . "SMS BODY: {$smsBody}\n"
               . "YOUR SECURE OTP IS: {$otp}\n"
               . "====================================================\n\n";
        
        @file_put_contents($outboxFile, $entry, FILE_APPEND);
        
        return [
            'success' => true,
            'mode' => 'demo',
            'message' => "OTP generated and dispatched to SMS outbox ('demo_sms_outbox.txt')."
        ];
    }
}

/**
 * Send notification email to Admin when a Farmer submits a new Scheme Application
 */
function notifyAdminOfNewApplication($pdo, string $appId, string $farmerName, string $farmerId, string $schemeName, string $farmName = 'N/A'): array {
    $stmt = $pdo->query("SELECT email, name FROM users WHERE role = 'admin' AND status = 'active' AND email IS NOT NULL AND email != ''");
    $admins = $stmt->fetchAll();

    $results = [];
    $subject = "New Scheme Application Request - [{$appId}] {$schemeName}";
    $timestamp = date('d M Y, h:i A');

    $body = "Dear Administrator,\n\n"
          . "A new agricultural scheme application has been submitted and is pending review.\n\n"
          . "APPLICATION DETAILS:\n"
          . "----------------------------------------\n"
          . "Application ID : {$appId}\n"
          . "Scheme Name    : {$schemeName}\n"
          . "Farmer Name    : {$farmerName}\n"
          . "Farmer ID      : {$farmerId}\n"
          . "Registered Farm: {$farmName}\n"
          . "Submitted At   : {$timestamp}\n"
          . "----------------------------------------\n\n"
          . "Please log in to the AgriStack Admin Portal to review and process this application.\n\n"
          . "Regards,\n"
          . "AgriStack Portal Notification System";

    foreach ($admins as $admin) {
        $results[] = sendPortalEmail($admin['email'], $subject, $body, $admin['name']);
    }

    return $results;
}

/**
 * Send notification email to Farmer when Admin updates or approves a Scheme Application
 */
function notifyFarmerOfApplicationStatus($pdo, int $farmerUserId, string $appId, string $schemeName, string $status, string $adminRemarks = ''): array {
    $stmt = $pdo->prepare("SELECT name, email, mobile FROM users WHERE id = ?");
    $stmt->execute([$farmerUserId]);
    $farmer = $stmt->fetch();

    if (!$farmer || empty($farmer['email'])) {
        return ['success' => false, 'message' => 'Farmer email not found.'];
    }

    $timestamp = date('d M Y, h:i A');
    $statusUpper = strtoupper($status);
    $subject = "Your Scheme Application [{$appId}] has been {$statusUpper} - AgriStack";

    $statusMessage = ($status === 'Approved')
        ? "Congratulations! Your application for the '{$schemeName}' scheme has been APPROVED successfully."
        : (($status === 'Rejected')
            ? "Your application for the '{$schemeName}' scheme has been REJECTED by the administration."
            : "Your application for the '{$schemeName}' scheme is now {$statusUpper}.");

    $body = "Dear {$farmer['name']},\n\n"
          . "{$statusMessage}\n\n"
          . "APPLICATION DETAILS:\n"
          . "----------------------------------------\n"
          . "Application ID : {$appId}\n"
          . "Scheme Name    : {$schemeName}\n"
          . "Current Status : {$status}\n"
          . "Admin Remarks  : " . (!empty($adminRemarks) ? $adminRemarks : "None") . "\n"
          . "Reviewed At    : {$timestamp}\n"
          . "----------------------------------------\n\n"
          . "You can log in to your AgriStack Farmer Dashboard anytime to view full details and download your dossier.\n\n"
          . "Regards,\n"
          . "Department of Agriculture - AgriStack Registry";

    return sendPortalEmail($farmer['email'], $subject, $body, $farmer['name']);
}

/**
 * Send DBT credit notification email to the Farmer's registered email
 */
function notifyFarmerOfDbtTransfer(
    string $farmerEmail,
    string $farmerName,
    string $schemeName,
    string $appId,
    float $amount,
    string $txId,
    string $txDate = ''
): array {
    if (empty($farmerEmail)) {
        return ['success' => false, 'message' => 'Farmer has no registered email address.'];
    }

    if (empty($txDate)) {
        $txDate = date('d M Y, h:i A');
    }

    $formattedAmount = '₹' . number_format($amount, 2);
    $statusText = "Demo Benefit Credited Successfully";
    $disclaimer = "DBT Sandbox — Academic Simulation. No real money is transferred.";

    $subject = "AgriStack DBT Credit Notification: {$formattedAmount} [{$txId}]";

    $body = "Dear {$farmerName},\n\n"
          . "Your Direct Benefit Transfer (DBT) has been processed under the AgriStack portal.\n\n"
          . "════════════════════════════════════════════════════\n"
          . "           DBT TRANSACTION DETAILS\n"
          . "════════════════════════════════════════════════════\n"
          . "Farmer Name      : {$farmerName}\n"
          . "Scheme Name      : {$schemeName}\n"
          . "Application ID   : {$appId}\n"
          . "DBT Amount       : {$formattedAmount}\n"
          . "Transaction ID   : {$txId}\n"
          . "Transaction Date : {$txDate}\n"
          . "Status           : {$statusText}\n"
          . "════════════════════════════════════════════════════\n\n"
          . "NOTICE:\n"
          . "{$disclaimer}\n\n"
          . "The demo benefit has been reflected in your AgriStack portal account.\n"
          . "You can log in to your Farmer Dashboard to review your transaction history and download your updated dossier.\n\n"
          . "Regards,\n"
          . "Direct Benefit Transfer Division\n"
          . "AgriStack Farmer Registry Portal";

    return sendPortalEmail($farmerEmail, $subject, $body, $farmerName);
}

/**
 * Send DBT confirmation email to the Administrator
 */
function notifyAdminOfDbtConfirmation(
    string $adminEmail,
    string $adminName,
    string $farmerName,
    string $farmerId,
    string $schemeName,
    string $appId,
    float $amount,
    string $txId,
    string $txDate = ''
): array {
    if (empty($adminEmail)) {
        return ['success' => false, 'message' => 'Admin email not found.'];
    }

    if (empty($txDate)) {
        $txDate = date('d M Y, h:i A');
    }

    $formattedAmount = '₹' . number_format($amount, 2);
    $disclaimer = "DBT Sandbox — Academic Simulation. No real money is transferred.";
    $subject = "Admin DBT Confirmation: {$formattedAmount} Dispatched for {$appId} [{$txId}]";

    $body = "Dear Administrator ({$adminName}),\n\n"
          . "A Direct Benefit Transfer (DBT) transaction has been executed successfully via the AgriStack DBT Sandbox.\n\n"
          . "════════════════════════════════════════════════════\n"
          . "           ADMIN TRANSACTION SUMMARY\n"
          . "════════════════════════════════════════════════════\n"
          . "Transaction ID   : {$txId}\n"
          . "Application ID   : {$appId}\n"
          . "Farmer Name      : {$farmerName}\n"
          . "Farmer ID        : {$farmerId}\n"
          . "Scheme Name      : {$schemeName}\n"
          . "DBT Amount       : {$formattedAmount}\n"
          . "Transaction Date : {$txDate}\n"
          . "Status           : Processed (Success)\n"
          . "════════════════════════════════════════════════════\n\n"
          . "DISCLAIMER:\n"
          . "{$disclaimer}\n\n"
          . "Audit log record and in-portal farmer notifications have been recorded.\n\n"
          . "Regards,\n"
          . "AgriStack System Services";

    return sendPortalEmail($adminEmail, $subject, $body, $adminName);
}

