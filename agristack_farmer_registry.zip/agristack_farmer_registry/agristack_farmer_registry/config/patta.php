<?php
/**
 * Land Patta / Verification Configuration
 * =========================================
 * To integrate an official verified government land-records API or URL,
 * set PATTA_OFFICIAL_URL to the verified endpoint.
 *
 * Leave PATTA_OFFICIAL_URL as empty string ('') to use the project's own
 * demo patta page (land/patta.php) — the default for academic prototypes.
 *
 * Example for future integration:
 *   define('PATTA_OFFICIAL_URL', 'https://meebhoomi.ap.gov.in/patta?id=');
 *   define('PATTA_OFFICIAL_LABEL', 'Mee Bhoomi – AP Land Records');
 *
 * IMPORTANT: Only set PATTA_OFFICIAL_URL if you have a verified, documented,
 * publicly accessible API/URL. DO NOT invent a government URL.
 */

// Official government patta URL prefix (append survey number or farm ID).
// Leave empty to use the project's built-in demo patta page.
define('PATTA_OFFICIAL_URL',   '');
define('PATTA_OFFICIAL_LABEL', '');   // e.g. 'Mee Bhoomi – AP Land Records'

// Base URL of this project (auto-detect current host with localhost default, no trailing slash)
$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
define('PATTA_BASE_URL', $proto . $host . '/agristack_farmer_registry');

// Path to the demo patta page
define('PATTA_DEMO_PATH', '/land/patta.php');

/**
 * Returns the full QR URL for a given token.
 * If an official URL is configured, builds the official link.
 * Otherwise builds the demo patta link.
 */
function buildPattaQrUrl(string $token, string $survey_number = ''): string {
    if (PATTA_OFFICIAL_URL !== '' && $survey_number !== '') {
        return PATTA_OFFICIAL_URL . urlencode($survey_number);
    }
    return PATTA_BASE_URL . PATTA_DEMO_PATH . '?token=' . urlencode($token);
}

/**
 * Returns true if official patta integration is configured.
 */
function isOfficialPattaConfigured(): bool {
    return PATTA_OFFICIAL_URL !== '';
}
