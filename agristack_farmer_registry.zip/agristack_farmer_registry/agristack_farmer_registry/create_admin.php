<?php
/**
 * AgriStack Farmer Registry Portal - Admin Account Generator
 * 
 * Usage from Command Line:
 * C:\xampp\php\php.exe create_admin.php "Super Admin" "superadmin@agristack.local" "9876543210" "Admin@StrongPass123"
 */

require_once __DIR__ . '/config/database.php';

// Check if running from CLI or web
$isCli = (php_sapi_name() === 'cli');

if ($isCli) {
    $name     = $argv[1] ?? 'New Administrator';
    $email    = $argv[2] ?? 'newadmin@agristack.local';
    $mobile   = $argv[3] ?? '9876543210';
    $password = $argv[4] ?? 'Admin@12345';
} else {
    $name     = $_GET['name'] ?? 'New Administrator';
    $email    = $_GET['email'] ?? 'newadmin@agristack.local';
    $mobile   = $_GET['mobile'] ?? '9876543210';
    $password = $_GET['password'] ?? 'Admin@12345';
}

if (empty($email) || empty($mobile) || empty($password)) {
    echo "Error: Name, Email, Mobile and Password are required.\n";
    exit(1);
}

// Check if mobile or email already exists
$stmt = $pdo->prepare("SELECT id, email, mobile FROM users WHERE email = ? OR mobile = ?");
$stmt->execute([$email, $mobile]);
$existing = $stmt->fetch();

if ($existing) {
    echo "Error: An account with this Email ({$existing['email']}) or Mobile ({$existing['mobile']}) already exists (ID: {$existing['id']}).\n";
    exit(1);
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO users (farmer_id, name, email, mobile, password_hash, role, status) VALUES (NULL, ?, ?, ?, ?, 'admin', 'active')");
$stmt->execute([$name, $email, $mobile, $hash]);
$newId = $pdo->lastInsertId();

if ($isCli) {
    echo "===========================================\n";
    echo " ADMIN ACCOUNT CREATED SUCCESSFULLY!\n";
    echo "===========================================\n";
    echo "ID       : {$newId}\n";
    echo "Name     : {$name}\n";
    echo "Email    : {$email}\n";
    echo "Mobile   : {$mobile}\n";
    echo "Password : {$password}\n";
    echo "Role     : admin\n";
    echo "===========================================\n";
} else {
    echo "<h2 style='color:green;'>Admin Account Created Successfully!</h2>";
    echo "<ul>";
    echo "<li><strong>ID:</strong> {$newId}</li>";
    echo "<li><strong>Name:</strong> " . htmlspecialchars($name) . "</li>";
    echo "<li><strong>Email:</strong> " . htmlspecialchars($email) . "</li>";
    echo "<li><strong>Mobile:</strong> " . htmlspecialchars($mobile) . "</li>";
    echo "<li><strong>Password:</strong> " . htmlspecialchars($password) . "</li>";
    echo "<li><strong>Role:</strong> admin</li>";
    echo "</ul>";
    echo "<p><a href='admin/login.php'>Go to Admin Login</a></p>";
}
