<?php
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(dirname(__DIR__)));
$count = 0;
foreach ($files as $f) {
    if ($f->isFile() && $f->getExtension() === 'php') {
        $c = file_get_contents($f->getPathname());
        if (substr($c, 0, 3) === "\xEF\xBB\xBF") {
            echo "BOM: " . $f->getPathname() . "\n";
            $count++;
        }
    }
}
echo "TOTAL_BOM: " . $count . "\n";
