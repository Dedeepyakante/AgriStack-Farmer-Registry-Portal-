<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT a.*, s.scheme_name, f.farm_name, es.signature_path, es.signature_type 
                       FROM scheme_applications a 
                       JOIN schemes s ON a.scheme_id = s.id 
                       LEFT JOIN farms f ON a.farm_id = f.id 
                       LEFT JOIN esignatures es ON (a.esign_id = es.id OR (a.application_id = es.application_id AND a.application_id IS NOT NULL))
                       WHERE a.user_id = ? ORDER BY a.id DESC");
$stmt->execute([$user_id]);
$apps = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Scheme Applications</h2>
        
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>App ID</th>
                        <th>Scheme</th>
                        <th>Farm</th>
                        <th>eSign Status</th>
                        <th>Application Status</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($apps as $app): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($app['applied_at'])) ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($app['application_id']) ?></td>
                        <td><?= htmlspecialchars($app['scheme_name']) ?></td>
                        <td><?= htmlspecialchars($app['farm_name'] ?? 'N/A') ?></td>
                        <td>
                            <?php if(!empty($app['signature_path'])): ?>
                                <?php if(($app['signature_type'] ?? '') === 'verified_provider'): ?>
                                    <span class="badge bg-success py-1"><i class="bi bi-patch-check-fill me-1"></i>Verified Signed</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark py-1"><i class="bi bi-pen me-1"></i>Demo Signed</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="https://demo.emsigner.com/" class="btn btn-sm btn-success py-1">
                                    <i class="bi bi-pen me-1"></i>Digital Sign
                                </a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                                $badge = 'bg-secondary';
                                if($app['status']=='Approved') $badge = 'bg-success';
                                if($app['status']=='Rejected') $badge = 'bg-danger';
                                if($app['status']=='Under Review') $badge = 'bg-warning text-dark';
                            ?>
                            <span class="badge <?= $badge ?>"><?= $app['status'] ?></span>
                        </td>
                        <td><?= htmlspecialchars($app['admin_remarks'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($apps)): ?>
                        <tr><td colspan="7" class="text-center py-4">No applications found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
