<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM farmer_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$ekyc_record = $stmt->fetch();
$ekyc_status = $ekyc_record['verification_status'] ?? $ekyc_record['status'] ?? 'Not started';
$ekyc_holder_status = $ekyc_record['holder_check_status'] ?? 'Not started';
$ekyc = $ekyc_status;

$stmt = $pdo->prepare("SELECT COUNT(*) FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms_count = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM scheme_applications WHERE user_id = ?");
$stmt->execute([$user_id]);
$app_count = $stmt->fetchColumn();

// Retrieve farmer market transactions & pending emSigner signatures
$stmt = $pdo->prepare("SELECT COUNT(*) FROM market_transactions WHERE farmer_id = ?");
$stmt->execute([$user_id]);
$tx_count = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM transaction_agreements WHERE farmer_id = ? AND farmer_signature_status = 'Pending' AND agreement_status != 'Superseded'");
$stmt->execute([$user_id]);
$pending_tx_signs = $stmt->fetchColumn();

// Retrieve recent scheme applications for eSign status display
$recentAppsStmt = $pdo->prepare("SELECT a.application_id, s.scheme_name, a.status, a.esign_status, a.applied_at 
                                  FROM scheme_applications a 
                                  JOIN schemes s ON a.scheme_id = s.id 
                                  WHERE a.user_id = ? 
                                  ORDER BY a.id DESC LIMIT 5");
$recentAppsStmt->execute([$user_id]);
$recentApps = $recentAppsStmt->fetchAll();

// Retrieve recent market transactions for dashboard display
$recentTxStmt = $pdo->prepare("SELECT t.*, a.version, a.agreement_status, a.farmer_signature_status, a.admin_signature_status 
                               FROM market_transactions t 
                               LEFT JOIN transaction_agreements a ON t.id = a.transaction_id AND a.version = t.current_version 
                               WHERE t.farmer_id = ? 
                               ORDER BY t.id DESC LIMIT 3");
$recentTxStmt->execute([$user_id]);
$recentTx = $recentTxStmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <h2 class="mb-0">Farmer Dashboard</h2>
            <a href="https://demo.emsigner.com/" class="btn btn-success fw-semibold shadow-sm">
                <i class="bi bi-pen me-1"></i>Digital Sign
            </a>
        </div>

        <div class="alert alert-success border-0 shadow-sm">
            <h5>Welcome, <?= htmlspecialchars($user['name']) ?>!</h5>
            <strong>Farmer ID:</strong> <?= htmlspecialchars($user['farmer_id']) ?>
        </div>

        <?php if (!empty($_SESSION['google_new_registration'])): unset($_SESSION['google_new_registration']); ?>
        <div class="alert alert-info alert-dismissible fade show border-0 shadow-sm" role="alert">
            <div class="d-flex align-items-start gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 48 48" class="flex-shrink-0 mt-1"><path fill="#FFC107" d="M43.6 20.2H42V20H24v8h11.3C33.7 33.1 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.5 6.5 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.8z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.6 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.5 6.5 29.5 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.3 26.7 36 24 36c-5.2 0-9.6-3-11.3-7.2l-6.5 5C9.6 39.6 16.3 44 24 44z"/><path fill="#1976D2" d="M43.6 20.2H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.3 5.6l6.2 5.2C37 38.1 44 33 44 24c0-1.3-.1-2.7-.4-3.8z"/></svg>
                <div>
                    <strong>Welcome to AgriStack, <?= htmlspecialchars($user['name']) ?>!</strong><br>
                    Your account has been created automatically via Google Sign-In. Your Farmer ID is <strong><?= htmlspecialchars($_SESSION['farmer_id_assigned'] ?? $user['farmer_id']) ?></strong>.<br>
                    <small class="text-muted">Please complete your profile, add your mobile number, and submit your eKYC to unlock all features.</small><br>
                    <a href="profile.php" class="btn btn-primary btn-sm mt-2">
                        <i class="bi bi-person-fill me-1"></i> Complete My Profile
                    </a>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php unset($_SESSION['farmer_id_assigned']); ?>

        <h5 class="mt-4 mb-3">Progress Tracker</h5>
        <div class="d-flex justify-content-between text-center mb-5 overflow-auto pb-3">
            <div class="border p-2 bg-success text-white rounded"><i class="bi bi-check-circle"></i><br><small>Registered</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= $profile ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-person"></i><br><small>Profile</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($ekyc_status === 'Aadhaar document verified') ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-fingerprint"></i><br><small>eKYC</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($farms_count>0) ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-geo-alt"></i><br><small>Farms</small></div>
            <div><i class="bi bi-arrow-right fs-3"></i></div>
            <div class="border p-2 <?= ($app_count>0) ? 'bg-success text-white' : 'bg-light text-muted' ?> rounded"><i class="bi bi-ui-checks"></i><br><small>Schemes</small></div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0 shadow-sm">
                    <div class="card-body d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="text-muted text-uppercase mb-0">eKYC Status</h6>
                                <?php if($ekyc_status === 'Aadhaar document verified'): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">Verified Doc</span>
                                <?php elseif($ekyc_status === 'demo_completed'): ?>
                                    <span class="badge bg-warning-subtle text-dark border border-warning-subtle">Demo File</span>
                                <?php endif; ?>
                            </div>
                            <?php if($ekyc_status === 'demo_completed'): ?>
                                <h5 class="mb-1 text-warning fw-bold">DEMO — Not Aadhaar verified</h5>
                            <?php else: ?>
                                <h5 class="mb-1 text-primary fw-bold"><?= htmlspecialchars($ekyc_status) ?></h5>
                            <?php endif; ?>
                            <?php if($ekyc_record): ?>
                                <small class="text-muted d-block mb-1">Holder Check: <strong><?= htmlspecialchars($ekyc_holder_status) ?></strong></small>
                                <?php if(!empty($ekyc_record['aadhaar_last4'])): ?>
                                    <small class="font-monospace text-muted d-block">Aadhaar: XXXX-XXXX-<?= htmlspecialchars($ekyc_record['aadhaar_last4']) ?></small>
                                <?php endif; ?>
                            <?php else: ?>
                                <small class="text-muted d-block mb-2">Paperless XML / Secure QR</small>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3">
                            <a href="ekyc.php" class="btn btn-sm btn-outline-primary w-100">
                                <i class="bi bi-fingerprint me-1"></i><?= ($ekyc_status === 'Aadhaar document verified') ? 'View e-KYC Details' : 'Complete e-KYC' ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0">
                    <div class="card-body">
                        <h6 class="text-muted text-uppercase mb-2">Registered Farms</h6>
                        <h4 class="mb-0 text-success"><?= $farms_count ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card dashboard-card h-100 border-0">
                    <div class="card-body">
                        <h6 class="text-muted text-uppercase mb-2">Scheme Applications</h6>
                        <h4 class="mb-0 text-warning"><?= $app_count ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Applications & Digital Sign Section -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span class="fw-bold fs-6"><i class="bi bi-file-earmark-check me-2 text-primary"></i>Recent Applications &amp; Digital Sign</span>
                <a href="https://demo.emsigner.com/" class="btn btn-sm btn-outline-success">
                    <i class="bi bi-pen me-1"></i>Open emSigner Platform
                </a>
            </div>
            <div class="card-body p-0">
                <?php if(!empty($recentApps)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>App ID</th>
                                    <th>Scheme Name</th>
                                    <th>Applied Date</th>
                                    <th>Application Status</th>
                                    <th>eSign Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recentApps as $app): ?>
                                <tr>
                                    <td class="fw-bold font-monospace"><?= htmlspecialchars($app['application_id']) ?></td>
                                    <td><?= htmlspecialchars($app['scheme_name']) ?></td>
                                    <td><?= date('d M Y', strtotime($app['applied_at'])) ?></td>
                                    <td>
                                        <?php 
                                            $bClass = 'bg-secondary';
                                            if($app['status'] === 'Approved') $bClass = 'bg-success';
                                            if($app['status'] === 'Rejected') $bClass = 'bg-danger';
                                            if($app['status'] === 'Under Review') $bClass = 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?= $bClass ?>"><?= htmlspecialchars($app['status']) ?></span>
                                    </td>
                                    <td>
                                        <?php if($app['esign_status'] === 'Verified Signed'): ?>
                                            <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Verified Signed</span>
                                        <?php elseif($app['esign_status'] === 'Demo Signed'): ?>
                                            <span class="badge bg-warning text-dark"><i class="bi bi-pen me-1"></i>Demo Signed</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not Signed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($app['esign_status'] === 'Verified Signed'): ?>
                                            <span class="text-success small fw-semibold"><i class="bi bi-check2-circle me-1"></i>Complete</span>
                                        <?php else: ?>
                                            <a href="https://demo.emsigner.com/" class="btn btn-sm btn-success">
                                                <i class="bi bi-pen me-1"></i>Digital Sign
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">
                        <p class="mb-2">No scheme applications submitted yet.</p>
                        <a href="schemes.php" class="btn btn-sm btn-primary">
                            <i class="bi bi-journal-plus me-1"></i>Browse &amp; Apply Schemes
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-light py-2 text-muted small">
                <i class="bi bi-info-circle me-1"></i> Clicking <strong>Digital Sign</strong> navigates directly to the external emSigner platform (<strong>https://demo.emsigner.com/</strong>). Opening the external site does not mark documents as signed. Signing status updates require backend verification.
            </div>
        </div>

        <!-- Market Transactions & emSigner Agreements Section -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span class="fw-bold fs-6"><i class="bi bi-receipt me-2 text-success"></i>Market Transactions &amp; emSigner Agreements</span>
                <div class="d-flex gap-2">
                    <a href="transactions.php" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-eye me-1"></i>View All Transactions
                    </a>
                    <a href="https://demo.emsigner.com/" target="_blank" class="btn btn-sm btn-success">
                        <i class="bi bi-pen me-1"></i>Sign in emSigner
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if(!empty($recentTx)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Code</th>
                                    <th>Buyer</th>
                                    <th>Crop &amp; Quantity</th>
                                    <th>Total Value</th>
                                    <th>Agreement Status</th>
                                    <th>Your Signature</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recentTx as $rt): 
                                    $stBadge = 'bg-warning text-dark';
                                    if ($rt['agreement_status'] === 'Fully signed') $stBadge = 'bg-success';
                                    elseif ($rt['agreement_status'] === 'Partially signed') $stBadge = 'bg-info text-dark';
                                ?>
                                <tr>
                                    <td class="font-monospace fw-bold"><?= htmlspecialchars($rt['transaction_code']) ?></td>
                                    <td><?= htmlspecialchars($rt['buyer_name']) ?></td>
                                    <td><?= htmlspecialchars($rt['crop']) ?> (<?= number_format($rt['quantity'], 2) ?> <?= htmlspecialchars($rt['quantity_unit']) ?>)</td>
                                    <td class="fw-bold text-success">₹<?= number_format($rt['total_amount'], 2) ?></td>
                                    <td>
                                        <span class="badge <?= $stBadge ?>">
                                            <?= htmlspecialchars($rt['agreement_status'] ?? 'Awaiting signatures') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if($rt['farmer_signature_status'] === 'Signed'): ?>
                                            <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="transactions.php" class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-arrow-right me-1"></i>Review &amp; Sign
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">
                        <p class="mb-2">No market transaction agreements on file.</p>
                        <a href="transactions.php" class="btn btn-sm btn-success">
                            <i class="bi bi-plus-circle me-1"></i>Initiate Transaction Agreement
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-light py-2 text-muted small">
                <i class="bi bi-shield-check me-1"></i> Confirmed agreements show <strong>“Awaiting signatures”</strong> and are marked <strong>“Fully signed”</strong> only after both farmer and admin transaction signatures are verified in emSigner for the same agreement version.
            </div>
        </div>

    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
