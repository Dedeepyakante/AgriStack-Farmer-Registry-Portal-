<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $doc_name = trim($_POST['document_name']);
    $file = $_FILES['document'];
    
    $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (in_array($ext, $allowed) && $file['size'] <= 5000000) {
        $filename = uniqid('doc_') . '.' . $ext;
        $dest = '../uploads/documents/' . $filename;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $stmt = $pdo->prepare("INSERT INTO documents (user_id, document_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $doc_name, $filename, $ext, $file['size']]);
            require_once '../includes/functions.php';
            logAudit($pdo, $user_id, 'farmer', 'Document Upload', "Uploaded document: $doc_name");
            $message = "Document uploaded successfully.";
        } else {
            $error = "Upload failed.";
        }
    } else {
        $error = "Invalid file or size exceeded.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM documents WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$docs = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Documents</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data" class="row align-items-end">
                    <div class="col-md-5">
                        <label>Document Name (e.g. Land Patta)</label>
                        <input type="text" name="document_name" class="form-control" required>
                    </div>
                    <div class="col-md-5">
                        <label>File (JPG, PNG, PDF)</label>
                        <input type="file" name="document" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">Upload</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Document Name</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($docs as $doc): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($doc['uploaded_at'])) ?></td>
                        <td><?= htmlspecialchars($doc['document_name']) ?></td>
                        <td><?= strtoupper(htmlspecialchars($doc['file_type'])) ?></td>
                        <td><?= round($doc['file_size']/1024, 2) ?> KB</td>
                        <td>
                            <a href="../uploads/documents/<?= htmlspecialchars($doc['file_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
