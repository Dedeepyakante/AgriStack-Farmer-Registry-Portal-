<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';

$user_id = getUserId();
$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$ekyc = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM scheme_applications a JOIN schemes s ON a.scheme_id = s.id WHERE a.user_id = ?");
$stmt->execute([$user_id]);
$apps = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM esignatures WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$esign = $stmt->fetch();
?>
<style>
@media print {
    .no-print { display: none !important; }
    .sidebar { display: none !important; }
    .container { max-width: 100% !important; margin: 0 !important; }
}
</style>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4 bg-white" id="printableArea">
        <div class="text-end mb-4 no-print">
            <button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer"></i> Print Farmer Dossier</button>
        </div>
        
        <div class="text-center mb-4 border-bottom pb-3">
            <h2 class="fw-bold">AgriStack Farmer Dossier</h2>
            <p class="mb-0 text-muted">Generated on <?= date('d M Y H:i:s') ?></p>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <h4><i class="bi bi-person-lines-fill text-success"></i> Basic Details</h4>
                <table class="table table-bordered table-sm">
                    <tr><th width="30%">Farmer ID</th><td><?= htmlspecialchars($profile['farmer_id']) ?></td></tr>
                    <tr><th>Name</th><td><?= htmlspecialchars($profile['name']) ?></td></tr>
                    <tr><th>Mobile / Email</th><td><?= htmlspecialchars($profile['mobile']) ?> / <?= htmlspecialchars($profile['email']) ?></td></tr>
                    <tr><th>DOB / Gender</th><td><?= htmlspecialchars($profile['dob']) ?> / <?= htmlspecialchars($profile['gender']) ?></td></tr>
                    <tr><th>Address</th><td><?= htmlspecialchars($profile['address'].', '.$profile['district'].', '.$profile['state']) ?></td></tr>
                </table>
            </div>
            <div class="col-md-4 text-center">
                <?php if($ekyc && $ekyc['extracted_photo_path']): ?>
                    <img src="../uploads/ekyc/<?= htmlspecialchars($ekyc['extracted_photo_path']) ?>" class="img-thumbnail" style="height:150px">
                <?php else: ?>
                    <div class="border p-5 text-muted bg-light"><i class="bi bi-person fs-1"></i><br>No Photo</div>
                <?php endif; ?>
                <div class="mt-2 fw-bold">eKYC Status: <span class="text-<?= $ekyc['status']=='Verified'?'success':($ekyc['status']=='Rejected'?'danger':'warning') ?>"><?= $ekyc['status'] ?? 'Not Submitted' ?></span></div>
            </div>
        </div>

        <h4 class="mt-4"><i class="bi bi-geo-alt-fill text-success"></i> Registered Farms</h4>
        <table class="table table-bordered table-sm">
            <thead><tr class="bg-light"><th>Name</th><th>Survey No</th><th>Area</th><th>Location</th><th>Geo-Tag</th></tr></thead>
            <tbody>
                <?php foreach($farms as $f): ?>
                <tr>
                    <td><?= htmlspecialchars($f['farm_name']) ?></td>
                    <td><?= htmlspecialchars($f['survey_number']) ?></td>
                    <td><?= htmlspecialchars($f['land_area'].' '.$f['land_unit']) ?></td>
                    <td><?= htmlspecialchars($f['village'].', '.$f['district']) ?></td>
                    <td><?= $f['latitude'] ? $f['latitude'].', '.$f['longitude'] : 'No' ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($farms)): ?><tr><td colspan="5">No farms registered.</td></tr><?php endif; ?>
            </tbody>
        </table>

        <h4 class="mt-4"><i class="bi bi-ui-checks text-success"></i> Applications</h4>
        <table class="table table-bordered table-sm">
            <thead><tr class="bg-light"><th>App ID</th><th>Scheme Name</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
                <?php foreach($apps as $a): ?>
                <tr>
                    <td><?= htmlspecialchars($a['application_id']) ?></td>
                    <td><?= htmlspecialchars($a['scheme_name']) ?></td>
                    <td><?= htmlspecialchars($a['status']) ?></td>
                    <td><?= date('d M Y', strtotime($a['applied_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($apps)): ?><tr><td colspan="4">No applications submitted.</td></tr><?php endif; ?>
            </tbody>
        </table>

        <div class="mt-5 border-top pt-4">
            <div class="row align-items-center">
                <div class="col-8">
                    <p class="small text-muted">This is an electronically generated academic dossier. The details are self-certified by the farmer and verified by demo admin where applicable.</p>
                </div>
                <div class="col-4 text-center">
                    <?php if($esign): ?>
                        <img src="../uploads/signatures/<?= htmlspecialchars($esign['signature_path']) ?>" style="max-height: 85px; max-width: 100%;" class="border rounded p-1 bg-white shadow-sm">
                        <br><small class="fw-semibold <?= ($esign['signature_type'] ?? '') === 'verified_provider' ? 'text-success' : 'text-secondary' ?>">
                            <?= ($esign['signature_type'] ?? '') === 'verified_provider' ? '<i class="bi bi-patch-check-fill text-success"></i> Verified Digital Signature (eMudhra eSign)' : 'Demo eSign — Not legally certified' ?>
                        </small>
                        <br><small class="text-muted"><?= date('d M Y, h:i A', strtotime($esign['signed_at'])) ?> &bull; <?= htmlspecialchars($esign['farmer_email'] ?? $profile['email'] ?? '') ?></small>
                    <?php else: ?>
                        <div class="border-bottom border-dark mt-4 mx-3"></div>
                        <small>Signature Missing</small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
