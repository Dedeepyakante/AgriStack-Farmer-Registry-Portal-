<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../config/csrf.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();

// Fetch latest verification status for this farmer
$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC LIMIT 1");
$stmt->execute([$user_id]);
$latest_ekyc = $stmt->fetch();

// Fetch all verification attempts for history
$stmt = $pdo->prepare("SELECT * FROM identity_verifications WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$ekyc_history = $stmt->fetchAll();

$flash_success = $_SESSION['ekyc_success'] ?? '';
$flash_error   = $_SESSION['ekyc_error'] ?? '';
unset($_SESSION['ekyc_success'], $_SESSION['ekyc_error']);

$csrfToken = getCsrfToken();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="mb-4">
            <h2 class="mb-1"><i class="bi bi-fingerprint text-success me-2"></i>Aadhaar Offline e-KYC Verification</h2>
            <p class="text-muted mb-0">UIDAI-Compliant Paperless Offline e-KYC Verification</p>
        </div>

        <?php if($flash_success): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($flash_error): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Dynamic Result Alert Box (for AJAX responses) -->
        <div id="dynamic-alert" class="d-none alert shadow-sm" role="alert"></div>

        <!-- Current Verification Status Card -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0"><i class="bi bi-shield-check text-primary me-2"></i>Current Verification Status</h5>
            </div>
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-3 mb-3 mb-md-0 text-center border-end">
                        <small class="text-muted text-uppercase fw-semibold d-block mb-1">Document Status</small>
                        <?php
                            $docStatus = $latest_ekyc['verification_status'] ?? 'Not started';
                            $badgeClass = 'bg-secondary';
                            $displayDocStatus = htmlspecialchars($docStatus);
                            if ($docStatus === 'Aadhaar document verified') {
                                $badgeClass = 'bg-success';
                            } elseif ($docStatus === 'demo_completed') {
                                $badgeClass = 'bg-warning text-dark';
                                $displayDocStatus = 'DEMO — Not Aadhaar verified';
                            } elseif ($docStatus === 'Failed') {
                                $badgeClass = 'bg-danger';
                            } elseif ($docStatus === 'Processing') {
                                $badgeClass = 'bg-warning text-dark';
                            }
                        ?>
                        <span class="badge <?= $badgeClass ?> fs-6 py-2 px-3"><?= $displayDocStatus ?></span>
                    </div>

                    <div class="col-md-3 mb-3 mb-md-0 text-center border-end">
                        <small class="text-muted text-uppercase fw-semibold d-block mb-1">Holder Identity Check</small>
                        <?php
                            $holderStatus = $latest_ekyc['holder_check_status'] ?? 'Not started';
                            $hBadge = ($holderStatus === 'Verified') ? 'bg-success' : (($holderStatus === 'Holder check pending') ? 'bg-warning text-dark' : 'bg-secondary');
                        ?>
                        <span class="badge <?= $hBadge ?> fs-6 py-2 px-3"><?= htmlspecialchars($holderStatus) ?></span>
                    </div>

                    <div class="col-md-3 mb-3 mb-md-0 text-center border-end">
                        <small class="text-muted text-uppercase fw-semibold d-block mb-1">Masked Aadhaar</small>
                        <span class="font-monospace fs-6 fw-bold">
                            <?= !empty($latest_ekyc['aadhaar_last4']) ? 'XXXX-XXXX-' . htmlspecialchars($latest_ekyc['aadhaar_last4']) : 'Not Available' ?>
                        </span>
                    </div>

                    <div class="col-md-3 text-center">
                        <small class="text-muted text-uppercase fw-semibold d-block mb-1">Latest Attempt Ref</small>
                        <span class="font-monospace small text-muted">
                            <?= htmlspecialchars($latest_ekyc['attempt_ref'] ?? 'None') ?>
                        </span>
                    </div>
                </div>

                <div class="alert alert-light border mt-3 mb-0 py-2 small text-muted">
                    <i class="bi bi-info-circle me-1 text-primary"></i>
                    <strong>Verification Distinction:</strong> A valid cryptographic digital signature from UIDAI verifies the <em>authenticity and integrity of the Aadhaar document</em>. It does not by itself establish that the person uploading it is the Aadhaar holder (tracked as <strong>Holder check pending</strong>), nor does it grant crop cultivator or land ownership rights.
                </div>
            </div>
        </div>

        <!-- Verification Form -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 fw-semibold text-dark">
                    <i class="bi bi-file-earmark-code text-success me-2"></i>Aadhaar Paperless Offline XML / ZIP Verification
                </h5>
            </div>
            
            <div class="card-body p-4">
                
                <!-- Mandatory Consent & Privacy Disclosure -->
                <div class="p-3 mb-4 rounded bg-light border">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-lock-fill text-success me-2"></i>Privacy Disclosure &amp; Explicit Consent</h6>
                    <p class="small text-muted mb-2">
                        In compliance with UIDAI regulations and privacy standards:
                    </p>
                    <ul class="small text-muted mb-3 ps-3">
                        <li><strong>Processed Information:</strong> Only demographic information covered by UIDAI's digital signature (Name, Date of Birth, Gender, Address, and masked Aadhaar last 4 digits) will be processed for identity verification.</li>
                        <li><strong>No Retention of Sensitive Artifacts:</strong> AgriLink does <em>not</em> store your full 12-digit Aadhaar number, biometric data, raw XML/ZIP archives, or Share Codes. Uploaded files are processed in volatile memory and deleted immediately.</li>
                        <li><strong>Backend Cryptography:</strong> All digital signatures are validated on the backend against authoritative UIDAI certificates.</li>
                    </ul>
                    
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="consent_checkbox" required>
                        <label class="form-check-label fw-semibold small" for="consent_checkbox">
                            I give my voluntary, explicit consent to process my Aadhaar Paperless Offline e-KYC data solely for farmer identity verification on AgriLink.
                        </label>
                    </div>
                </div>

                <!-- Offline XML / ZIP Verification Form -->
                <form id="form-xml" action="verify_ekyc_handler.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    <input type="hidden" name="verification_method" value="offline_xml">
                    <input type="hidden" name="consent_terms" value="1">
                    <input type="hidden" name="is_ajax" value="1">

                    <div class="row g-3">
                        <div class="col-md-7">
                            <label class="form-label fw-semibold">Aadhaar Paperless Offline XML or ZIP File <span class="text-danger">*</span></label>
                            <input type="file" name="ekyc_file" id="ekyc_file" class="form-control" accept=".zip,.xml" required>
                            <div class="form-text">
                                Upload the signed XML file or password-protected ZIP downloaded from the official <a href="https://myaadhaar.uidai.gov.in/" target="_blank" rel="noopener">myAadhaar portal</a>. Max upload size: 5MB.
                            </div>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label fw-semibold">Share Code (Passcode)</label>
                            <input type="password" name="share_code" id="share_code" class="form-control" placeholder="e.g. 4-character code" autocomplete="off">
                            <div class="form-text">
                                Per UIDAI specification: Required to decrypt password-protected ZIP archives.
                            </div>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" id="btn-submit-xml" class="btn btn-success px-4 fw-semibold">
                            <span class="spinner-border spinner-border-sm me-2 d-none" role="status"></span>
                            <i class="bi bi-shield-check me-1"></i>Verify Offline XML / ZIP
                        </button>
                    </div>
                </form>

            </div>
        </div>

        <!-- Verification History Table -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0"><i class="bi bi-clock-history me-2 text-secondary"></i>Verification History</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Date &amp; Time</th>
                                <th>Method</th>
                                <th>Doc Status</th>
                                <th>Holder Check</th>
                                <th>Masked Aadhaar</th>
                                <th>Signature Trust</th>
                                <th>Attempt Ref</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($ekyc_history)): ?>
                                <?php foreach($ekyc_history as $hist): ?>
                                <tr>
                                    <td><?= date('d M Y, H:i', strtotime($hist['submitted_at'])) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border">
                                            <?= htmlspecialchars($hist['verification_method'] ?? 'offline_xml') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                            $vS = $hist['verification_status'] ?? $hist['status'];
                                            $bCls = 'bg-secondary';
                                            $dispHist = htmlspecialchars($vS);
                                            if ($vS === 'Aadhaar document verified') {
                                                $bCls = 'bg-success';
                                            } elseif ($vS === 'demo_completed') {
                                                $bCls = 'bg-warning text-dark';
                                                $dispHist = 'DEMO — Not Aadhaar verified';
                                            } elseif ($vS === 'Failed' || $vS === 'Rejected') {
                                                $bCls = 'bg-danger';
                                            } elseif ($vS === 'Processing') {
                                                $bCls = 'bg-warning text-dark';
                                            }
                                        ?>
                                        <span class="badge <?= $bCls ?>"><?= $dispHist ?></span>
                                    </td>
                                    <td>
                                        <?php 
                                            $hS = $hist['holder_check_status'] ?? 'Holder check pending';
                                            $hCls = ($hS === 'Verified') ? 'bg-success' : 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?= $hCls ?>"><?= htmlspecialchars($hS) ?></span>
                                    </td>
                                    <td class="font-monospace">
                                        <?= !empty($hist['aadhaar_last4']) ? 'XXXX-' . htmlspecialchars($hist['aadhaar_last4']) : '-' ?>
                                    </td>
                                    <td>
                                        <small class="badge bg-light text-muted border">
                                            <?= htmlspecialchars($hist['uidai_sig_status'] ?? 'N/A') ?>
                                        </small>
                                    </td>
                                    <td class="font-monospace small text-muted">
                                        <?= htmlspecialchars($hist['attempt_ref'] ?? '-') ?>
                                    </td>
                                    <td class="small text-muted" style="max-width: 250px;">
                                        <?= htmlspecialchars($hist['admin_remarks'] ?? '-') ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4 text-muted">
                                        No e-KYC attempts recorded yet.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function() {
    const consentCheckbox = document.getElementById('consent_checkbox');
    const dynamicAlert    = document.getElementById('dynamic-alert');

    function showAlert(type, message) {
        dynamicAlert.className = 'alert alert-' + type + ' alert-dismissible fade show shadow-sm mb-4';
        dynamicAlert.innerHTML = '<i class="bi ' + (type === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill') + ' me-2"></i>' +
                                 message +
                                 '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
        dynamicAlert.classList.remove('d-none');
        dynamicAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // =========================================================================
    // Tab 1: XML / ZIP Form Submission via AJAX
    // =========================================================================
    const formXml = document.getElementById('form-xml');
    const btnSubmitXml = document.getElementById('btn-submit-xml');

    formXml.addEventListener('submit', function(e) {
        e.preventDefault();

        if (!consentCheckbox.checked) {
            showAlert('warning', 'Please provide explicit consent before proceeding with verification.');
            consentCheckbox.focus();
            return;
        }

        const fileInput = document.getElementById('ekyc_file');
        if (!fileInput.files || fileInput.files.length === 0) {
            showAlert('danger', 'Please select an Aadhaar offline XML or ZIP file.');
            return;
        }

        const formData = new FormData(formXml);
        btnSubmitXml.disabled = true;
        btnSubmitXml.querySelector('.spinner-border').classList.remove('d-none');

        fetch('verify_ekyc_handler.php', {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(res => res.json())
        .then(data => {
            btnSubmitXml.disabled = false;
            btnSubmitXml.querySelector('.spinner-border').classList.add('d-none');

            if (data.success) {
                if (data.verification_status === 'demo_completed' || data.is_demo) {
                    showAlert('warning', '<strong>DEMO — Not Aadhaar verified</strong>' + 
                                         '<div class="mt-2 p-2 bg-white rounded border text-dark small">' +
                                         '<strong>Fictional Farmer Details Preview:</strong><br>' +
                                         '&bull; <strong>Name:</strong> ' + (data.name || 'Demo Farmer') + '<br>' +
                                         '&bull; <strong>DOB / Gender:</strong> ' + (data.dob || 'N/A') + ' / ' + (data.gender || 'N/A') + '<br>' +
                                         '&bull; <strong>Masked Aadhaar:</strong> XXXX-XXXX-' + (data.aadhaar_last4 || '') + '<br>' +
                                         '&bull; <strong>Address:</strong> ' + (data.address || 'N/A') + '<br>' +
                                         (data.phone ? '&bull; <strong>Phone:</strong> ' + data.phone + '<br>' : '') +
                                         (data.email ? '&bull; <strong>Email:</strong> ' + data.email + '<br>' : '') +
                                         '&bull; <strong>Attempt Ref:</strong> ' + (data.attempt_ref || '') +
                                         '</div>' +
                                         '<div class="mt-1 text-muted small"><i class="bi bi-info-circle me-1"></i>Simulated demonstration file. Genuine identity verification was not performed and verified actions remain locked.</div>');
                } else {
                    showAlert('success', '<strong>' + data.verification_status + '</strong>: ' + data.message + 
                                         '<br><small class="text-dark">Masked Aadhaar: XXXX-XXXX-' + (data.aadhaar_last4 || '') + ' | Ref: ' + (data.attempt_ref || '') + '</small>');
                }
                setTimeout(() => window.location.reload(), 2500);
            } else {
                showAlert('danger', '<strong>Verification Failed</strong>: ' + (data.message || 'Signature verification error.'));
            }
        })
        .catch(err => {
            btnSubmitXml.disabled = false;
            btnSubmitXml.querySelector('.spinner-border').classList.add('d-none');
            showAlert('danger', 'Server communication error: ' + err.message);
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
