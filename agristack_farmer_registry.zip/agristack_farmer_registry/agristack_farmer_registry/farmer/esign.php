<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../config/esign.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();

// Retrieve farmer account information
$stmt = $pdo->prepare("SELECT id, name, email, mobile, farmer_id FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$farmer = $stmt->fetch();

// Retrieve farmer's scheme applications for status display
$appStmt = $pdo->prepare("SELECT a.application_id, s.scheme_name, a.status, a.esign_status, a.applied_at 
                          FROM scheme_applications a 
                          JOIN schemes s ON a.scheme_id = s.id 
                          WHERE a.user_id = ? 
                          ORDER BY a.id DESC");
$appStmt->execute([$user_id]);
$applications = $appStmt->fetchAll();

// Retrieve farmer's market transactions
$txList = getFarmerMarketTransactions($pdo, $user_id);

// Fetch recorded signatures for this farmer if any exist
$sList = $pdo->prepare("SELECT * FROM esignatures WHERE user_id = ? ORDER BY id DESC");
$sList->execute([$user_id]);
$signatures = $sList->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="mb-0">Digital Signature (eSign)</h2>
                <small class="text-muted">External emSigner Platform Integration &bull; IT Act 2000</small>
            </div>
            <a href="https://demo.emsigner.com/" class="btn btn-success fw-semibold shadow-sm">
                <i class="bi bi-pen me-1"></i>Digital Sign
            </a>
        </div>

        <!-- External emSigner Platform Information Card -->
        <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #0b2545 0%, #134074 100%); color: #ffffff;">
            <div class="card-body p-4">
                <div class="d-flex align-items-start gap-3">
                    <span class="badge bg-white text-dark p-2 rounded-circle fs-3 flex-shrink-0">
                        <i class="bi bi-shield-lock-fill text-primary"></i>
                    </span>
                    <div>
                        <h5 class="fw-bold mb-1">External Digital Signature Platform (emSigner)</h5>
                        <p class="mb-2 opacity-90 small">
                            The signing interface and digital signing operations take place on the external <strong>emSigner</strong> platform (<strong>https://demo.emsigner.com/</strong>).
                        </p>
                        <p class="mb-0 opacity-90 small">
                            <strong>Important:</strong> Opening the emSigner website does not mark a document as signed. Document signing status is updated only after the backend verifies a successful signing result from the provider and matches it to the correct farmer and document.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Direct Action Card -->
        <div class="card shadow-sm border-0 mb-4 border-top border-success border-4">
            <div class="card-body p-4">
                <div class="row align-items-center">
                    <div class="col-lg-8">
                        <h5 class="fw-bold mb-1">Proceed to Digital Sign</h5>
                        <p class="text-muted small mb-3">
                            Clicking <strong>Digital Sign</strong> will navigate directly to <code>https://demo.emsigner.com/</code> in this browser tab. All signing operations (Aadhaar eSign / digital certificate affixing) must be performed on the external platform.
                        </p>
                        <div class="d-flex align-items-center gap-2 small text-muted">
                            <span class="badge bg-light text-dark border">Signer: <?= htmlspecialchars($farmer['name']) ?></span>
                            <span class="badge bg-light text-dark border">Email: <?= htmlspecialchars($farmer['email'] ?? 'N/A') ?></span>
                            <span class="badge bg-light text-dark border">Farmer ID: <?= htmlspecialchars($farmer['farmer_id']) ?></span>
                        </div>
                    </div>
                    <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                        <a href="https://demo.emsigner.com/" class="btn btn-success btn-lg px-4 py-3 fw-bold shadow-sm">
                            <i class="bi bi-pen me-2"></i>Digital Sign
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Scheme Applications & Current Signing Status -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3">
                <i class="bi bi-ui-checks me-2 text-primary"></i>My Applications &amp; Signing Status
            </div>
            <div class="card-body p-0">
                <?php if(!empty($applications)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>App ID</th>
                                    <th>Scheme Name</th>
                                    <th>Submission Date</th>
                                    <th>Application Status</th>
                                    <th>eSign Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($applications as $app): ?>
                                <tr>
                                    <td class="fw-bold font-monospace"><?= htmlspecialchars($app['application_id']) ?></td>
                                    <td><?= htmlspecialchars($app['scheme_name']) ?></td>
                                    <td><?= date('d M Y', strtotime($app['applied_at'])) ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= htmlspecialchars($app['status']) ?></span>
                                    </td>
                                    <td>
                                        <?php if($app['esign_status'] === 'Verified Signed'): ?>
                                            <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Verified Signed</span>
                                        <?php elseif($app['esign_status'] === 'Demo Signed'): ?>
                                            <span class="badge bg-warning text-dark"><i class="bi bi-pen me-1"></i>Demo Signed</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not Signed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($app['esign_status'] === 'Verified Signed'): ?>
                                            <span class="text-success small fw-semibold"><i class="bi bi-check2-circle me-1"></i>Complete</span>
                                        <?php else: ?>
                                            <a href="https://demo.emsigner.com/" class="btn btn-sm btn-success">
                                                <i class="bi bi-pen me-1"></i>Digital Sign
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">
                        <p class="mb-0">No scheme applications on file.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Market Transaction Agreements & Current Signing Status -->
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span class="fw-bold"><i class="bi bi-receipt me-2 text-success"></i>My Market Transaction Agreements</span>
                <a href="transactions.php" class="btn btn-sm btn-outline-success">
                    <i class="bi bi-arrow-right me-1"></i>Manage &amp; Sign Transactions
                </a>
            </div>
            <div class="card-body p-0">
                <?php if(!empty($txList)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>TX Code</th>
                                    <th>Buyer</th>
                                    <th>Crop &amp; Quantity</th>
                                    <th>Value</th>
                                    <th>Version</th>
                                    <th>Agreement Status</th>
                                    <th>Farmer eSign</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($txList as $tx): 
                                    $agr = $tx['active_agreement'];
                                    $stBadge = 'bg-warning text-dark';
                                    if ($agr && $agr['agreement_status'] === 'Fully signed') $stBadge = 'bg-success';
                                    elseif ($agr && $agr['agreement_status'] === 'Partially signed') $stBadge = 'bg-info text-dark';
                                ?>
                                <tr>
                                    <td class="fw-bold font-monospace"><?= htmlspecialchars($tx['transaction_code']) ?></td>
                                    <td><?= htmlspecialchars($tx['buyer_name']) ?></td>
                                    <td><?= htmlspecialchars($tx['crop']) ?> (<?= number_format($tx['quantity'], 2) ?> <?= htmlspecialchars($tx['quantity_unit']) ?>)</td>
                                    <td class="fw-bold text-success">₹<?= number_format($tx['total_amount'], 2) ?></td>
                                    <td><span class="badge bg-dark">v<?= $agr ? $agr['version'] : $tx['current_version'] ?></span></td>
                                    <td><span class="badge <?= $stBadge ?>"><?= htmlspecialchars($agr['agreement_status'] ?? 'Awaiting signatures') ?></span></td>
                                    <td>
                                        <?php if($agr && $agr['farmer_signature_status'] === 'Signed'): ?>
                                            <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Pending</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="transactions.php" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye me-1"></i>View / Sign
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="p-4 text-center text-muted">
                        <p class="mb-2">No market transaction agreements on file.</p>
                        <a href="transactions.php" class="btn btn-sm btn-success">
                            <i class="bi bi-plus-circle me-1"></i>Go to Transactions
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Verified Signatures on File (if backend has verified records) -->
        <?php if(!empty($signatures)): ?>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-header bg-white py-3">
                <i class="bi bi-clock-history me-2 text-primary"></i>Verified Signatures on File
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Timestamp</th>
                                <th>Provider</th>
                                <th>Signer Email</th>
                                <th>Signing Target / Action</th>
                                <th>Reference ID</th>
                                <th>Status</th>
                                <th>Preview</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($signatures as $s): 
                                $targetDesc = 'Dossier / Scheme';
                                if (!empty($s['signing_action'])) {
                                    if ($s['signing_action'] === 'farmer_transaction') {
                                        $targetDesc = 'Transaction Agreement v' . ($s['agreement_version'] ?? '1');
                                    } elseif ($s['signing_action'] === 'admin_transaction') {
                                        $targetDesc = 'Admin Transaction Agreement v' . ($s['agreement_version'] ?? '1');
                                    } elseif ($s['signing_action'] === 'admin_document_approval') {
                                        $targetDesc = 'Document #' . ($s['document_id'] ?? '');
                                    } elseif (!empty($s['application_id'])) {
                                        $targetDesc = 'Scheme App ' . $s['application_id'];
                                    }
                                } elseif (!empty($s['application_id'])) {
                                    $targetDesc = 'Scheme App ' . $s['application_id'];
                                }
                            ?>
                            <tr>
                                <td><?= date('d M Y, h:i A', strtotime($s['signed_at'])) ?></td>
                                <td><?= htmlspecialchars($s['provider_name'] ?? 'emSigner') ?></td>
                                <td><?= htmlspecialchars($s['farmer_email'] ?? $farmer['email'] ?? 'N/A') ?></td>
                                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($targetDesc) ?></span></td>
                                <td class="font-monospace small"><?= htmlspecialchars($s['provider_ref_id'] ?? 'N/A') ?></td>
                                <td><span class="badge bg-success-subtle text-success"><?= htmlspecialchars($s['signing_status']) ?></span></td>
                                <td>
                                    <?php if(!empty($s['signature_path'])): ?>
                                        <a href="../uploads/signatures/<?= htmlspecialchars($s['signature_path']) ?>" target="_blank" class="btn btn-sm btn-outline-primary py-0">View</a>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
