<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $farm_name = trim($_POST['farm_name']);
    $survey_number = trim($_POST['survey_number']);
    $village = trim($_POST['village']);
    $mandal = trim($_POST['mandal']);
    $district = trim($_POST['district']);
    $state = trim($_POST['state']);
    $land_area = $_POST['land_area'];
    $land_unit = $_POST['land_unit'];
    $ownership_type = $_POST['ownership_type'];
    $crop_type = trim($_POST['crop_type']);
    $irrigation = trim($_POST['irrigation_type']);
    
    $stmt = $pdo->prepare("INSERT INTO farms (user_id, farm_name, survey_number, village, mandal, district, state, land_area, land_unit, ownership_type, crop_type, irrigation_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$user_id, $farm_name, $survey_number, $village, $mandal, $district, $state, $land_area, $land_unit, $ownership_type, $crop_type, $irrigation]);
    
    require_once '../includes/functions.php';
    logAudit($pdo, $user_id, 'farmer', 'Farm Registered', "Farm '$farm_name' registered.");
    $message = "Farm registered successfully.";
}

$stmt = $pdo->prepare("SELECT * FROM farms WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Farm Registry</h2>
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="mb-4 text-end">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addFarmModal"><i class="bi bi-plus-circle"></i> Add Farm</button>
        </div>

        <div class="row">
            <?php foreach($farms as $farm): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 border-start border-4 border-success h-100">
                    <div class="card-body">
                        <h5 class="card-title text-success"><?= htmlspecialchars($farm['farm_name']) ?></h5>
                        <p class="mb-1"><strong>Survey No:</strong> <?= htmlspecialchars($farm['survey_number']) ?></p>
                        <p class="mb-1"><strong>Location:</strong> <?= htmlspecialchars($farm['village'].', '.$farm['mandal'].', '.$farm['district']) ?></p>
                        <p class="mb-1"><strong>Area:</strong> <?= htmlspecialchars($farm['land_area'].' '.$farm['land_unit']) ?> (<?= $farm['ownership_type'] ?>)</p>
                        <p class="mb-2"><strong>Crop:</strong> <?= htmlspecialchars($farm['crop_type']) ?> | <strong>Irrigation:</strong> <?= htmlspecialchars($farm['irrigation_type']) ?></p>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <?php if($farm['latitude'] && $farm['longitude']): ?>
                                <span class="badge bg-success"><i class="bi bi-geo-alt-fill"></i> Geo-Tagged (<?= round($farm['latitude'],4) ?>, <?= round($farm['longitude'],4) ?>)</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark"><i class="bi bi-geo-alt"></i> Not Geo-Tagged</span>
                            <?php endif; ?>
                            <a href="geotag.php?farm_id=<?= $farm['id'] ?>" class="btn btn-sm btn-outline-success">
                                <i class="bi bi-pin-map"></i> <?= $farm['latitude'] ? 'Update Tag' : 'Tag Now' ?>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if(empty($farms)): ?>
                <div class="col-12"><div class="alert alert-info">No farms registered yet. Click "Add Farm" to begin.</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add Farm Modal -->
<div class="modal fade" id="addFarmModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Register New Farm</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="post">
      <div class="modal-body row">
          <div class="col-md-6 mb-3"><label>Farm Name (Identifier)</label><input type="text" name="farm_name" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Survey Number / Khata No</label><input type="text" name="survey_number" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Village</label><input type="text" name="village" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>Mandal/Taluk</label><input type="text" name="mandal" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>District</label><input type="text" name="district" class="form-control" required></div>
          <div class="col-md-6 mb-3"><label>State</label><input type="text" name="state" class="form-control" required></div>
          <div class="col-md-4 mb-3"><label>Land Area</label><input type="number" step="0.01" name="land_area" class="form-control" required></div>
          <div class="col-md-4 mb-3"><label>Unit</label><select name="land_unit" class="form-select" required><option>Acres</option><option>Hectares</option></select></div>
          <div class="col-md-4 mb-3"><label>Ownership</label><select name="ownership_type" class="form-select" required><option>Owned</option><option>Leased</option></select></div>
          <div class="col-md-6 mb-3"><label>Current Crop</label><input type="text" name="crop_type" class="form-control"></div>
          <div class="col-md-6 mb-3"><label>Irrigation Source</label><input type="text" name="irrigation_type" class="form-control"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-success">Save Farm</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
