<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../config/patta.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';
$error   = '';

// ── 1. Handle geo-tag save ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_location') {
    $farm_id = (int)$_POST['farm_id'];
    $lat     = trim($_POST['lat']);
    $lng     = trim($_POST['lng']);

    if (!is_numeric($lat) || !is_numeric($lng) ||
        $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        $error = 'Invalid coordinates. Please select a location on the map or use GPS capture.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM farms WHERE id = ? AND user_id = ?");
        $stmt->execute([$farm_id, $user_id]);
        if ($stmt->fetch()) {
            $upd = $pdo->prepare("UPDATE farms SET latitude = ?, longitude = ? WHERE id = ?");
            $upd->execute([$lat, $lng, $farm_id]);
            logAudit($pdo, $user_id, 'farmer', 'Geo-Tagging',
                "Farm ID $farm_id geo-tagged at lat=$lat, lng=$lng.");
            $message = '✅ Location saved successfully! You can now generate the Land Patta QR below.';
        } else {
            $error = 'Farm not found or access denied.';
        }
    }
}

// ── 2. Handle Land Patta QR token generation ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate_patta_qr') {
    $farm_id = (int)$_POST['farm_id'];
    $force   = ($_POST['force_regen'] ?? '0') === '1'; // explicit regeneration request

    $stmt = $pdo->prepare("SELECT id, qr_token, latitude FROM farms WHERE id = ? AND user_id = ?");
    $stmt->execute([$farm_id, $user_id]);
    $frow = $stmt->fetch();

    if (!$frow) {
        $error = 'Farm not found or access denied.';
    } elseif (empty($frow['latitude'])) {
        $error = 'Please save the farm geo-location before generating a Land Patta QR.';
    } elseif (!empty($frow['qr_token']) && !$force) {
        // Reuse existing valid token — do NOT regenerate unnecessarily
        $message = '✅ Land Patta QR already exists for this farm. Use the existing QR below.';
    } else {
        // Generate a fresh cryptographically secure 64-character token
        $token = bin2hex(random_bytes(32));
        $pdo->prepare("UPDATE farms SET qr_token = ?, qr_generated_at = NOW() WHERE id = ?")
            ->execute([$token, $farm_id]);
        logAudit($pdo, $user_id, 'farmer', 'Patta QR Generated', "QR token created for Farm ID $farm_id.");
        $message = $force
            ? '🔄 Land Patta QR regenerated. Old QR is now invalid.'
            : '🔐 Land Patta QR generated successfully!';
    }
}

// ── 3. Load farms & selected farm ───────────────────────────────────────────
// Determine the farm being viewed (POST > GET > first farm)
$farm_id_sel = (int)($_POST['farm_id'] ?? $_GET['farm_id'] ?? 0);

// Reload full farm record from DB (so any token update is fresh)
$selected_farm = null;
if ($farm_id_sel > 0) {
    $s = $pdo->prepare("SELECT * FROM farms WHERE id = ? AND user_id = ?");
    $s->execute([$farm_id_sel, $user_id]);
    $selected_farm = $s->fetch() ?: null;
}

// Load all farms (always fresh)
$stmt_all = $pdo->prepare("SELECT * FROM farms WHERE user_id = ? ORDER BY created_at DESC");
$stmt_all->execute([$user_id]);
$all_farms = $stmt_all->fetchAll();

// Default to first farm if nothing selected
if (!$selected_farm && !empty($all_farms)) {
    $selected_farm = $all_farms[0];
    $farm_id_sel   = $selected_farm['id'];
}

// Build patta QR URL for the selected farm
$patta_qr_url = '';
if ($selected_farm && !empty($selected_farm['qr_token'])) {
    $patta_qr_url = buildPattaQrUrl(
        $selected_farm['qr_token'],
        $selected_farm['survey_number'] ?? ''
    );
}
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">

        <h2 class="mb-1"><i class="bi bi-pin-map-fill text-success me-2"></i>Farm Geo-Tagging</h2>
        <p class="text-muted mb-4">
            Capture your farm's GPS location, save it, then generate a secure
            <strong>Land Patta QR</strong> for instant mobile verification.
        </p>

        <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (empty($all_farms)): ?>
            <div class="alert alert-warning">
                You have no farms registered yet. <a href="farms.php">Register a farm first</a>.
            </div>
        <?php else: ?>

        <!-- ═══════════════════════════════════════════════════════════════ -->
        <!--  MAP + FORM                                                     -->
        <!-- ═══════════════════════════════════════════════════════════════ -->
        <div class="row g-4">

            <!-- Left: Location form -->
            <div class="col-md-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-success text-white fw-bold">
                        <i class="bi bi-pin-map-fill me-2"></i>Tag Farm Location
                    </div>
                    <div class="card-body">
                        <form method="post" id="geoForm">
                            <input type="hidden" name="action" value="save_location">

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Select Farm</label>
                                <select name="farm_id" id="farmSelect" class="form-select" required>
                                    <?php foreach ($all_farms as $f): ?>
                                    <option value="<?= $f['id'] ?>"
                                        data-lat="<?= $f['latitude'] ?? '' ?>"
                                        data-lng="<?= $f['longitude'] ?? '' ?>"
                                        <?= ($farm_id_sel == $f['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($f['farm_name']) ?>
                                        (<?= htmlspecialchars($f['survey_number']) ?>)
                                        <?= $f['latitude'] ? ' ✅' : ' ⬜' ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">✅ = geo-tagged &nbsp; ⬜ = not tagged</div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Search Location</label>
                                <div class="input-group">
                                    <input type="text" id="searchBox" class="form-control"
                                           placeholder="e.g. Guntur, Andhra Pradesh">
                                    <button type="button" class="btn btn-outline-primary" onclick="searchPlace()">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </div>
                                <div class="form-text">Type a village / district / state name</div>
                            </div>

                            <div class="mb-2">
                                <label class="form-label fw-semibold">Latitude</label>
                                <input type="text" id="lat" name="lat" class="form-control"
                                    placeholder="e.g. 16.5062"
                                    value="<?= htmlspecialchars($selected_farm['latitude'] ?? '') ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Longitude</label>
                                <input type="text" id="lng" name="lng" class="form-control"
                                    placeholder="e.g. 80.6480"
                                    value="<?= htmlspecialchars($selected_farm['longitude'] ?? '') ?>" required>
                                <div class="form-text">You can also type coordinates directly.</div>
                            </div>

                            <button type="button" class="btn btn-primary w-100 mb-2" onclick="getGPS()">
                                <i class="bi bi-crosshair2"></i> Capture GPS Location
                            </button>
                            <button type="button" class="btn btn-outline-secondary w-100 mb-3" onclick="updateMapFromInputs()">
                                <i class="bi bi-map"></i> Preview on Map
                            </button>
                            <button type="submit" class="btn btn-success w-100 fw-bold">
                                <i class="bi bi-floppy"></i> Save Location
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Right: Leaflet map -->
            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white text-muted small">
                        <i class="bi bi-info-circle me-1"></i>
                        <strong>Click anywhere on the map</strong> to drop a pin, or drag the marker.
                        <span class="float-end text-success fw-semibold" id="mapStatus">Map ready.</span>
                    </div>
                    <div class="card-body p-0">
                        <div id="map" style="height:450px;width:100%;border-radius:0 0 5px 5px;cursor:crosshair;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ═══════════════════════════════════════════════════════════════ -->
        <!--  LAND PATTA QR SECTION                                          -->
        <!-- ═══════════════════════════════════════════════════════════════ -->
        <?php if ($selected_farm && !empty($selected_farm['latitude'])): ?>
        <div class="mt-4" id="pattaQrSection">

            <!-- Official integration notice (shown only if configured) -->
            <?php if (isOfficialPattaConfigured()): ?>
            <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
                <i class="bi bi-link-45deg fs-5"></i>
                <div>
                    Official patta integration active:
                    <strong><?= htmlspecialchars(PATTA_OFFICIAL_LABEL) ?></strong>.
                    The QR will open the official government portal.
                </div>
            </div>
            <?php endif; ?>

            <div class="card shadow border-0" style="border-radius:16px;overflow:hidden;">

                <!-- Card header -->
                <div class="card-header text-white fw-bold d-flex align-items-center py-3 px-4"
                     style="background:linear-gradient(135deg,#145a32 0%,#1e8449 55%,#27ae60 100%);">
                    <i class="bi bi-qr-code-scan fs-3 me-3 flex-shrink-0"></i>
                    <div>
                        <div class="fs-5">Land Patta / Land Verification QR</div>
                        <div class="fw-normal small opacity-75">
                            Secure token linked to this specific farm/land record — no personal data in the QR
                        </div>
                    </div>
                </div>

                <div class="card-body p-4">
                    <div class="row align-items-start g-4">

                        <!-- Column 1: Farm / Land Details -->
                        <div class="col-lg-5">
                            <h6 class="fw-bold text-success mb-3">
                                <i class="bi bi-card-text me-1"></i>Farm / Land Details
                            </h6>
                            <table class="table table-sm table-borderless small mb-3">
                                <tbody>
                                    <tr>
                                        <td class="text-muted fw-semibold pe-3" style="width:44%;white-space:nowrap">Farm / Land Name</td>
                                        <td><?= htmlspecialchars($selected_farm['farm_name']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Survey / Patta No.</td>
                                        <td class="fw-semibold"><?= htmlspecialchars($selected_farm['survey_number']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Village</td>
                                        <td><?= htmlspecialchars($selected_farm['village']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Mandal</td>
                                        <td><?= htmlspecialchars($selected_farm['mandal']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">District</td>
                                        <td><?= htmlspecialchars($selected_farm['district']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">State</td>
                                        <td><?= htmlspecialchars($selected_farm['state']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Land Area</td>
                                        <td><?= htmlspecialchars($selected_farm['land_area']) ?>
                                            <?= htmlspecialchars($selected_farm['land_unit']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Ownership</td>
                                        <td><?= htmlspecialchars($selected_farm['ownership_type']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Latitude</td>
                                        <td class="font-monospace" style="font-size:0.8rem">
                                            <?= htmlspecialchars($selected_farm['latitude']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Longitude</td>
                                        <td class="font-monospace" style="font-size:0.8rem">
                                            <?= htmlspecialchars($selected_farm['longitude']) ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Geo-Tag Status</td>
                                        <td>
                                            <?php if (!empty($selected_farm['latitude'])): ?>
                                            <span class="badge bg-success">
                                                <i class="bi bi-check-circle me-1"></i>Geo-Tagged
                                            </span>
                                            <?php else: ?>
                                            <span class="badge bg-warning text-dark">Not Tagged</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted fw-semibold">Land Record</td>
                                        <td>
                                            <span class="badge bg-info text-dark">
                                                <?= isOfficialPattaConfigured() ? 'Official Patta' : 'Demo Patta Record' ?>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                            <!-- Token status badge -->
                            <?php if (!empty($selected_farm['qr_token'])): ?>
                            <div class="rounded p-2 small" style="background:#f0fdf4;border:1px solid #bbf7d0;">
                                <div class="fw-semibold text-success mb-1">
                                    <i class="bi bi-shield-check-fill me-1"></i>QR Token Active
                                </div>
                                <div class="font-monospace text-muted" style="font-size:0.65rem;word-break:break-all;">
                                    <?= htmlspecialchars(substr($selected_farm['qr_token'], 0, 32)) ?>…
                                </div>
                                <?php if (!empty($selected_farm['qr_generated_at'])): ?>
                                <div class="text-muted mt-1">
                                    Generated: <?= date('d M Y, h:i A', strtotime($selected_farm['qr_generated_at'])) ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <div class="rounded p-2 small" style="background:#fffbeb;border:1px solid #fde68a;">
                                <div class="fw-semibold text-warning mb-1">
                                    <i class="bi bi-exclamation-triangle-fill me-1"></i>No Patta QR Yet
                                </div>
                                <div class="text-muted">
                                    Click <strong>Generate Land Patta QR</strong> to create a secure token.
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Column 2: QR code display -->
                        <div class="col-lg-4 text-center">
                            <?php if (!empty($selected_farm['qr_token'])): ?>
                                <div id="qrcode-wrap" class="d-inline-block p-3 bg-white rounded shadow-sm"
                                     style="border:3px solid #1e8449;">
                                    <canvas id="qrcode-canvas"></canvas>
                                </div>
                                <p class="small text-muted mt-2 mb-1">
                                    📷 Scan QR to View Land Patta
                                </p>
                                <p class="font-monospace text-muted" style="font-size:0.6rem;word-break:break-all;">
                                    <?= htmlspecialchars($patta_qr_url) ?>
                                </p>
                                <input type="hidden" id="qrPattaUrl"  value="<?= htmlspecialchars($patta_qr_url) ?>">
                                <input type="hidden" id="qrFarmName"  value="<?= htmlspecialchars($selected_farm['farm_name']) ?>">
                                <input type="hidden" id="qrSurveyNo"  value="<?= htmlspecialchars($selected_farm['survey_number']) ?>">
                            <?php else: ?>
                                <div class="p-5 rounded d-flex flex-column align-items-center justify-content-center"
                                     style="background:#f8fafc;border:2px dashed #cbd5e1;min-height:220px;">
                                    <i class="bi bi-qr-code" style="font-size:3rem;color:#94a3b8;"></i>
                                    <p class="small text-muted mt-3 mb-0">
                                        Land Patta QR will appear here<br>after generation
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Column 3: Action buttons -->
                        <div class="col-lg-3 d-flex flex-column gap-2">
                            <?php if (empty($selected_farm['qr_token'])): ?>
                                <!-- Generate fresh QR -->
                                <form method="post">
                                    <input type="hidden" name="action"   value="generate_patta_qr">
                                    <input type="hidden" name="farm_id"  value="<?= $selected_farm['id'] ?>">
                                    <input type="hidden" name="force_regen" value="0">
                                    <button type="submit" class="btn btn-success w-100 fw-bold py-2">
                                        <i class="bi bi-qr-code me-1"></i> Generate Land Patta QR
                                    </button>
                                </form>
                                <div class="small text-muted text-center px-1">
                                    A unique secure token will be created and saved for this farm.
                                </div>

                            <?php else: ?>
                                <!-- Download -->
                                <button class="btn btn-primary w-100 py-2 fw-semibold" onclick="downloadQR()" id="btnDownloadQR">
                                    <i class="bi bi-download me-1"></i> Download QR
                                </button>

                                <!-- Preview patta page -->
                                <a href="<?= htmlspecialchars($patta_qr_url) ?>"
                                   target="_blank" class="btn btn-success w-100 py-2 fw-semibold">
                                    <i class="bi bi-box-arrow-up-right me-1"></i> View Land Patta
                                </a>

                                <!-- Print -->
                                <button class="btn btn-outline-secondary w-100 py-2" onclick="printQR()">
                                    <i class="bi bi-printer me-1"></i> Print QR
                                </button>

                                <!-- Regenerate (force = invalidates old QR) -->
                                <form method="post" class="mt-1">
                                    <input type="hidden" name="action"      value="generate_patta_qr">
                                    <input type="hidden" name="farm_id"     value="<?= $selected_farm['id'] ?>">
                                    <input type="hidden" name="force_regen" value="1">
                                    <button type="submit" class="btn btn-outline-danger w-100 btn-sm"
                                            onclick="return confirm('This will invalidate the current QR.\nThe old QR code will no longer work.\n\nContinue?')">
                                        <i class="bi bi-arrow-clockwise me-1"></i> Regenerate Token
                                    </button>
                                </form>

                                <hr class="my-1">
                                <div class="small text-muted text-center">
                                    <i class="bi bi-info-circle me-1"></i>
                                    QR encodes a secure URL only.<br>
                                    No Aadhaar / mobile / password in QR.
                                </div>
                            <?php endif; ?>
                        </div>

                    </div><!-- /row -->
                </div><!-- /card-body -->
            </div><!-- /card -->
        </div>

        <?php elseif ($selected_farm && empty($selected_farm['latitude'])): ?>
        <!-- Farm exists but not yet geo-tagged -->
        <div class="mt-4 alert alert-info d-flex align-items-center gap-3">
            <i class="bi bi-info-circle-fill fs-4 flex-shrink-0"></i>
            <div>
                Save this farm's geo-location first using the form above, then
                <strong>Generate Land Patta QR</strong> will appear here.
            </div>
        </div>
        <?php endif; ?>

        <!-- Other farms that already have patta QR codes -->
        <?php
        $other_patta = array_filter($all_farms,
            fn($f) => !empty($f['qr_token']) && $f['id'] != $farm_id_sel
        );
        ?>
        <?php if (!empty($other_patta)): ?>
        <div class="mt-4">
            <h6 class="text-muted fw-semibold mb-3">
                <i class="bi bi-collection me-1"></i>Other Farms with Land Patta QR
            </h6>
            <div class="row g-3">
                <?php foreach ($other_patta as $of): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card border-0 shadow-sm" style="border-radius:10px;">
                        <div class="card-body p-3">
                            <div class="fw-bold"><?= htmlspecialchars($of['farm_name']) ?></div>
                            <div class="small text-muted mb-1">
                                Survey: <?= htmlspecialchars($of['survey_number']) ?>
                            </div>
                            <div class="small text-muted mb-2">
                                <?= htmlspecialchars($of['village']) ?>,
                                <?= htmlspecialchars($of['district']) ?>
                            </div>
                            <div class="d-flex gap-2 flex-wrap">
                                <a href="?farm_id=<?= $of['id'] ?>" class="btn btn-sm btn-outline-success">
                                    <i class="bi bi-qr-code me-1"></i>View QR
                                </a>
                                <a href="<?= htmlspecialchars(buildPattaQrUrl($of['qr_token'], $of['survey_number'])) ?>"
                                   target="_blank" class="btn btn-sm btn-outline-info">
                                    <i class="bi bi-eye me-1"></i>Land Patta
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php endif; // end if farms exist ?>
    </div>
</div>

<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<!-- QRCode.js (canvas-based, no server needed) -->
<script src="https://cdn.jsdelivr.net/npm/qrcode/build/qrcode.min.js"></script>

<script>
/* ════════════════════════════════════════
   Leaflet map
   ════════════════════════════════════════ */
let map, marker;
const initLat  = <?= json_encode((float)($selected_farm['latitude']  ?? 20.5937)) ?>;
const initLng  = <?= json_encode((float)($selected_farm['longitude'] ?? 78.9629)) ?>;
const initZoom = <?= ($selected_farm && $selected_farm['latitude']) ? 14 : 5 ?>;

document.addEventListener('DOMContentLoaded', function () {

    /* Init map */
    map = L.map('map').setView([initLat, initLng], initZoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    if (initZoom === 14) placeMarker(initLat, initLng, false);

    /* Click to drop pin */
    map.on('click', function (e) {
        placeMarker(e.latlng.lat.toFixed(7), e.latlng.lng.toFixed(7), true);
    });

    /* Farm select change → update map */
    document.getElementById('farmSelect').addEventListener('change', function () {
        const opt = this.options[this.selectedIndex];
        const lat = opt.getAttribute('data-lat');
        const lng = opt.getAttribute('data-lng');
        if (lat && lng) {
            document.getElementById('lat').value = lat;
            document.getElementById('lng').value = lng;
            map.setView([parseFloat(lat), parseFloat(lng)], 14);
            placeMarker(lat, lng, false);
            setStatus('Showing existing location.', 'text-info');
        } else {
            document.getElementById('lat').value = '';
            document.getElementById('lng').value = '';
            setStatus('No location yet. Click map or capture GPS.', 'text-warning');
        }
    });

    /* Debounced manual coord input */
    document.getElementById('lat').addEventListener('input', debounce(updateMapFromInputs, 600));
    document.getElementById('lng').addEventListener('input', debounce(updateMapFromInputs, 600));

    /* ─ Render QR code on canvas ─ */
    const canvas  = document.getElementById('qrcode-canvas');
    const urlEl   = document.getElementById('qrPattaUrl');
    if (canvas && urlEl && urlEl.value) {
        QRCode.toCanvas(canvas, urlEl.value, {
            width: 185,
            margin: 1,
            color: { dark: '#145a32', light: '#ffffff' }
        }, function (err) {
            if (err) { console.error('QR render error:', err); return; }
            window._qrCanvas = canvas;
        });
    }

    /* Search box — Enter key */
    const sb = document.getElementById('searchBox');
    if (sb) sb.addEventListener('keypress', e => {
        if (e.key === 'Enter') { e.preventDefault(); searchPlace(); }
    });
});

/* Place / move draggable marker */
function placeMarker(lat, lng, fromClick) {
    lat = parseFloat(lat); lng = parseFloat(lng);
    if (isNaN(lat) || isNaN(lng)) return;
    document.getElementById('lat').value = lat.toFixed(7);
    document.getElementById('lng').value = lng.toFixed(7);
    if (marker) {
        marker.setLatLng([lat, lng]);
    } else {
        marker = L.marker([lat, lng], { draggable: true }).addTo(map);
        marker.on('dragend', function (e) {
            const p = e.target.getLatLng();
            document.getElementById('lat').value = p.lat.toFixed(7);
            document.getElementById('lng').value = p.lng.toFixed(7);
            setStatus('Marker dragged. Coordinates updated.', 'text-success');
        });
    }
    marker.bindPopup('<b>📍 Farm Location</b><br>Lat: ' + lat.toFixed(5) + '<br>Lng: ' + lng.toFixed(5)).openPopup();
    if (fromClick) setStatus('Pin placed at (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + '). Drag to adjust.', 'text-success');
}

/* GPS capture */
function getGPS() {
    if (!navigator.geolocation) { alert('Geolocation not supported by this browser.'); return; }
    setStatus('Acquiring GPS position…', 'text-warning');
    navigator.geolocation.getCurrentPosition(
        pos => {
            map.setView([pos.coords.latitude, pos.coords.longitude], 16);
            placeMarker(pos.coords.latitude, pos.coords.longitude, true);
            setStatus('GPS location captured!', 'text-success');
        },
        err => {
            const msgs = { 1: 'Location access denied.', 2: 'Location unavailable.', 3: 'GPS timed out.' };
            setStatus('GPS Error: ' + (msgs[err.code] || 'Unknown'), 'text-danger');
            alert(msgs[err.code] || 'Could not get location.');
        },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}

/* Nominatim geocoder search */
function searchPlace() {
    const q = document.getElementById('searchBox').value.trim();
    if (!q) { alert('Enter a location name.'); return; }
    setStatus('Searching…', 'text-warning');
    fetch('https://nominatim.openstreetmap.org/search?format=json&q=' +
          encodeURIComponent(q) + '&countrycodes=in&limit=1', { headers: { 'Accept-Language': 'en' } })
    .then(r => r.json())
    .then(data => {
        if (data && data.length > 0) {
            const lat = parseFloat(data[0].lat), lng = parseFloat(data[0].lon);
            map.setView([lat, lng], 13);
            placeMarker(lat, lng, true);
            setStatus('Found: ' + data[0].display_name.split(',').slice(0, 3).join(','), 'text-success');
        } else {
            setStatus('Not found. Try a more specific name.', 'text-danger');
            alert('Location not found. Try e.g. "Guntur, Andhra Pradesh".');
        }
    })
    .catch(() => setStatus('Search failed. Check internet.', 'text-danger'));
}

/* Update map from manually typed coords */
function updateMapFromInputs() {
    const lat = parseFloat(document.getElementById('lat').value);
    const lng = parseFloat(document.getElementById('lng').value);
    if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        map.setView([lat, lng], 14);
        placeMarker(lat, lng, false);
        setStatus('Map updated from manual coordinates.', 'text-info');
    }
}

function setStatus(msg, cls) {
    const el = document.getElementById('mapStatus');
    el.className = 'float-end small fw-semibold ' + cls;
    el.textContent = msg;
}
function debounce(fn, delay) {
    let t;
    return function () { clearTimeout(t); t = setTimeout(fn, delay); };
}

/* ════════════════════════════════════════
   QR actions
   ════════════════════════════════════════ */
function downloadQR() {
    const canvas = window._qrCanvas;
    if (!canvas) { alert('QR code is not ready yet. Please wait a moment.'); return; }
    const farmName  = (document.getElementById('qrFarmName')?.value || 'farm').replace(/\s+/g, '_');
    const surveyNo  = (document.getElementById('qrSurveyNo')?.value || '').replace(/[^a-zA-Z0-9]/g, '_');
    const link = document.createElement('a');
    link.download = 'LandPatta_QR_' + farmName + (surveyNo ? '_' + surveyNo : '') + '.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
}

function printQR() {
    const canvas = window._qrCanvas;
    if (!canvas) { alert('QR code is not ready yet.'); return; }
    const dataUrl   = canvas.toDataURL('image/png');
    const pattaUrl  = document.getElementById('qrPattaUrl')?.value  || '';
    const farmName  = document.getElementById('qrFarmName')?.value  || '';
    const surveyNo  = document.getElementById('qrSurveyNo')?.value  || '';
    const win = window.open('', '_blank', 'width=640,height=800');
    win.document.write(`<!DOCTYPE html>
<html><head><title>Land Patta QR — ${farmName}</title>
<style>
  *{box-sizing:border-box}
  body{font-family:Arial,sans-serif;text-align:center;padding:36px 20px;color:#222;background:#fff;}
  .logo{font-size:2rem;margin-bottom:4px;}
  h2{color:#145a32;margin:0 0 2px;}
  .sub{color:#555;font-size:13px;margin-bottom:4px;}
  .survey{color:#888;font-size:12px;margin-bottom:20px;}
  .qr-box{display:inline-block;border:3px solid #1e8449;border-radius:12px;padding:12px;margin-bottom:12px;}
  .scan-label{color:#145a32;font-weight:700;font-size:14px;margin-bottom:6px;}
  .url{font-size:9px;color:#666;word-break:break-all;max-width:340px;margin:0 auto 16px;font-family:monospace;}
  .disclaimer{font-size:10px;color:#aaa;border-top:1px solid #eee;padding-top:14px;margin-top:10px;line-height:1.6;}
  .badge{display:inline-block;background:#f0fdf4;border:1px solid #86efac;color:#166534;
         border-radius:999px;padding:3px 12px;font-size:11px;font-weight:600;margin-bottom:14px;}
</style></head><body>
<div class="logo">🌾</div>
<h2>AgriStack Farmer Registry</h2>
<p class="sub">Land Patta / Land Verification QR</p>
<p class="survey">Farm: <strong>${farmName}</strong> &nbsp;|&nbsp; Survey No.: <strong>${surveyNo}</strong></p>
<div class="badge">📋 Academic Demo Patta Record</div>
<div class="qr-box"><img src="${dataUrl}" width="200" height="200" alt="Land Patta QR"/></div>
<p class="scan-label">📷 Scan QR to View Land Patta</p>
<p class="url">${pattaUrl}</p>
<p class="disclaimer">
  Academic Prototype — Demo Land/Patta Record.<br>
  <strong>Not an official Government Land Record.</strong><br>
  Scan this QR code to open the land verification record for the farm listed above.
</p>
<script>window.onload=function(){window.print();}<\/script>
</body></html>`);
    win.document.close();
}
</script>
<?php require_once '../includes/footer.php'; ?>
