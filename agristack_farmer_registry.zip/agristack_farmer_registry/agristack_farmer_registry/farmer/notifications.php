<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();

if (isset($_GET['mark_all'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
    $stmt->execute([$user_id]);
    header("Location: notifications.php");
    exit;
}

if (isset($_GET['read_id'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['read_id'], $user_id]);
    header("Location: notifications.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Notifications</h2>
            <a href="?mark_all=1" class="btn btn-sm btn-outline-success">Mark All as Read</a>
        </div>
        
        <div class="list-group shadow-sm border-0">
            <?php foreach($notifications as $n): ?>
                <a href="?read_id=<?= $n['id'] ?>" class="list-group-item list-group-item-action <?= $n['is_read'] ? 'bg-light text-muted' : '' ?>">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1 <?= $n['is_read'] ? '' : 'fw-bold' ?>"><?= htmlspecialchars($n['title']) ?></h6>
                        <small><?= date('d M, H:i', strtotime($n['created_at'])) ?></small>
                    </div>
                    <p class="mb-1"><?= htmlspecialchars($n['message']) ?></p>
                </a>
            <?php endforeach; ?>
            <?php if(empty($notifications)): ?>
                <div class="list-group-item text-center py-4">No notifications found.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
