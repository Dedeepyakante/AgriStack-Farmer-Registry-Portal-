<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $district = trim($_POST['district'] ?? '');
    $state = trim($_POST['state'] ?? '');
    
    if (empty($email)) {
        $error = "Email address is required for your Farmer account.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address format (e.g. farmer@example.com).";
    } else {
        // Check duplicate email across other accounts
        $stmtDup = $pdo->prepare("SELECT id, role FROM users WHERE email = ? AND id != ?");
        $stmtDup->execute([$email, $user_id]);
        $dup = $stmtDup->fetch();
        
        if ($dup) {
            $error = "This email address is already in use by another account. Please provide a different email.";
        } else {
            // Update email in users table
            $uStmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
            $uStmt->execute([$email, $user_id]);
            
            // Update profile
            $stmt = $pdo->prepare("UPDATE farmer_profiles SET dob=?, gender=?, address=?, district=?, state=?, profile_completed=1 WHERE user_id=?");
            $stmt->execute([$dob, $gender, $address, $district, $state, $user_id]);
            
            $message = "Profile and registered email updated successfully.";
            require_once '../includes/functions.php';
            logAudit($pdo, $user_id, 'farmer', 'Profile Update', "Farmer updated profile and email to: $email");
        }
    }
}

$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN farmer_profiles p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">My Profile</h2>
        
        <?php if(empty($profile['email'])): ?>
            <div class="alert alert-warning border-0 shadow-sm d-flex align-items-center mb-4">
                <i class="bi bi-exclamation-triangle-fill fs-3 me-3 text-warning"></i>
                <div>
                    <strong>Action Required: Registered Email Missing!</strong><br>
                    Please enter your valid email address below so you can receive DBT transfer receipts, eSign requests, and official status alerts.
                </div>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <?php if($message): ?><div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
                <?php if($error): ?><div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Farmer ID</label>
                            <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($profile['farmer_id']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Full Name</label>
                            <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($profile['name']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Registered Mobile</label>
                            <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($profile['mobile']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Registered Email *</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($profile['email'] ?? '') ?>" required placeholder="farmer@example.com">
                            <small class="text-muted">Associated with your account for DBT receipts &amp; digital eSign.</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($profile['dob'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Gender</label>
                            <select name="gender" class="form-select" required>
                                <option value="Male" <?= ($profile['gender']??'')=='Male'?'selected':'' ?>>Male</option>
                                <option value="Female" <?= ($profile['gender']??'')=='Female'?'selected':'' ?>>Female</option>
                                <option value="Other" <?= ($profile['gender']??'')=='Other'?'selected':'' ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <label>Address</label>
                            <textarea name="address" class="form-control" required><?= htmlspecialchars($profile['address'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>District</label>
                            <input type="text" name="district" class="form-control" value="<?= htmlspecialchars($profile['district'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>State</label>
                            <input type="text" name="state" class="form-control" value="<?= htmlspecialchars($profile['state'] ?? '') ?>" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success mt-3">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
