<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$user_id = getUserId();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply_scheme'])) {
    $scheme_id = $_POST['scheme_id'];
    $farm_id = $_POST['farm_id'] ?? null;
    
    // Check if already applied
    $chk = $pdo->prepare("SELECT id FROM scheme_applications WHERE user_id=? AND scheme_id=?");
    $chk->execute([$user_id, $scheme_id]);
    
    if($chk->fetch()) {
        $message = "You have already applied for this scheme.";
    } else {
        require_once '../includes/functions.php';
        require_once '../config/mailer.php';
        
        $app_id = generateApplicationId($pdo);
        $stmt = $pdo->prepare("INSERT INTO scheme_applications (application_id, user_id, scheme_id, farm_id, status) VALUES (?, ?, ?, ?, 'Submitted')");
        $stmt->execute([$app_id, $user_id, $scheme_id, $farm_id]);
        
        // Fetch farmer details for email
        $uStmt = $pdo->prepare("SELECT name, farmer_id, email FROM users WHERE id = ?");
        $uStmt->execute([$user_id]);
        $farmer = $uStmt->fetch();
        
        // Fetch scheme name
        $sStmt = $pdo->prepare("SELECT scheme_name FROM schemes WHERE id = ?");
        $sStmt->execute([$scheme_id]);
        $schemeObj = $sStmt->fetch();
        
        // Fetch farm name if selected
        $farmName = 'N/A';
        if ($farm_id) {
            $fStmt = $pdo->prepare("SELECT farm_name FROM farms WHERE id = ?");
            $fStmt->execute([$farm_id]);
            $farmObj = $fStmt->fetch();
            if ($farmObj) $farmName = $farmObj['farm_name'];
        }
        
        logAudit($pdo, $user_id, 'farmer', 'Scheme Application', "Applied for scheme ID $scheme_id (App ID: $app_id).");
        sendNotification($pdo, 1, 'New Scheme Application', "Application $app_id received."); // Notify Admin in-app
        
        // Dispatch email to Administrator(s)
        notifyAdminOfNewApplication($pdo, $app_id, $farmer['name'] ?? 'Farmer', $farmer['farmer_id'] ?? 'N/A', $schemeObj['scheme_name'] ?? 'Scheme', $farmName);
        
        $message = "Successfully applied! Your Application ID is $app_id. A notification has been dispatched to the administration.";
    }
}

$stmt = $pdo->query("SELECT * FROM schemes WHERE status = 'Active'");
$schemes = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT id, farm_name FROM farms WHERE user_id = ?");
$stmt->execute([$user_id]);
$farms = $stmt->fetchAll();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <h2 class="mb-4">Agricultural Schemes</h2>
        <div class="alert alert-warning border-0">
            <strong>Demo Scheme:</strong> These are not official current government schemes.
        </div>
        
        <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        
        <div class="row">
            <?php foreach($schemes as $scheme): ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white text-success fw-bold fs-5">
                        <?= htmlspecialchars($scheme['scheme_name']) ?>
                    </div>
                    <div class="card-body">
                        <p class="mb-2"><strong>Description:</strong> <?= htmlspecialchars($scheme['description']) ?></p>
                        <p class="mb-2"><strong>Eligibility:</strong> <?= htmlspecialchars($scheme['eligibility']) ?></p>
                        <p class="mb-2"><strong>Benefits:</strong> <?= htmlspecialchars($scheme['benefits']) ?></p>
                        <p class="mb-3 text-muted small"><strong>Req. Docs:</strong> <?= htmlspecialchars($scheme['required_documents']) ?></p>
                        
                        <form method="post">
                            <input type="hidden" name="scheme_id" value="<?= $scheme['id'] ?>">
                            <div class="mb-3">
                                <label class="small">Select Farm (if applicable)</label>
                                <select name="farm_id" class="form-select form-select-sm">
                                    <option value="">-- None --</option>
                                    <?php foreach($farms as $f): ?>
                                        <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['farm_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" name="apply_scheme" class="btn btn-success w-100">Apply Now</button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
