<?php
require_once '../config/auth.php';
requireRole('farmer');
require_once '../config/database.php';
require_once '../config/csrf.php';
require_once '../config/esign.php';
require_once '../includes/esign_provider.php';
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$farmerUserId = getUserId();
$flash_success = $_SESSION['flash_success'] ?? null;
$flash_error   = $_SESSION['flash_error'] ?? null;
unset($_SESSION['flash_success'], $_SESSION['flash_error']);

// Fetch farmer profile & details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$farmerUserId]);
$farmer = $stmt->fetch();

// Farmer initiates / confirms a new transaction
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_transaction'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrf)) {
        $_SESSION['flash_error'] = 'Invalid CSRF token. Please try again.';
        header("Location: transactions.php");
        exit;
    }

    $buyerName     = trim($_POST['buyer_name'] ?? '');
    $buyerContact  = trim($_POST['buyer_contact'] ?? '');
    $buyerEmail    = trim($_POST['buyer_email'] ?? '');
    $crop          = trim($_POST['crop'] ?? '');
    $quantity      = (float)($_POST['quantity'] ?? 0);
    $quantityUnit  = trim($_POST['quantity_unit'] ?? 'Quintals');
    $agreedPrice   = (float)($_POST['agreed_price'] ?? 0);
    $deliveryTerms = trim($_POST['delivery_terms'] ?? '');

    if (empty($buyerName) || empty($crop) || $quantity <= 0 || $agreedPrice <= 0 || empty($deliveryTerms)) {
        $_SESSION['flash_error'] = 'Please fill in all transaction fields with valid numbers and delivery terms.';
    } else {
        $txData = [
            'farmer_id'      => $farmerUserId,
            'buyer_name'     => $buyerName,
            'buyer_contact'  => $buyerContact,
            'buyer_email'    => $buyerEmail,
            'crop'           => $crop,
            'quantity'       => $quantity,
            'quantity_unit'  => $quantityUnit,
            'agreed_price'   => $agreedPrice,
            'delivery_terms' => $deliveryTerms
        ];
        try {
            $txId = createMarketTransaction($pdo, $txData, $farmerUserId);
            $_SESSION['flash_success'] = "Transaction details confirmed! Transaction agreement created and frozen for signing. Status: 'Awaiting signatures'.";
            header("Location: transactions.php");
            exit;
        } catch (Exception $e) {
            $_SESSION['flash_error'] = "Could not create transaction: " . $e->getMessage();
        }
    }
}

// Retrieve transactions for this farmer
$transactions = getFarmerMarketTransactions($pdo, $farmerUserId);
$csrfToken = getCsrfToken();
?>
<div class="d-flex">
    <?php require_once '../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="mb-1"><i class="bi bi-receipt text-success me-2"></i>Farmer Transaction Agreements &amp; emSigner</h2>
                <p class="text-muted mb-0">Review confirmed agreements, sign via external emSigner, and track execution status</p>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-success fw-semibold shadow-sm" data-bs-toggle="modal" data-bs-target="#newTxModal">
                    <i class="bi bi-plus-circle me-1"></i>New Transaction Agreement
                </button>
                <a href="https://demo.emsigner.com/" target="_blank" class="btn btn-success fw-semibold shadow-sm">
                    <i class="bi bi-pen me-1"></i>Open emSigner
                </a>
            </div>
        </div>

        <?php if($flash_success): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-check-circle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if($flash_error): ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5 align-middle"></i>
                <?= htmlspecialchars($flash_error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- emSigner Platform Info Card -->
        <div class="card border-0 shadow-sm mb-4" style="background: linear-gradient(135deg, #0b2545 0%, #134074 100%); color: #ffffff;">
            <div class="card-body p-4">
                <div class="d-flex align-items-start gap-3">
                    <span class="badge bg-white text-dark p-2 rounded-circle fs-3 flex-shrink-0">
                        <i class="bi bi-shield-lock-fill text-success"></i>
                    </span>
                    <div>
                        <h5 class="fw-bold mb-1">External Digital Signature Platform (emSigner)</h5>
                        <p class="mb-2 opacity-90 small">
                            Transaction agreement signing is conducted externally via the licensed <strong>emSigner</strong> portal (<strong>https://demo.emsigner.com/</strong>).
                            All Aadhaar eSign and cryptographic signing operations take place on the provider's platform.
                        </p>
                        <p class="mb-0 opacity-90 small">
                            <i class="bi bi-info-circle text-warning me-1"></i>
                            <strong>Workflow Invariant:</strong> After confirmation, agreements show <strong>“Awaiting signatures”</strong> and are frozen for signing. An agreement is marked <strong>“Fully signed”</strong> only after <strong>both farmer and admin transaction signatures</strong> are verified for the same agreement version.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transactions List -->
        <?php if(empty($transactions)): ?>
            <div class="card border-0 shadow-sm text-center p-5">
                <i class="bi bi-file-earmark-spreadsheet fs-1 text-muted mb-3"></i>
                <h4 class="fw-bold text-dark">No Transaction Agreements On File</h4>
                <p class="text-muted mb-3">Confirm transaction details with your commodity buyer to generate a legally structured, frozen agreement for emSigner signing.</p>
                <div>
                    <button type="button" class="btn btn-success fw-bold px-4 py-2" data-bs-toggle="modal" data-bs-target="#newTxModal">
                        <i class="bi bi-plus-lg me-1"></i> Create First Transaction Agreement
                    </button>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach($transactions as $tx): 
                    $agr = $tx['active_agreement'];
                    $isFarmerSigned = ($agr && $agr['farmer_signature_status'] === 'Signed');
                    $isAdminSigned  = ($agr && $agr['admin_signature_status'] === 'Signed');
                    $isFullySigned  = ($agr && $agr['agreement_status'] === 'Fully signed');
                    
                    // Status badge class
                    $statusBadge = 'bg-warning text-dark';
                    if ($agr['agreement_status'] === 'Fully signed') $statusBadge = 'bg-success';
                    elseif ($agr['agreement_status'] === 'Partially signed') $statusBadge = 'bg-info text-dark';
                    elseif ($agr['agreement_status'] === 'Superseded') $statusBadge = 'bg-secondary';
                ?>
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <!-- Card Header -->
                        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2 border-bottom">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-primary-subtle text-primary font-monospace fs-6 px-3 py-2 border border-primary-subtle">
                                    <?= htmlspecialchars($tx['transaction_code']) ?>
                                </span>
                                <span class="badge bg-dark text-white px-2 py-1">
                                    <i class="bi bi-lock-fill me-1"></i>Version <?= $agr ? $agr['version'] : $tx['current_version'] ?> (Frozen for signing)
                                </span>
                                <span class="badge <?= $statusBadge ?> px-3 py-2 fs-6">
                                    <i class="bi <?= $isFullySigned ? 'bi-check-all' : 'bi-clock-history' ?> me-1"></i>
                                    <?= htmlspecialchars($agr['agreement_status'] ?? 'Awaiting signatures') ?>
                                </span>
                            </div>
                            <small class="text-muted">Confirmed on <?= date('d M Y, h:i A', strtotime($tx['created_at'])) ?></small>
                        </div>

                        <!-- Card Body: Agreement Terms -->
                        <div class="card-body p-4">
                            <div class="row g-3 mb-4">
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Buyer Name</small>
                                    <strong class="text-dark fs-6"><?= htmlspecialchars($tx['buyer_name']) ?></strong>
                                    <?php if(!empty($tx['buyer_contact'])): ?>
                                        <small class="text-muted d-block"><?= htmlspecialchars($tx['buyer_contact']) ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Crop</small>
                                    <strong class="text-dark fs-6"><?= htmlspecialchars($tx['crop']) ?></strong>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Quantity &amp; Agreed Price</small>
                                    <strong class="text-dark fs-6"><?= number_format($tx['quantity'], 2) ?> <?= htmlspecialchars($tx['quantity_unit']) ?></strong>
                                    <small class="text-muted d-block">@ ₹<?= number_format($tx['agreed_price'], 2) ?> / <?= htmlspecialchars($tx['quantity_unit']) ?></small>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <small class="text-muted text-uppercase fw-semibold d-block">Total Transaction Value</small>
                                    <strong class="text-success fs-5">₹<?= number_format($tx['total_amount'], 2) ?></strong>
                                </div>
                            </div>

                            <!-- Delivery Terms -->
                            <div class="p-3 bg-light rounded mb-4 border">
                                <strong class="d-block mb-1 text-secondary small text-uppercase"><i class="bi bi-truck me-1"></i>Agreed Delivery Terms:</strong>
                                <p class="mb-0 text-dark small"><?= nl2br(htmlspecialchars($tx['delivery_terms'])) ?></p>
                            </div>

                            <!-- Signing Status Grid -->
                            <div class="row g-3 mb-3">
                                <!-- Farmer Signature Status -->
                                <div class="col-md-6">
                                    <div class="p-3 border rounded h-100 <?= $isFarmerSigned ? 'bg-success-subtle border-success-subtle' : 'bg-white' ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold small text-uppercase">1. Farmer Transaction Signature</span>
                                            <?php if($isFarmerSigned): ?>
                                                <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed in emSigner</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-clock me-1"></i>Awaiting Your Signature</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="small text-muted mb-2">
                                            Signer: <strong><?= htmlspecialchars($farmer['name']) ?></strong> (<?= htmlspecialchars($farmer['email'] ?? 'Registered Email') ?>)
                                        </p>
                                        <?php if($isFarmerSigned): ?>
                                            <div class="small text-success">
                                                <i class="bi bi-check-circle me-1"></i>Signed: <?= date('d M Y, h:i A', strtotime($agr['farmer_signed_at'])) ?><br>
                                                <span class="font-monospace text-muted">Ref: <?= htmlspecialchars($agr['farmer_signature_ref']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted mb-3">
                                                You must perform your own signature from this authenticated farmer account.
                                            </div>

                                            <div class="d-flex flex-wrap gap-2">
                                                <!-- Action Button 1: Initiate emSigner API session -->
                                                <button type="button"
                                                    class="btn btn-success btn-sm fw-bold shadow-sm btn-initiate-emsigner"
                                                    data-action="farmer_transaction"
                                                    data-agr-id="<?= $agr['id'] ?>"
                                                    title="Create emSigner session & dispatch signing invitation email">
                                                    <i class="bi bi-pen me-1"></i>Initiate emSigner Signing
                                                </button>
                                                <!-- Action Button 2: Verify Signing Result -->
                                                <button type="button" class="btn btn-outline-success btn-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#verifyFarmerTxModal<?= $agr['id'] ?>">
                                                    <i class="bi bi-check2-circle me-1"></i>Verify Signing Result
                                                </button>
                                            </div>

                                            <div class="alert alert-light border small mt-2 mb-0 py-2">
                                                <i class="bi bi-info-circle text-primary me-1"></i>
                                                Clicking <strong>Initiate emSigner Signing</strong> creates a live session via the emSigner API and dispatches an invitation email with the secure signing link to your registered email. After signing, return here and click <strong>Verify Signing Result</strong> to confirm.
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Admin Transaction Signature Status -->
                                <div class="col-md-6">
                                    <div class="p-3 border rounded h-100 <?= $isAdminSigned ? 'bg-success-subtle border-success-subtle' : 'bg-white' ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold small text-uppercase">2. Admin Transaction Signature</span>
                                            <?php if($isAdminSigned): ?>
                                                <span class="badge bg-success"><i class="bi bi-patch-check-fill me-1"></i>Signed by Admin</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><i class="bi bi-clock me-1"></i>Awaiting Admin Signature</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="small text-muted mb-2">
                                            Official AgriLink administrator signature for Transaction Agreement Version <?= $agr['version'] ?>.
                                        </p>
                                        <?php if($isAdminSigned): ?>
                                            <div class="small text-success">
                                                <i class="bi bi-check-circle me-1"></i>Signed: <?= date('d M Y, h:i A', strtotime($agr['admin_signed_at'])) ?><br>
                                                <span class="font-monospace text-muted">Ref: <?= htmlspecialchars($agr['admin_signature_ref']) ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted">
                                                Pending administrator review and signature in emSigner portal.
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Cryptographic Hash & Immutability Seal -->
                            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 pt-2 border-top small text-muted">
                                <div>
                                    <i class="bi bi-fingerprint me-1"></i>Canonical Agreement Hash (SHA-256):
                                    <code class="text-secondary"><?= substr($agr['agreement_hash'] ?? '', 0, 24) ?>...</code>
                                </div>
                                <div>
                                    <?php if($isFullySigned): ?>
                                        <span class="text-success fw-bold"><i class="bi bi-patch-check-fill me-1"></i>Fully Signed &amp; Legally Binding</span>
                                    <?php else: ?>
                                        <span class="text-warning fw-semibold"><i class="bi bi-hourglass-split me-1"></i>Awaiting signatures (Requires both Farmer &amp; Admin)</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Verification Modal for Farmer -->
                        <?php if(!$isFarmerSigned && $agr): ?>
                        <div class="modal fade text-start" id="verifyFarmerTxModal<?= $agr['id'] ?>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="/agristack_farmer_registry/api/verify_signing_result.php">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                                        <input type="hidden" name="action" value="farmer_transaction">
                                        <input type="hidden" name="agreement_id" value="<?= $agr['id'] ?>">

                                        <div class="modal-header bg-success text-white">
                                            <h5 class="modal-title"><i class="bi bi-patch-check me-2"></i>Verify Farmer Signing Result</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-light border small mb-3">
                                                <strong>Transaction:</strong> <?= htmlspecialchars($tx['transaction_code']) ?> (Version <?= $agr['version'] ?>)<br>
                                                <strong>Farmer Signer:</strong> <?= htmlspecialchars($farmer['name']) ?><br>
                                                <strong>External Portal:</strong> <a href="https://demo.emsigner.com/" target="_blank">https://demo.emsigner.com/</a>
                                            </div>

                                            <p class="small text-muted mb-3">
                                                After completing your signing on emSigner, confirm your signature reference to verify and bind the signature to Agreement Version <?= $agr['version'] ?>.
                                            </p>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">emSigner Signing Reference</label>
                                                <input type="text" name="provider_ref_id" class="form-control font-monospace" placeholder="e.g. EMUDHRA-TX-FARMER-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" value="EMUDHRA-TX-FARMER-<?= date('Ymd') ?>-<?= strtoupper(substr(uniqid(), -4)) ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">emSigner Workflow ID (Optional)</label>
                                                <input type="text" name="workflow_id" class="form-control font-monospace" placeholder="WF-TX-<?= $tx['transaction_code'] ?>-v<?= $agr['version'] ?>-FARMER" value="WF-TX-<?= $tx['transaction_code'] ?>-v<?= $agr['version'] ?>-FARMER">
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-success fw-bold">
                                                <i class="bi bi-patch-check-fill me-1"></i>Verify &amp; Confirm Signature
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</div>

<!-- Modal: Create New Transaction Agreement -->
<div class="modal fade" id="newTxModal" tabindex="-1" aria-labelledby="newTxModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="transactions.php">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                <input type="hidden" name="create_transaction" value="1">

                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="newTxModalLabel"><i class="bi bi-receipt me-2"></i>Create New Transaction Agreement</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <p class="text-muted small mb-4">
                        Define transaction terms with the buyer. Once confirmed, the agreement will be <strong>frozen for signing (Version 1)</strong>, placed in <strong>“Awaiting signatures”</strong> status, and require both farmer and admin signatures through emSigner.
                    </p>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Buyer / Agribusiness Name <span class="text-danger">*</span></label>
                            <input type="text" name="buyer_name" class="form-control" placeholder="e.g. Southern Agro Mills Ltd" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Buyer Contact</label>
                            <input type="text" name="buyer_contact" class="form-control" placeholder="e.g. 9876543210">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Buyer Email</label>
                            <input type="email" name="buyer_email" class="form-control" placeholder="buyer@agromills.com">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Crop / Produce <span class="text-danger">*</span></label>
                            <input type="text" name="crop" class="form-control" placeholder="e.g. Paddy (Basmati)" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Quantity <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.01" name="quantity" class="form-control" placeholder="e.g. 100.00" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Unit</label>
                            <select name="quantity_unit" class="form-select">
                                <option value="Quintals" selected>Quintals</option>
                                <option value="Metric Tons">Metric Tons</option>
                                <option value="Kg">Kilograms (Kg)</option>
                                <option value="Bags">Bags (50kg)</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Agreed Price (₹ per unit) <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" min="0.01" name="agreed_price" class="form-control" placeholder="e.g. 2350.00" required>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">Delivery &amp; Settlement Terms <span class="text-danger">*</span></label>
                            <textarea name="delivery_terms" class="form-control" rows="3" placeholder="e.g. Farmgate pickup within 10 days of harvesting. Moisture content below 14%. Direct bank transfer upon weighbridge clearance." required>Farmgate pickup within 7 days of harvest. Quality inspection on site. Payment via Direct Bank Transfer within 48 hours of dispatch.</textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success fw-bold">
                        <i class="bi bi-check2-circle me-1"></i>Confirm Details &amp; Create Agreement
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
