<?php
// Buffer output early to prevent any stray bytes, warnings or whitespace before JSON
ob_start();

// Disable printing PHP errors into HTTP response body (log them to server log instead)
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

/**
 * AgriStack / AgriLink - Aadhaar e-KYC Verification Handler
 * 
 * Strict Privacy & Security Standards:
 * 1. Requires authenticated farmer session.
 * 2. Enforces CSRF protection and session-based rate limiting.
 * 3. Enforces explicit consent verification.
 * 4. Binds attempts strictly to the authenticated user ID (never trusts client parameters).
 * 5. Processes files temporarily and cleans them up immediately (never logs sensitive payload or retains raw files).
 * 6. Keeps document authenticity distinct from holder identity checks.
 * 7. Separate Demo Upload Path:
 *    - Custom demonstration files (<AgriLinkDemoEKYC>) are never sent through production UIDAI verifier.
 *    - Processed only when server-side DEMO_MODE is enabled; otherwise rejected with "Demo files are disabled".
 *    - Sets status on server to demo_completed and displays "DEMO — Not Aadhaar verified".
 *    - Never trusts verification flags inside uploaded XML and does not unlock actions requiring verified identity.
 *    - Production Aadhaar signature and schema checks are fully preserved.
 */

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/csrf.php';
require_once __DIR__ . '/../config/demo.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/AadhaarXmlVerifier.php';
require_once __DIR__ . '/../includes/AadhaarSecureQrVerifier.php';
require_once __DIR__ . '/../includes/DemoEkycVerifier.php';

function sendJsonResponse(array $data, int $statusCode = 200): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

$isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') 
          || (isset($_POST['is_ajax']) && $_POST['is_ajax'] === '1');

// Verify farmer session
if (!isLoggedIn() || getUserRole() !== 'farmer') {
    if ($isAjax) {
        sendJsonResponse([
            'success' => false,
            'code'    => 'AUTH_REQUIRED',
            'message' => 'Your session has expired. Please refresh the page and log in again.'
        ], 401);
    }
    header("Location: /agristack_farmer_registry/login.php");
    exit;
}

$userId = getUserId();

// Rate limiting: maximum 10 attempts per 15 minutes per session
if (!isset($_SESSION['ekyc_rate_limit'])) {
    $_SESSION['ekyc_rate_limit'] = ['count' => 0, 'window_start' => time()];
}
if (time() - $_SESSION['ekyc_rate_limit']['window_start'] > 900) {
    $_SESSION['ekyc_rate_limit'] = ['count' => 1, 'window_start' => time()];
} else {
    $_SESSION['ekyc_rate_limit']['count']++;
    if ($_SESSION['ekyc_rate_limit']['count'] > 15) {
        $msg = "Rate limit exceeded: Too many e-KYC attempts. Please try again after 15 minutes.";
        if ($isAjax) {
            sendJsonResponse(['success' => false, 'code' => 'RATE_LIMIT_EXCEEDED', 'message' => $msg], 429);
        }
        $_SESSION['ekyc_error'] = $msg;
        header("Location: ekyc.php");
        exit;
    }
}

// CSRF Protection
$submittedCsrf = $_POST['csrf_token'] ?? '';
if (!verifyCsrfToken($submittedCsrf)) {
    $msg = "Security check failed: Invalid CSRF token. Please refresh the page and try again.";
    if ($isAjax) {
        sendJsonResponse(['success' => false, 'code' => 'INVALID_CSRF', 'message' => $msg], 403);
    }
    $_SESSION['ekyc_error'] = $msg;
    header("Location: ekyc.php");
    exit;
}

// Explicit Consent Verification
if (empty($_POST['consent_terms'])) {
    $msg = "Explicit consent is mandatory before processing Aadhaar verification.";
    if ($isAjax) {
        sendJsonResponse(['success' => false, 'code' => 'CONSENT_REQUIRED', 'message' => $msg], 400);
    }
    $_SESSION['ekyc_error'] = $msg;
    header("Location: ekyc.php");
    exit;
}

$method = $_POST['verification_method'] ?? 'offline_xml';
$verificationResult = null;
$tmpFileToCleanup = null;
$attemptRef = 'EKYC-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4)));

try {
    if ($method === 'offline_xml') {
        if (!isset($_FILES['ekyc_file']) || $_FILES['ekyc_file']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Please select a valid Aadhaar offline XML or password-protected ZIP file.");
        }

        $tmpFileToCleanup = $_FILES['ekyc_file']['tmp_name'];
        $shareCode = trim($_POST['share_code'] ?? '');

        // Check if uploaded file is the custom demo e-KYC format (<AgriLinkDemoEKYC>)
        if (DemoEkycVerifier::isDemoUpload($tmpFileToCleanup, $shareCode)) {
            // Process on separate demo upload path (never send through production UIDAI verifier)
            $verificationResult = DemoEkycVerifier::verify($tmpFileToCleanup, $shareCode);
        } else {
            // Production Aadhaar XML verifier with all structural & signature checks
            $verificationResult = AadhaarXmlVerifier::verify($_FILES['ekyc_file'], $shareCode);
        }

    } elseif ($method === 'secure_qr') {
        $qrPayload = trim($_POST['qr_payload'] ?? '');

        if (empty($qrPayload) && isset($_FILES['qr_image']) && $_FILES['qr_image']['error'] === UPLOAD_ERR_OK) {
            $tmpFileToCleanup = $_FILES['qr_image']['tmp_name'];
            $qrPayload = file_get_contents($_FILES['qr_image']['tmp_name']);
        }

        if (empty($qrPayload)) {
            throw new Exception("Please upload a QR code image or scan using your camera.");
        }

        // Verify Secure QR cryptographically
        $verificationResult = AadhaarSecureQrVerifier::verify($qrPayload);
    } else {
        throw new Exception("Unsupported verification method selected.");
    }
} catch (Exception $e) {
    $verificationResult = [
        'valid'   => false,
        'code'    => 'EXCEPTION',
        'message' => $e->getMessage()
    ];
} finally {
    // Privacy: immediately delete temporary file
    if ($tmpFileToCleanup && file_exists($tmpFileToCleanup)) {
        @unlink($tmpFileToCleanup);
    }
}

// =============================================================================
// Record Outcome in Database (Strict Server-Side Binding to $userId)
// =============================================================================
$isDemo = !empty($verificationResult['is_demo']);

if ($verificationResult['valid']) {
    $last4 = $verificationResult['aadhaar_last4'] ?? null;

    if ($isDemo) {
        // Demo upload path outcome
        $vStatus      = 'demo_completed';
        $legacyStatus = 'Pending'; // Remains Pending, never trusted as genuine verified
        $holderStatus = 'Not verified (Demo mode)';
        $docType      = 'AgriLink Demo e-KYC (XML)';
        $sigTrust     = 'DEMO_NOT_VERIFIED';
        $remarks      = 'DEMO — Not Aadhaar verified (Simulated demonstration file; not issued by UIDAI).';
        $actualMethod = 'demo_xml';
    } else {
        // Genuine production Aadhaar verification outcome
        $vStatus      = 'Aadhaar document verified';
        $legacyStatus = 'Pending'; // Remains Pending for physical/administrator holder review
        $holderStatus = 'Holder check pending';
        $docType      = ($method === 'offline_xml') ? 'Aadhaar Offline e-KYC (XML)' : 'Aadhaar Secure QR';
        $sigTrust     = $verificationResult['uidai_sig_status'] ?? 'UNVERIFIED';
        $remarks      = "UIDAI Digital Signature Verified ({$sigTrust}). Document authenticated. Account-holder check pending.";
        $actualMethod = $method;
    }

    $stmt = $pdo->prepare("INSERT INTO identity_verifications (
        user_id, document_type, document_path, extracted_photo_path,
        status, admin_remarks, submitted_at, verification_status,
        verification_method, uidai_sig_status, aadhaar_last4,
        attempt_ref, consent_recorded, consent_timestamp, holder_check_status
    ) VALUES (?, ?, NULL, NULL, ?, ?, NOW(), ?, ?, ?, ?, ?, 1, NOW(), ?)");

    $stmt->execute([
        $userId,
        $docType,
        $legacyStatus,
        $remarks,
        $vStatus,
        $actualMethod,
        $sigTrust,
        $last4,
        $attemptRef,
        $holderStatus
    ]);

    // Privacy-preserving audit log
    logAudit($pdo, $userId, 'farmer', 'eKYC Verification', "Aadhaar e-KYC attempt ({$attemptRef}) via {$actualMethod}. Outcome: {$vStatus}.");

    if ($isDemo) {
        $response = [
            'success'             => true,
            'is_demo'             => true,
            'verification_status' => 'demo_completed',
            'status_display'      => 'DEMO — Not Aadhaar verified',
            'holder_check_status' => $holderStatus,
            'aadhaar_last4'       => $last4,
            'attempt_ref'         => $attemptRef,
            'method'              => 'demo_xml',
            'name'                => $verificationResult['name'] ?? '',
            'dob'                 => $verificationResult['dob'] ?? '',
            'gender'              => $verificationResult['gender'] ?? '',
            'address'             => $verificationResult['address'] ?? '',
            'phone'               => $verificationResult['phone'] ?? '',
            'email'               => $verificationResult['email'] ?? '',
            'message'             => 'DEMO — Not Aadhaar verified'
        ];
    } else {
        $response = [
            'success'             => true,
            'is_demo'             => false,
            'verification_status' => $vStatus,
            'holder_check_status' => $holderStatus,
            'aadhaar_last4'       => $last4,
            'attempt_ref'         => $attemptRef,
            'method'              => $method,
            'name'                => $verificationResult['name'] ?? '',
            'dob'                 => $verificationResult['dob'] ?? '',
            'gender'              => $verificationResult['gender'] ?? '',
            'message'             => "Aadhaar document verified successfully! The cryptographic digital signature from UIDAI was validated. Note: Account-holder identity check remains pending."
        ];
    }

    if ($isAjax) {
        sendJsonResponse($response, 200);
    }

    $_SESSION['ekyc_success'] = $response['message'];
    header("Location: ekyc.php?ref=" . urlencode($attemptRef));
    exit;

} else {
    // Verification Failed
    $vStatus      = 'Failed';
    $legacyStatus = 'Rejected';
    $holderStatus = 'Holder check pending';
    $docType      = ($method === 'offline_xml') ? 'Aadhaar Offline e-KYC (XML)' : 'Aadhaar Secure QR';
    $remarks      = "Verification Failed: " . ($verificationResult['message'] ?? 'Signature verification error.');
    $last4        = $verificationResult['aadhaar_last4'] ?? null;

    // Check if rejected because demo mode is disabled
    if (($verificationResult['code'] ?? '') === 'DEMO_MODE_DISABLED') {
        $response = [
            'success'             => false,
            'verification_status' => 'Failed',
            'code'                => 'DEMO_MODE_DISABLED',
            'message'             => 'Demo files are disabled'
        ];
        if ($isAjax) {
            sendJsonResponse($response, 200);
        }
        $_SESSION['ekyc_error'] = 'Demo files are disabled';
        header("Location: ekyc.php?failed=1");
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO identity_verifications (
        user_id, document_type, document_path, extracted_photo_path,
        status, admin_remarks, submitted_at, verification_status,
        verification_method, uidai_sig_status, aadhaar_last4,
        attempt_ref, consent_recorded, consent_timestamp, holder_check_status
    ) VALUES (?, ?, NULL, NULL, ?, ?, NOW(), ?, ?, ?, ?, ?, 1, NOW(), ?)");

    $stmt->execute([
        $userId,
        $docType,
        $legacyStatus,
        $remarks,
        $vStatus,
        $method,
        'VERIFICATION_FAILED',
        $last4,
        $attemptRef,
        $holderStatus
    ]);

    logAudit($pdo, $userId, 'farmer', 'eKYC Verification', "Aadhaar e-KYC attempt ({$attemptRef}) via {$method}. Outcome: Failed.");

    $response = [
        'success'             => false,
        'verification_status' => 'Failed',
        'code'                => $verificationResult['code'] ?? 'ERROR',
        'message'             => $verificationResult['message'] ?? 'Aadhaar verification failed.'
    ];

    if ($isAjax) {
        sendJsonResponse($response, 200);
    }

    $_SESSION['ekyc_error'] = $response['message'];
    header("Location: ekyc.php?failed=1");
    exit;
}
