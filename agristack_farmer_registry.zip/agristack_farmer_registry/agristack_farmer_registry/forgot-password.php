<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/mailer.php';
require_once __DIR__ . '/includes/functions.php';

$error = '';
$info = '';
$success = '';

$step = $_SESSION['farmer_reset_step'] ?? 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_otp'])) {
        $mobile = trim($_POST['mobile'] ?? '');
        if (empty($mobile)) {
            $error = "Please enter your registered 10-digit mobile number.";
        } else {
            $stmt = $pdo->prepare("SELECT id, name, mobile FROM users WHERE mobile = ? AND role = 'farmer'");
            $stmt->execute([$mobile]);
            $user = $stmt->fetch();
            
            if ($user) {
                $otp = str_pad((string)random_int(100000, 999999), 6, '0', STR_PAD_LEFT);

                $_SESSION['farmer_reset_id']         = $user['id'];
                $_SESSION['farmer_reset_mobile']     = $user['mobile'];
                $_SESSION['farmer_reset_name']       = $user['name'];
                $_SESSION['farmer_reset_otp']        = $otp;
                $_SESSION['farmer_reset_otp_expiry'] = time() + 900; // 15 mins
                $_SESSION['farmer_reset_step']       = 2;
                $step = 2;

                $dispatch = sendOTPMessage($user['mobile'], $otp, 'sms', $user['name']);
                $info = $dispatch['message'];
            } else {
                $error = "No farmer account found registered with this mobile number.";
            }
        }
    } elseif (isset($_POST['verify_otp'])) {
        $otp = trim($_POST['otp'] ?? '');
        if (!isset($_SESSION['farmer_reset_id']) || !isset($_SESSION['farmer_reset_otp'])) {
            $error = "Reset session has expired. Please request a new OTP.";
            $step = 1;
            $_SESSION['farmer_reset_step'] = 1;
        } elseif (time() > ($_SESSION['farmer_reset_otp_expiry'] ?? 0)) {
            $error = "The OTP has expired (valid for 15 minutes). Please request a new OTP.";
            unset($_SESSION['farmer_reset_otp'], $_SESSION['farmer_reset_otp_expiry']);
            $step = 1;
            $_SESSION['farmer_reset_step'] = 1;
        } elseif ($otp === $_SESSION['farmer_reset_otp']) {
            $_SESSION['farmer_reset_verified'] = true;
            $_SESSION['farmer_reset_step']     = 3;
            $step = 3;
            $info = "OTP verified successfully. Please set your new password.";
        } else {
            $error = "Invalid OTP code entered. Please check and try again.";
            $step = 2;
        }
    } elseif (isset($_POST['reset_pwd'])) {
        $pwd = $_POST['password'] ?? '';
        $cpwd = $_POST['cpassword'] ?? '';

        if (!isset($_SESSION['farmer_reset_id']) || empty($_SESSION['farmer_reset_verified'])) {
            $error = "Unauthorized reset attempt. Please verify OTP first.";
            $step = 1;
            $_SESSION['farmer_reset_step'] = 1;
        } elseif (strlen($pwd) < 8) {
            $error = "Password must be at least 8 characters long.";
            $step = 3;
        } elseif ($pwd !== $cpwd) {
            $error = "Passwords do not match. Please re-enter.";
            $step = 3;
        } else {
            $hash = password_hash($pwd, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ? AND role = 'farmer'");
            $stmt->execute([$hash, $_SESSION['farmer_reset_id']]);

            logAudit($pdo, $_SESSION['farmer_reset_id'], 'farmer', 'Password Reset', 'Farmer successfully reset password via OTP.');

            unset(
                $_SESSION['farmer_reset_id'],
                $_SESSION['farmer_reset_mobile'],
                $_SESSION['farmer_reset_name'],
                $_SESSION['farmer_reset_otp'],
                $_SESSION['farmer_reset_otp_expiry'],
                $_SESSION['farmer_reset_verified'],
                $_SESSION['farmer_reset_step']
            );

            $success = "Password updated successfully. You can now log in with your new password.";
            $step = 4;
        }
    } elseif (isset($_POST['cancel_reset'])) {
        unset(
            $_SESSION['farmer_reset_id'],
            $_SESSION['farmer_reset_mobile'],
            $_SESSION['farmer_reset_name'],
            $_SESSION['farmer_reset_otp'],
            $_SESSION['farmer_reset_otp_expiry'],
            $_SESSION['farmer_reset_verified'],
            $_SESSION['farmer_reset_step']
        );
        header("Location: login.php");
        exit;
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow border-0">
                <div class="card-header bg-success text-white text-center py-3">
                    <div class="mb-1"><i class="bi bi-shield-lock fs-2"></i></div>
                    <h4 class="mb-0 fw-bold">Farmer Password Reset</h4>
                    <small class="text-light opacity-75">Secure Mobile OTP Verification</small>
                </div>
                <div class="card-body p-4">
                    <!-- Progress Indicator -->
                    <div class="d-flex justify-content-between text-center mb-4 pb-2 border-bottom">
                        <div class="<?= $step >= 1 ? 'text-success fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 1 ? 'bg-success' : 'bg-secondary' ?> rounded-pill mb-1">1</span><br>
                            <small>Mobile</small>
                        </div>
                        <div class="text-muted pt-1">&rarr;</div>
                        <div class="<?= $step >= 2 ? 'text-success fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 2 ? 'bg-success' : 'bg-secondary' ?> rounded-pill mb-1">2</span><br>
                            <small>Verify OTP</small>
                        </div>
                        <div class="text-muted pt-1">&rarr;</div>
                        <div class="<?= $step >= 3 ? 'text-success fw-bold' : 'text-muted' ?>">
                            <span class="badge <?= $step >= 3 ? 'bg-success' : 'bg-secondary' ?> rounded-pill mb-1">3</span><br>
                            <small>New Password</small>
                        </div>
                    </div>

                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($info)): ?>
                        <div class="alert alert-info alert-dismissible fade show" role="alert">
                            <i class="bi bi-info-circle-fill me-2"></i><?= htmlspecialchars($info) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($success)): ?>
                        <div class="alert alert-success text-center py-4" role="alert">
                            <i class="bi bi-check-circle-fill fs-1 text-success d-block mb-2"></i>
                            <h5 class="alert-heading fw-bold">Password Reset Complete!</h5>
                            <p class="mb-3"><?= htmlspecialchars($success) ?></p>
                            <a href="login.php" class="btn btn-success w-100 py-2 fw-semibold">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Go to Farmer Login
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if($step === 1): ?>
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Enter your registered 10-digit mobile number. A 6-digit OTP will be dispatched for verification.
                            </p>
                            <div class="mb-3">
                                <label for="mobile" class="form-label fw-semibold">Registered Mobile Number</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-phone"></i></span>
                                    <input type="tel" id="mobile" name="mobile" class="form-control" required pattern="[0-9]{10}" placeholder="10-digit Mobile Number" autofocus>
                                </div>
                            </div>
                            <button type="submit" name="send_otp" class="btn btn-success w-100 py-2 fw-semibold">
                                <i class="bi bi-send me-1"></i> Send Verification OTP
                            </button>
                        </form>

                    <?php elseif($step === 2): ?>
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Enter the 6-digit OTP dispatched to your mobile. (Valid for 15 minutes).
                            </p>
                            <div class="mb-3">
                                <label for="otp" class="form-label fw-semibold">Enter 6-Digit OTP</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-key-fill"></i></span>
                                    <input type="text" id="otp" name="otp" class="form-control font-monospace fs-5 text-center letter-spacing" maxlength="6" pattern="[0-9]{6}" placeholder="______" required autofocus>
                                </div>
                            </div>
                            <button type="submit" name="verify_otp" class="btn btn-success w-100 py-2 fw-semibold mb-2">
                                <i class="bi bi-shield-check me-1"></i> Verify OTP
                            </button>
                        </form>
                        <form method="post" action="forgot-password.php" class="d-flex justify-content-between mt-2">
                            <button type="submit" name="send_otp" class="btn btn-link btn-sm text-decoration-none p-0 text-muted">
                                <i class="bi bi-arrow-clockwise me-1"></i>Resend OTP
                            </button>
                            <button type="submit" name="cancel_reset" class="btn btn-link btn-sm text-decoration-none p-0 text-danger">
                                Cancel & Restart
                            </button>
                        </form>

                    <?php elseif($step === 3): ?>
                        <form method="post" action="forgot-password.php">
                            <p class="text-muted small mb-3">
                                Enter your new account password (minimum 8 characters).
                            </p>
                            <div class="mb-3">
                                <label for="password" class="form-label fw-semibold">New Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock-fill"></i></span>
                                    <input type="password" id="password" name="password" class="form-control" required minlength="8" placeholder="Minimum 8 characters" autofocus>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="cpassword" class="form-label fw-semibold">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-lock-fill"></i></span>
                                    <input type="password" id="cpassword" name="cpassword" class="form-control" required minlength="8" placeholder="Re-type password">
                                </div>
                            </div>
                            <button type="submit" name="reset_pwd" class="btn btn-success w-100 py-2 fw-semibold">
                                <i class="bi bi-check2-circle me-1"></i> Update Password
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if($step !== 4): ?>
                        <div class="text-center mt-3 pt-2 border-top">
                            <a href="login.php" class="text-decoration-none small text-muted">
                                <i class="bi bi-arrow-left me-1"></i>Back to Farmer Login
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="mt-3 pt-2 border-top">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
