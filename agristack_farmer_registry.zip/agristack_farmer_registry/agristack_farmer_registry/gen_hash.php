<?php
// Generate fresh bcrypt hashes for both admin and farmer demo passwords
$admin_password = 'Admin@12345';
$farmer_password = 'Farmer@12345';

$admin_hash = password_hash($admin_password, PASSWORD_DEFAULT);
$farmer_hash = password_hash($farmer_password, PASSWORD_DEFAULT);

echo "Admin hash: " . $admin_hash . "\n";
echo "Farmer hash: " . $farmer_hash . "\n";
?>
