<?php
/**
 * AgriStack / AgriLink - Aadhaar Secure QR Code Verifier
 * 
 * Strict UIDAI Compliance & Cryptographic Signature Validation:
 * 1. Decodes binary big-integer, base64, or raw byte streams.
 * 2. Decompresses gzip / zlib compressed payloads.
 * 3. Extracts demographic fields separated by 0xFF delimiters.
 * 4. Extracts the 256-byte RSA digital signature and verifies it against trusted UIDAI certificates.
 * 5. Rejects arbitrary JSON, legacy unsigned text, or unverified signatures with clear error messages.
 * 6. Never requests or retains full Aadhaar number (extracts only masked last 4 digits).
 */

require_once __DIR__ . '/AadhaarXmlVerifier.php';

class AadhaarSecureQrVerifier {

    /**
     * Decode and cryptographically verify Aadhaar Secure QR code data
     * 
     * @param string $qrInput Raw text, decimal big-integer, or base64 scanned from QR
     * @param array  $options Verification options ('allow_test_fixtures' => bool)
     * @return array Result array with status and extracted demographics
     */
    public static function verify(string $qrInput, array $options = []): array {
        $trimmed = trim($qrInput);

        if (empty($trimmed)) {
            return [
                'valid'   => false,
                'code'    => 'EMPTY_PAYLOAD',
                'message' => 'QR code payload is empty.'
            ];
        }

        // Security check: explicitly reject arbitrary JSON or plain text formats
        if (str_starts_with($trimmed, '{') || str_starts_with($trimmed, '[') || str_starts_with($trimmed, '<?xml')) {
            return [
                'valid'   => false,
                'code'    => 'UNSUPPORTED_UNSIGNED_FORMAT',
                'message' => 'Scanned code is an unsigned legacy text or JSON format. UIDAI requires cryptographically signed Secure QR codes. Please use the Aadhaar Paperless Offline XML upload method.'
            ];
        }

        // Convert big integer or base64 to raw bytes
        $rawBytes = self::convertToBytes($trimmed);
        if (empty($rawBytes) || strlen($rawBytes) < 260) {
            return [
                'valid'   => false,
                'code'    => 'INVALID_QR_LENGTH',
                'message' => 'Invalid or truncated QR payload. Official UIDAI Secure QR codes contain at least 256 bytes of cryptographic signature data.'
            ];
        }

        // Signature separation: the last 256 bytes are the RSA-2048 digital signature
        $sigLength = 256;
        $signedData = substr($rawBytes, 0, -$sigLength);
        $signatureBytes = substr($rawBytes, -$sigLength);

        // Attempt decompression of the signed data (gzip \x1f\x8b or zlib \x78)
        $decompressed = null;
        if (str_starts_with($signedData, "\x1f\x8b")) {
            $decompressed = @gzdecode($signedData);
        } elseif (str_starts_with($signedData, "\x78")) {
            $decompressed = @zlib_decode($signedData);
        } else {
            // Also check if entire payload was compressed including signature
            $tryAllGz = @gzdecode($rawBytes);
            if ($tryAllGz && strlen($tryAllGz) > 260) {
                $signedData = substr($tryAllGz, 0, -$sigLength);
                $signatureBytes = substr($tryAllGz, -$sigLength);
                $decompressed = $signedData;
            }
        }

        $dataStream = $decompressed ?: $signedData;

        // Verify cryptographic signature against trusted UIDAI certificates
        $sigResult = self::verifyQrSignature($signedData, $signatureBytes, $options);
        if (!$sigResult['valid']) {
            return [
                'valid'   => false,
                'code'    => $sigResult['code'],
                'message' => $sigResult['message'] . ' Please use the Aadhaar Paperless Offline XML upload method.'
            ];
        }

        // Parse fields separated by 0xFF delimiter
        $fields = explode("\xff", $dataStream);
        if (count($fields) < 5) {
            return [
                'valid'   => false,
                'code'    => 'MALFORMED_DELIMITERS',
                'message' => 'Unable to parse demographic fields from Secure QR payload. Format unrecognized.'
            ];
        }

        // UIDAI V2 Field Map:
        // [0] Email/Mobile presence flag, [1] Reference ID / Last 4, [2] Name, [3] DOB, [4] Gender,
        // [5] Care of, [6] District, [7] Landmark, [8] House, [9] Location, [10] Pincode, [11] Post office, [12] State
        $refId   = $fields[1] ?? '';
        $name    = $fields[2] ?? '';
        $dob     = $fields[3] ?? '';
        $gender  = $fields[4] ?? '';
        $co      = $fields[5] ?? '';
        $dist    = $fields[6] ?? '';
        $state   = $fields[12] ?? '';
        $pincode = $fields[10] ?? '';

        // Extract last 4 digits
        $last4 = '';
        if (preg_match('/[0-9]{4}/', $refId, $m)) {
            $last4 = $m[0];
        } else {
            $last4 = substr(preg_replace('/[^0-9]/', '', $refId), -4) ?: 'XXXX';
        }

        return [
            'valid'               => true,
            'code'                => 'VERIFIED',
            'verification_status' => 'Aadhaar document verified',
            'holder_check_status' => 'Holder check pending',
            'uidai_sig_status'    => $sigResult['status_label'],
            'aadhaar_last4'       => $last4,
            'reference_id'        => $refId,
            'name'                => $name,
            'dob'                 => $dob,
            'gender'              => $gender,
            'address'             => trim(implode(', ', array_filter([$co, $dist, $state, $pincode]))),
            'district'            => $dist,
            'state'               => $state,
            'pincode'             => $pincode,
            'message'             => 'Aadhaar Secure QR cryptographic signature and demographic payload validated.'
        ];
    }

    /**
     * Convert decimal big-integer string, base64, or raw byte string into raw bytes
     */
    private static function convertToBytes(string $input): string {
        // If entirely digits, decode as UIDAI decimal big-integer
        if (ctype_digit($input) && extension_loaded('bcmath')) {
            $hex = '';
            $num = $input;
            while (bccomp($num, '0') > 0) {
                $rem = (int)bcmod($num, '16');
                $hex = dechex($rem) . $hex;
                $num = bcdiv($num, '16', 0);
            }
            if (strlen($hex) % 2 !== 0) {
                $hex = '0' . $hex;
            }
            return hex2bin($hex) ?: '';
        }

        // Try base64 decoding
        if (preg_match('/^[A-Za-z0-9+\/]+={0,2}$/', $input) && (strlen($input) % 4 === 0)) {
            $decoded = base64_decode($input, true);
            if ($decoded !== false && strlen($decoded) > 100) {
                return $decoded;
            }
        }

        return $input;
    }

    /**
     * Verify the RSA-2048 digital signature of the QR code
     */
    private static function verifyQrSignature(string $signedData, string $signatureBytes, array $options): array {
        $testCertPath = dirname(__DIR__) . '/config/certificates/test_fixtures/test_uidai_cert.pem';
        $allowTest = !empty($options['allow_test_fixtures']);

        $candidateKeys = [];

        // Load trusted UIDAI certificates from both certificates/ and config/certificates/trusted_uidai/
        $trustDirs = [
            dirname(__DIR__) . '/certificates',
            dirname(__DIR__) . '/config/certificates/trusted_uidai',
            dirname(__DIR__) . '/config/certificates'
        ];

        $loadedFingerprints = [];
        foreach ($trustDirs as $dir) {
            if (is_dir($dir)) {
                $files = glob($dir . '/*.{pem,cer,crt}', GLOB_BRACE);
                if (!empty($files)) {
                    foreach ($files as $f) {
                        $fContent = file_get_contents($f);
                        $pem = AadhaarXmlVerifier::normalizeCertToPem($fContent);
                        if ($pem) {
                            $fp = hash('sha256', $pem);
                            if (isset($loadedFingerprints[$fp])) {
                                continue;
                            }
                            $loadedFingerprints[$fp] = true;
                            $k = @openssl_pkey_get_public($pem);
                            if ($k) {
                                $candidateKeys[] = [
                                    'key'     => $k,
                                    'label'   => 'AUTHENTIC_UIDAI_CERTIFICATE',
                                    'is_test' => false
                                ];
                            }
                        }
                    }
                }
            }
        }

        // In production mode (when test fixtures not allowed), detect and strictly reject synthetic test certificates
        if (!$allowTest && file_exists($testCertPath)) {
            $testPubKey = @openssl_pkey_get_public(file_get_contents($testCertPath));
            if ($testPubKey && @openssl_verify($signedData, $signatureBytes, $testPubKey, OPENSSL_ALGO_SHA256) === 1) {
                return [
                    'valid'   => false,
                    'code'    => 'TEST_CERT_REJECTED_IN_PRODUCTION',
                    'message' => 'Security Error: Synthetic test certificate signature detected. Test fixtures are strictly rejected in production.'
                ];
            }
        }

        // Load test fixture if allowed for automated tests
        if ($allowTest && file_exists($testCertPath)) {
            $candidateKeys[] = [
                'key' => @openssl_pkey_get_public(file_get_contents($testCertPath)),
                'label' => 'TEST_FIXTURE_VALID',
                'is_test' => true
            ];
        }

        if (empty($candidateKeys)) {
            return [
                'valid'   => false,
                'code'    => 'VERIFICATION_UNAVAILABLE',
                'message' => 'Verification unavailable: Official UIDAI certificates are not installed in the trust store (config/certificates/trusted_uidai/). Real Aadhaar Secure QR verification is unavailable until authentic UIDAI public certificates are installed.'
            ];
        }

        foreach ($candidateKeys as $cand) {
            if (!$cand['key']) continue;

            $ver = @openssl_verify($signedData, $signatureBytes, $cand['key'], OPENSSL_ALGO_SHA256);
            if ($ver === 1) {
                return [
                    'valid'        => true,
                    'status_label' => $cand['label']
                ];
            }
        }

        return [
            'valid'   => false,
            'code'    => 'SIGNATURE_VERIFICATION_FAILED',
            'message' => 'Secure QR signature verification failed against trusted UIDAI certificates.'
        ];
    }
}
