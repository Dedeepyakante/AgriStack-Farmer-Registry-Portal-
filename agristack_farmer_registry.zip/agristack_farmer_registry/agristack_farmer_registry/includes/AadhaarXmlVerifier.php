<?php
/**
 * AgriStack / AgriLink - Aadhaar Paperless Offline e-KYC (XML / ZIP) Verifier
 * 
 * Strict UIDAI Compliance, Cryptographic Signature Validation & Security Hardening:
 * 1. Content/magic-byte inspection (handles .tmp temporary uploads safely)
 * 2. Archive security: limits upload size (5MB), decompressed size (10MB), entry count, and path traversal
 * 3. XML security: disables external entities (XXE) and network resolution (LIBXML_NONET)
 * 4. XML Signature Wrapping (XSW) protection: validates single enveloped signature over root node
 * 5. Cryptographic signature check: validates XMLDSIG digest and RSA signature against trusted UIDAI certificates
 * 6. Isolated test fixtures: test certificates must be explicitly enabled and are rejected in production
 * 7. Privacy: extracts only required fields and masked last 4 digits; never retains full Aadhaar
 */

class AadhaarXmlVerifier {

    const MAX_UPLOAD_BYTES       = 5242880;  // 5MB
    const MAX_DECOMPRESSED_BYTES = 10485760; // 10MB
    const MAX_ARCHIVE_ENTRIES    = 5;

    /**
     * Verify an uploaded Aadhaar offline e-KYC file (XML or ZIP)
     * 
     * @param string|array $fileInput Path to file or $_FILES entry array
     * @param string|null  $shareCode Share code per UIDAI specification (supports any valid string)
     * @param array        $options   Verification options ('allow_test_fixtures' => bool)
     * @return array Result array with status, metadata and extracted fields
     */
    public static function verify($fileInput, ?string $shareCode = null, array $options = []): array {
        $filePath = is_array($fileInput) ? ($fileInput['tmp_name'] ?? '') : $fileInput;

        if (empty($filePath) || !file_exists($filePath)) {
            return [
                'valid'   => false,
                'code'    => 'FILE_NOT_FOUND',
                'message' => 'Upload file not found or temporary upload failed.'
            ];
        }

        // Apply upload size limit
        $fileSize = filesize($filePath);
        if ($fileSize <= 0 || $fileSize > self::MAX_UPLOAD_BYTES) {
            return [
                'valid'   => false,
                'code'    => 'FILE_SIZE_EXCEEDED',
                'message' => 'Uploaded file size exceeds the allowed limit (maximum 5MB).'
            ];
        }

        // Read initial bytes to determine format independent of extension or .tmp name
        $handle = @fopen($filePath, 'rb');
        if (!$handle) {
            return [
                'valid'   => false,
                'code'    => 'FILE_READ_ERROR',
                'message' => 'Unable to read uploaded file contents.'
            ];
        }
        $headerBytes = fread($handle, 16);
        fclose($handle);

        $xmlContent = null;

        // Magic byte check: ZIP files start with PK\x03\x04
        if (str_starts_with($headerBytes, "PK\x03\x04")) {
            $zipResult = self::extractXmlFromZip($filePath, $shareCode);
            if (!$zipResult['success']) {
                return [
                    'valid'   => false,
                    'code'    => $zipResult['code'],
                    'message' => $zipResult['message']
                ];
            }
            $xmlContent = $zipResult['xml'];
        } 
        // Magic byte check: XML files start with <?xml or <OfflinePaperlessKyc
        elseif (str_starts_with(trim($headerBytes), '<?xml') || str_contains($headerBytes, '<OfflinePaperlessKyc')) {
            $xmlContent = file_get_contents($filePath);
        } else {
            return [
                'valid'   => false,
                'code'    => 'UNSUPPORTED_FORMAT',
                'message' => 'Unsupported format: File is neither a valid ZIP archive nor an Aadhaar offline XML document.'
            ];
        }

        if (empty($xmlContent) || strlen($xmlContent) > self::MAX_DECOMPRESSED_BYTES) {
            return [
                'valid'   => false,
                'code'    => 'MALFORMED_CONTENT',
                'message' => 'Decompressed XML content is empty or exceeds the maximum size limit (10MB).'
            ];
        }

        // Cryptographically validate the XML document
        return self::validateXmlDocument($xmlContent, $shareCode, $options);
    }

    /**
     * Safely extract XML from password-protected ZIP archive
     */
    private static function extractXmlFromZip(string $zipPath, ?string $shareCode): array {
        if (!class_exists('ZipArchive')) {
            return [
                'success' => false,
                'code'    => 'ZIP_EXTENSION_MISSING',
                'message' => 'Server configuration error: PHP Zip extension is not enabled.'
            ];
        }

        $zip = new ZipArchive();
        $openRes = $zip->open($zipPath, ZipArchive::RDONLY);
        if ($openRes !== true) {
            return [
                'success' => false,
                'code'    => 'CORRUPTED_ARCHIVE',
                'message' => 'Failed to open ZIP archive. The file may be corrupted.'
            ];
        }

        // Archive entry count limit (zip bomb defense)
        if ($zip->numFiles <= 0 || $zip->numFiles > self::MAX_ARCHIVE_ENTRIES) {
            $zip->close();
            return [
                'success' => false,
                'code'    => 'ARCHIVE_LIMIT_EXCEEDED',
                'message' => 'ZIP archive contains an invalid number of entries.'
            ];
        }

        // Apply Share Code password if provided
        if (!empty($shareCode)) {
            $zip->setPassword($shareCode);
        }

        $xmlData = null;
        $totalDecompressedSize = 0;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $entryName = $stat['name'] ?? '';
            $entrySize = $stat['size'] ?? 0;

            // Path traversal defense: reject entries with relative or absolute paths
            if (str_contains($entryName, '..') || str_contains($entryName, '/') || str_contains($entryName, '\\')) {
                $zip->close();
                return [
                    'success' => false,
                    'code'    => 'PATH_TRAVERSAL_DETECTED',
                    'message' => 'Security violation: Archive entry contains path traversal characters.'
                ];
            }

            $totalDecompressedSize += $entrySize;
            if ($totalDecompressedSize > self::MAX_DECOMPRESSED_BYTES) {
                $zip->close();
                return [
                    'success' => false,
                    'code'    => 'DECOMPRESSION_SIZE_EXCEEDED',
                    'message' => 'Total decompressed size of ZIP archive exceeds maximum threshold.'
                ];
            }

            if (str_ends_with(strtolower($entryName), '.xml')) {
                // Read entry content using configured password
                $content = $zip->getFromIndex($i);
                if ($content === false) {
                    $zip->close();
                    return [
                        'success' => false,
                        'code'    => 'WRONG_SHARE_CODE',
                        'message' => 'Incorrect Share Code or unable to decrypt password-protected ZIP archive.'
                    ];
                }
                $xmlData = $content;
            }
        }

        $zip->close();

        if ($xmlData === null) {
            return [
                'success' => false,
                'code'    => 'XML_ENTRY_MISSING',
                'message' => 'No valid .xml file found inside the ZIP archive.'
            ];
        }

        return ['success' => true, 'xml' => $xmlData];
    }

    /**
     * Validate XML structure, enveloped signature, digest, and certificate trust
     */
    public static function validateXmlDocument(string $xmlContent, ?string $shareCode, array $options): array {
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $loadFlags = LIBXML_NONET | LIBXML_NOENT | LIBXML_NOWARNING;

        if (!$dom->loadXML($xmlContent, $loadFlags)) {
            $errors = libxml_get_errors();
            libxml_clear_errors();
            return [
                'valid'   => false,
                'code'    => 'XML_PARSE_ERROR',
                'message' => 'Malformed or unparseable XML document.'
            ];
        }

        $xpath = new DOMXPath($dom);
        $xpath->registerNamespace('ds', 'http://www.w3.org/2000/09/xmldsig#');

        // Root element check
        $rootNode = $dom->documentElement;
        if (!$rootNode || $rootNode->localName !== 'OfflinePaperlessKyc') {
            return [
                'valid'   => false,
                'code'    => 'INVALID_ROOT_ELEMENT',
                'message' => 'XML does not conform to Aadhaar Offline Paperless e-KYC specification (Missing root <OfflinePaperlessKyc>).'
            ];
        }

        // XML Signature Wrapping (XSW) Defense: exactly ONE Signature element allowed
        $sigList = $xpath->query('//ds:Signature');
        if ($sigList->length === 0) {
            // Also check non-namespaced Signature
            $sigList = $xpath->query('//*[local-name()="Signature"]');
        }

        if ($sigList->length === 0) {
            return [
                'valid'   => false,
                'code'    => 'SIGNATURE_MISSING',
                'message' => 'Digital Signature Missing: XML does not contain a <ds:Signature> element.'
            ];
        }

        if ($sigList->length > 1) {
            return [
                'valid'   => false,
                'code'    => 'SIGNATURE_WRAPPING_ATTACK',
                'message' => 'Security Error: Multiple signatures detected. Document rejected due to potential XML Signature Wrapping.'
            ];
        }

        $signatureNode = $sigList->item(0);

        // Extract SignatureValue, SignedInfo, DigestValue, and X509Certificate
        $sigValueNode   = $xpath->query('.//*[local-name()="SignatureValue"]', $signatureNode)->item(0);
        $signedInfoNode = $xpath->query('.//*[local-name()="SignedInfo"]', $signatureNode)->item(0);
        $digestNode     = $xpath->query('.//*[local-name()="DigestValue"]', $signedInfoNode)->item(0);
        $certNode       = $xpath->query('.//*[local-name()="X509Certificate"]', $signatureNode)->item(0);

        if (!$sigValueNode || !$signedInfoNode || !$digestNode || !$certNode) {
            return [
                'valid'   => false,
                'code'    => 'INCOMPLETE_SIGNATURE',
                'message' => 'Digital signature elements (SignatureValue, SignedInfo, DigestValue, or X509Certificate) are incomplete.'
            ];
        }

        $embeddedCertRaw = trim($certNode->nodeValue);
        if (empty($embeddedCertRaw)) {
            return [
                'valid'   => false,
                'code'    => 'CERTIFICATE_EMPTY',
                'message' => 'X509 Certificate payload is missing or empty in digital signature.'
            ];
        }

        // Clean all internal whitespace, newlines, and carriage returns from the base64 certificate payload
        $cleanCertBase64 = preg_replace('/\s+/', '', $embeddedCertRaw);
        if (empty($cleanCertBase64) || !preg_match('/^[a-zA-Z0-9+\/]+={0,2}$/', $cleanCertBase64)) {
            return [
                'valid'   => false,
                'code'    => 'MALFORMED_CERTIFICATE_BASE64',
                'message' => 'Embedded X.509 certificate contains invalid base64 encoding.'
            ];
        }

        $certPem = "-----BEGIN CERTIFICATE-----\n" . chunk_split($cleanCertBase64, 64, "\n") . "-----END CERTIFICATE-----\n";
        $pubKey = @openssl_pkey_get_public($certPem);
        if (!$pubKey) {
            $osslError = openssl_error_string() ?: 'Invalid X.509 structure';
            return [
                'valid'   => false,
                'code'    => 'INVALID_CERTIFICATE_PEM',
                'message' => 'Unable to parse X.509 public key from the embedded certificate: ' . $osslError
            ];
        }

        // =====================================================================
        // Digest Verification (Enveloped Signature)
        // =====================================================================
        $domClone = clone $dom;
        $cloneXpath = new DOMXPath($domClone);
        $cloneSigNode = $cloneXpath->query('//*[local-name()="Signature"]')->item(0);
        if ($cloneSigNode && $cloneSigNode->parentNode) {
            $cloneSigNode->parentNode->removeChild($cloneSigNode);
        }

        $actualDigest = trim($digestNode->nodeValue);
        $digestMethodNode = $xpath->query('.//*[local-name()="DigestMethod"]', $signedInfoNode)->item(0);
        $digestAlgo = $digestMethodNode ? $digestMethodNode->getAttribute('Algorithm') : '';
        $hashAlgo = str_contains($digestAlgo, 'sha1') ? 'sha1' : 'sha256';

        // Check canonicalization method in transforms
        $transformNodes = $xpath->query('.//*[local-name()="Transform"]', $signedInfoNode);
        $isExcTransform = false;
        foreach ($transformNodes as $tn) {
            if (str_contains($tn->getAttribute('Algorithm'), 'exc-c14n')) {
                $isExcTransform = true;
                break;
            }
        }

        $c14nEnveloped = $domClone->C14N($isExcTransform, false);
        $expectedDigest = base64_encode(hash($hashAlgo, $c14nEnveloped, true));

        // If not matched, try alternate canonicalization (inclusive vs exclusive)
        if ($actualDigest !== $expectedDigest) {
            $c14nAlt = $domClone->C14N(!$isExcTransform, false);
            $expectedDigestAlt = base64_encode(hash($hashAlgo, $c14nAlt, true));
            if ($actualDigest === $expectedDigestAlt) {
                $expectedDigest = $expectedDigestAlt;
            }
        }

        if ($actualDigest !== $expectedDigest) {
            return [
                'valid'   => false,
                'code'    => 'DIGEST_MISMATCH',
                'message' => 'Cryptographic Digest Mismatch: The demographic data in the document has been altered or tampered with.'
            ];
        }

        // =====================================================================
        // Signature Value Verification (RSA over SignedInfo C14N)
        // =====================================================================
        $sigMethodNode = $xpath->query('.//*[local-name()="SignatureMethod"]', $signedInfoNode)->item(0);
        $sigMethodAlgo = $sigMethodNode ? $sigMethodNode->getAttribute('Algorithm') : '';
        $opensslAlgo = OPENSSL_ALGO_SHA256;
        if (str_contains($sigMethodAlgo, 'sha1')) {
            $opensslAlgo = OPENSSL_ALGO_SHA1;
        } elseif (str_contains($sigMethodAlgo, 'sha384')) {
            $opensslAlgo = OPENSSL_ALGO_SHA384;
        } elseif (str_contains($sigMethodAlgo, 'sha512')) {
            $opensslAlgo = OPENSSL_ALGO_SHA512;
        }

        $c14nMethodNode = $xpath->query('.//*[local-name()="CanonicalizationMethod"]', $signedInfoNode)->item(0);
        $c14nMethodAlgo = $c14nMethodNode ? $c14nMethodNode->getAttribute('Algorithm') : '';
        $isExcSignedInfo = str_contains($c14nMethodAlgo, 'exc-c14n');

        $c14nSignedInfo = $signedInfoNode->C14N($isExcSignedInfo, false);
        $signatureBytes = base64_decode(preg_replace('/\s+/', '', $sigValueNode->nodeValue));

        $sigVerifyStatus = @openssl_verify($c14nSignedInfo, $signatureBytes, $pubKey, $opensslAlgo);
        if ($sigVerifyStatus !== 1) {
            // Also test alternate C14N for SignedInfo
            $c14nSignedInfoAlt = $signedInfoNode->C14N(!$isExcSignedInfo, false);
            if (@openssl_verify($c14nSignedInfoAlt, $signatureBytes, $pubKey, $opensslAlgo) === 1) {
                $sigVerifyStatus = 1;
                $c14nSignedInfo = $c14nSignedInfoAlt;
            }
        }

        if ($sigVerifyStatus !== 1) {
            return [
                'valid'   => false,
                'code'    => 'SIGNATURE_INVALID',
                'message' => 'Digital Signature Invalid: The cryptographic signature does not match the SignedInfo payload.'
            ];
        }

        // =====================================================================
        // Certificate Trust Validation (Never trust solely because it's embedded)
        // =====================================================================
        $certParsed = openssl_x509_parse($certPem);
        $certSubject = $certParsed['name'] ?? '';
        $isTestFixture = str_contains($certSubject, 'TEST FIXTURE ONLY');

        $allowTestFixtures = !empty($options['allow_test_fixtures']);
        $isTrusted = false;
        $trustLabel = 'UNVERIFIED';

        // Check directories for trusted certificates
        $trustDirs = [
            dirname(__DIR__) . '/certificates',
            dirname(__DIR__) . '/config/certificates/trusted_uidai',
            dirname(__DIR__) . '/config/certificates'
        ];

        $trustedCertEntries = [];
        $loadedFingerprints = [];
        foreach ($trustDirs as $dir) {
            if (is_dir($dir)) {
                $files = glob($dir . '/*.{pem,cer,crt}', GLOB_BRACE);
                if (!empty($files)) {
                    foreach ($files as $f) {
                        $fContent = file_get_contents($f);
                        $pemNormalized = self::normalizeCertToPem($fContent);
                        if ($pemNormalized) {
                            $fp = hash('sha256', $pemNormalized);
                            if (isset($loadedFingerprints[$fp])) {
                                continue;
                            }
                            $loadedFingerprints[$fp] = true;
                            $trustedKey = @openssl_pkey_get_public($pemNormalized);
                            if ($trustedKey) {
                                $trustedCertEntries[] = [
                                    'path' => $f,
                                    'pem'  => $pemNormalized,
                                    'key'  => $trustedKey
                                ];
                            }
                        }
                    }
                }
            }
        }

        // Compare against authentic trusted certificates
        foreach ($trustedCertEntries as $entry) {
            // 1. Certificate equality (DER or PEM comparison)
            if (self::areCertificatesEqual($certPem, $entry['pem'])) {
                $isTrusted = true;
                $trustLabel = 'AUTHENTIC_UIDAI_CERTIFICATE';
                break;
            }

            // 2. Public key equality
            if (self::arePublicKeysEqual($pubKey, $entry['key'])) {
                $isTrusted = true;
                $trustLabel = 'AUTHENTIC_UIDAI_CERTIFICATE';
                break;
            }

            // 3. Direct signature verification against trusted certificate public key
            if (@openssl_verify($c14nSignedInfo, $signatureBytes, $entry['key'], $opensslAlgo) === 1) {
                $isTrusted = true;
                $trustLabel = 'AUTHENTIC_UIDAI_CERTIFICATE';
                break;
            }
        }

        // Test fixture path check
        if (!$isTrusted && $isTestFixture) {
            if ($allowTestFixtures) {
                $isTrusted = true;
                $trustLabel = 'TEST_FIXTURE_VALID';
            } else {
                return [
                    'valid'   => false,
                    'code'    => 'TEST_CERT_REJECTED_IN_PRODUCTION',
                    'message' => 'Security Error: Synthetic test certificate detected. Test fixtures are strictly rejected in production.'
                ];
            }
        }

        if (!$isTrusted) {
            $trustedCount = count($trustedCertEntries);
            if ($trustedCount === 0 && !$allowTestFixtures) {
                return [
                    'valid'   => false,
                    'code'    => 'VERIFICATION_UNAVAILABLE',
                    'message' => 'Verification unavailable: Official UIDAI certificates are not installed in the trust store (certificates/ or config/certificates/trusted_uidai/). Real Aadhaar verification is unavailable until authentic UIDAI public certificates are installed.'
                ];
            }
            return [
                'valid'   => false,
                'code'    => 'UNTRUSTED_ROOT_CERTIFICATE',
                'message' => 'Untrusted Certificate: The certificate used to sign this document is not recognized by trusted UIDAI authorities.'
            ];
        }

        // =====================================================================
        // Extract Demographics (Only fields covered by validated signature)
        // =====================================================================
        $referenceId  = (string)$rootNode->getAttribute('referenceId');
        // Masked Aadhaar last 4 digits (first 4 digits of referenceId per UIDAI format)
        $aadhaarLast4 = preg_match('/^[0-9]{4}/', $referenceId, $m) ? $m[0] : substr($referenceId, 0, 4);

        $poiNode = $xpath->query('/OfflinePaperlessKyc/UidData/Poi')->item(0);
        $poaNode = $xpath->query('/OfflinePaperlessKyc/UidData/Poa')->item(0);

        $name   = $poiNode ? (string)$poiNode->getAttribute('name') : '';
        $dob    = $poiNode ? (string)$poiNode->getAttribute('dob') : '';
        $gender = $poiNode ? (string)$poiNode->getAttribute('gender') : '';

        $dist  = $poaNode ? (string)$poaNode->getAttribute('dist') : '';
        $state = $poaNode ? (string)$poaNode->getAttribute('state') : '';
        $pc    = $poaNode ? (string)$poaNode->getAttribute('pc') : '';
        $co    = $poaNode ? (string)$poaNode->getAttribute('co') : '';
        $house = $poaNode ? (string)$poaNode->getAttribute('house') : '';
        $loc   = $poaNode ? (string)$poaNode->getAttribute('loc') : '';
        $vtc   = $poaNode ? (string)$poaNode->getAttribute('vtc') : '';

        $fullAddress = trim(implode(', ', array_filter([$house, $loc, $vtc, $dist, $state, $pc])));

        return [
            'valid'                => true,
            'code'                 => 'VERIFIED',
            'verification_status'  => 'Aadhaar document verified',
            'holder_check_status'  => 'Holder check pending',
            'uidai_sig_status'     => $trustLabel,
            'aadhaar_last4'        => $aadhaarLast4,
            'reference_id'         => $referenceId,
            'name'                 => $name,
            'dob'                  => $dob,
            'gender'               => $gender,
            'address'              => $fullAddress,
            'district'             => $dist,
            'state'                => $state,
            'pincode'              => $pc,
            'cert_subject'         => $certSubject,
            'message'              => 'Aadhaar offline e-KYC digital signature and cryptographic integrity verified.'
        ];
    }

    /**
     * Normalize certificate data (whether PEM, raw Base64, or binary DER) into a valid PEM string
     */
    public static function normalizeCertToPem(string $rawContent): ?string {
        if (str_contains($rawContent, '-----BEGIN CERTIFICATE-----')) {
            $clean = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $rawContent);
            $pem = "-----BEGIN CERTIFICATE-----\n" . chunk_split($clean, 64, "\n") . "-----END CERTIFICATE-----\n";
            return @openssl_x509_read($pem) ? $pem : null;
        }

        // Check if raw Base64 string without PEM headers
        $cleanBase64 = preg_replace('/\s+/', '', $rawContent);
        if (!empty($cleanBase64) && preg_match('/^[a-zA-Z0-9+\/]+={0,2}$/', $cleanBase64)) {
            $candidatePem = "-----BEGIN CERTIFICATE-----\n" . chunk_split($cleanBase64, 64, "\n") . "-----END CERTIFICATE-----\n";
            if (@openssl_x509_read($candidatePem)) {
                return $candidatePem;
            }
        }

        // Check if binary DER data
        $b64Der = base64_encode($rawContent);
        $candidatePem = "-----BEGIN CERTIFICATE-----\n" . chunk_split($b64Der, 64, "\n") . "-----END CERTIFICATE-----\n";
        if (@openssl_x509_read($candidatePem)) {
            return $candidatePem;
        }

        return null;
    }

    /**
     * Compare public keys / certificates for cryptographic equality
     */
    private static function areCertificatesEqual(string $pemA, string $pemB): bool {
        $cleanA = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $pemA);
        $cleanB = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $pemB);
        return hash_equals($cleanA, $cleanB);
    }

    /**
     * Compare two OpenSSL public key resources/objects for equality
     */
    private static function arePublicKeysEqual($keyA, $keyB): bool {
        $detailsA = @openssl_pkey_get_details($keyA);
        $detailsB = @openssl_pkey_get_details($keyB);
        if (!$detailsA || !$detailsB) {
            return false;
        }
        return !empty($detailsA['key']) && !empty($detailsB['key']) && hash_equals($detailsA['key'], $detailsB['key']);
    }
}
