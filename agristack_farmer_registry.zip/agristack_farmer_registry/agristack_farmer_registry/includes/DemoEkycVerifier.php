<?php
/**
 * AgriLink / AgriStack Farmer Registry - Demo e-KYC Verifier
 * 
 * Handles custom demonstration e-KYC files (<AgriLinkDemoEKYC version="1.0" demo="true">)
 * on a separate processing path, completely decoupled from the production UIDAI Aadhaar verifier.
 * 
 * Rules:
 * 1. Allowed ONLY when server-side DEMO_MODE is enabled.
 * 2. Parses XML safely (XXE protected via LIBXML_NONET) and validates AgriLinkDemoEKYC structure.
 * 3. Extracts fictional farmer details for preview.
 * 4. Sets status on server to demo_completed. Never trusts verification flags inside uploaded XML.
 * 5. Displays "DEMO — Not Aadhaar verified".
 * 6. Keeps demo results separate from genuine identity verification (does not unlock actions requiring verified identity).
 * 7. When DEMO_MODE is disabled, rejects with "Demo files are disabled".
 * 8. Preserves all production Aadhaar checks (official XML is never modified or bypassed).
 */

require_once __DIR__ . '/../config/demo.php';

class DemoEkycVerifier {

    const MAX_UPLOAD_BYTES = 5242880; // 5 MB

    /**
     * Check if raw file or archive content represents an AgriLinkDemoEKYC document
     */
    public static function isDemoUpload(string $filePath, ?string $shareCode = null): bool {
        $xmlContent = self::readXmlContent($filePath, $shareCode);
        if (!$xmlContent) {
            return false;
        }
        return self::isDemoXml($xmlContent);
    }

    /**
     * Inspect XML content to check for AgriLinkDemoEKYC root
     */
    public static function isDemoXml(string $xmlContent): bool {
        // Fast pre-check before DOM parsing
        if (!str_contains($xmlContent, 'AgriLinkDemoEKYC')) {
            return false;
        }

        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $loaded = $dom->loadXML($xmlContent, LIBXML_NONET | LIBXML_NOWARNING);
        libxml_clear_errors();

        if (!$loaded || !$dom->documentElement) {
            return false;
        }

        return $dom->documentElement->localName === 'AgriLinkDemoEKYC';
    }

    /**
     * Safely read XML content from direct XML file or ZIP archive
     */
    public static function readXmlContent(string $filePath, ?string $shareCode = null): ?string {
        if (!file_exists($filePath) || filesize($filePath) > self::MAX_UPLOAD_BYTES) {
            return null;
        }

        $handle = @fopen($filePath, 'rb');
        if (!$handle) return null;
        $magic = fread($handle, 4);
        fclose($handle);

        // ZIP Archive
        if ($magic === "PK\x03\x04") {
            if (!class_exists('ZipArchive')) return null;
            $zip = new ZipArchive();
            if ($zip->open($filePath, ZipArchive::RDONLY) !== true) {
                return null;
            }
            if (!empty($shareCode)) {
                $zip->setPassword($shareCode);
            }
            $xml = null;
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $stat = $zip->statIndex($i);
                $name = $stat['name'] ?? '';
                if (str_ends_with(strtolower($name), '.xml') || str_contains($name, 'AgriLink') || str_contains($name, 'eKYC')) {
                    $stream = $zip->getStream($name);
                    if ($stream) {
                        $xml = stream_get_contents($stream);
                        fclose($stream);
                        break;
                    }
                }
            }
            $zip->close();
            return $xml;
        }

        // Direct XML file
        return file_get_contents($filePath);
    }

    /**
     * Process and validate demo e-KYC document
     */
    public static function verify(string $filePath, ?string $shareCode = null): array {
        // Rule 1 & 7: Check server-side DEMO_MODE
        if (!isDemoModeEnabled()) {
            return [
                'valid'   => false,
                'code'    => 'DEMO_MODE_DISABLED',
                'message' => 'Demo files are disabled'
            ];
        }

        $xmlContent = self::readXmlContent($filePath, $shareCode);
        if (!$xmlContent) {
            return [
                'valid'   => false,
                'code'    => 'EMPTY_OR_UNREADABLE',
                'message' => 'Unable to read demo XML file or archive.'
            ];
        }

        // Rule 2: Parse XML safely and validate AgriLinkDemoEKYC structure
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $loaded = $dom->loadXML($xmlContent, LIBXML_NONET | LIBXML_NOWARNING);
        $errors = libxml_get_errors();
        libxml_clear_errors();

        if (!$loaded || !$dom->documentElement) {
            return [
                'valid'   => false,
                'code'    => 'MALFORMED_DEMO_XML',
                'message' => 'Malformed demo XML document.'
            ];
        }

        $root = $dom->documentElement;
        if ($root->localName !== 'AgriLinkDemoEKYC') {
            return [
                'valid'   => false,
                'code'    => 'INVALID_DEMO_ROOT',
                'message' => 'Invalid demo file: Root element must be <AgriLinkDemoEKYC>.'
            ];
        }

        $xpath = new DOMXPath($dom);

        $farmerDetails = $xpath->query('//FarmerDetails | //Farmer')->item(0);
        if (!$farmerDetails) {
            return [
                'valid'   => false,
                'code'    => 'INVALID_DEMO_STRUCTURE',
                'message' => 'Invalid demo file: Missing <FarmerDetails> structure.'
            ];
        }

        // Rule 3: Extract fictional farmer details for preview
        // 1. Name
        $name = '';
        $nameQueries = ['//FarmerDetails/Name', '//FarmerDetails/name', '//Farmer/Name', '//Farmer/@name', '//Poi/@name', '//Name', '//FullName', '//name'];
        foreach ($nameQueries as $q) {
            $node = $xpath->query($q)->item(0);
            if ($node) {
                $val = trim($node->nodeValue);
                if (!empty($val) && $val !== 'true' && $val !== '1.0') {
                    $name = $val;
                    break;
                }
            }
        }
        if (empty($name)) {
            $name = 'Demo Farmer (Fictional)';
        }

        // 2. Date of Birth
        $dob = '';
        $dobQueries = ['//FarmerDetails/Dob', '//FarmerDetails/DOB', '//Farmer/Dob', '//Farmer/@dob', '//Poi/@dob', '//Dob', '//DOB', '//dob', '//DateOfBirth'];
        foreach ($dobQueries as $q) {
            $node = $xpath->query($q)->item(0);
            if ($node) {
                $val = trim($node->nodeValue);
                if (!empty($val)) {
                    $dob = $val;
                    break;
                }
            }
        }
        if (empty($dob)) {
            $dob = '1985-01-01';
        }

        // 3. Gender
        $gender = '';
        $genderQueries = ['//FarmerDetails/Gender', '//Farmer/Gender', '//Farmer/@gender', '//Poi/@gender', '//Gender', '//gender'];
        foreach ($genderQueries as $q) {
            $node = $xpath->query($q)->item(0);
            if ($node) {
                $val = trim($node->nodeValue);
                if (!empty($val)) {
                    $gender = strtoupper(substr($val, 0, 1));
                    break;
                }
            }
        }
        if (empty($gender)) {
            $gender = 'M';
        }

        // 4. Address
        $address = '';
        $addrQueries = ['//FarmerDetails/Address', '//Farmer/Address', '//Address', '//address', '//FullAddress'];
        foreach ($addrQueries as $q) {
            $node = $xpath->query($q)->item(0);
            if ($node) {
                $val = trim($node->nodeValue);
                if (!empty($val)) {
                    $address = $val;
                    break;
                }
            }
        }
        if (empty($address)) {
            // Check Poa attributes
            $poa = $xpath->query('//Poa')->item(0);
            if ($poa) {
                $parts = [];
                foreach (['co', 'house', 'street', 'lm', 'loc', 'vtc', 'dist', 'state', 'pc'] as $attr) {
                    if ($poa->hasAttribute($attr) && !empty($poa->getAttribute($attr))) {
                        $parts[] = $poa->getAttribute($attr);
                    }
                }
                if (!empty($parts)) $address = implode(', ', $parts);
            }
        }
        if (empty($address)) {
            $address = 'Village Demo, Mandal Demo, District Guntur, Andhra Pradesh - 522002';
        }

        // 5. Masked Aadhaar / Demo Last 4
        $last4 = '';
        $last4Queries = ['//FarmerDetails/AadhaarLast4', '//Farmer/AadhaarLast4', '//AadhaarLast4', '//aadhaar_last4', '//Last4', '//last4', '//Uid', '//@aadhaar_last4'];
        foreach ($last4Queries as $q) {
            $node = $xpath->query($q)->item(0);
            if ($node) {
                $val = trim($node->nodeValue);
                $digits = preg_replace('/\D/', '', $val);
                if (strlen($digits) >= 4) {
                    $last4 = substr($digits, -4);
                    break;
                }
            }
        }
        if (empty($last4)) {
            $last4 = '0001';
        }

        // 6. Phone
        $phone = '';
        $phoneNode = $xpath->query('//FarmerDetails/Phone | //Farmer/Phone | //Phone')->item(0);
        if ($phoneNode) {
            $phone = trim($phoneNode->nodeValue);
        }

        // 7. Email
        $email = '';
        $emailNode = $xpath->query('//FarmerDetails/Email | //Farmer/Email | //Email')->item(0);
        if ($emailNode) {
            $email = trim($emailNode->nodeValue);
        }

        // 8. Photo (if embedded)
        $photo = '';
        $photoNodes = $xpath->query('//FarmerDetails/Photo | //Photo | //photo | //Pht');
        if ($photoNodes->length > 0) {
            $photo = trim($photoNodes->item(0)->nodeValue);
        }

        // Rule 4: Set the result status on the server to demo_completed.
        // Never trust verification flags supplied inside the uploaded XML.
        // Rule 5: Display "DEMO — Not Aadhaar verified".
        // Rule 6: Keep demo results separate from genuine identity verification.
        return [
            'valid'               => true,
            'is_demo'             => true,
            'verification_status' => 'demo_completed',
            'status_display'      => 'DEMO — Not Aadhaar verified',
            'holder_check_status' => 'Not verified (Demo mode)',
            'uidai_sig_status'    => 'DEMO_NOT_VERIFIED',
            'name'                => $name,
            'dob'                 => $dob,
            'gender'              => $gender,
            'address'             => $address,
            'aadhaar_last4'       => $last4,
            'phone'               => $phone,
            'email'               => $email,
            'photo'               => $photo,
            'message'             => 'DEMO — Not Aadhaar verified'
        ];
    }
}
