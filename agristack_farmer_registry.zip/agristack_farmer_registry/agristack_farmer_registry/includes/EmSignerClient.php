<?php
/**
 * AgriLink / AgriStack Farmer Registry - Official emSigner API Client
 * 
 * Implements the official emSigner (eMudhra) REST API workflow:
 * 1. AuthorizeApp (Bearer / AuthToken generation)
 * 2. InitiateEmbeddedSigning (Generates genuine signing session URL & Workflow ID)
 * 3. GetWorkflowInfo (Status check)
 * 4. DownloadWorkflowDocuments (Retrieval of cryptographically sealed PDF)
 * 5. Signing Invitation Email Dispatch
 * 
 * Rules:
 * - Credentials are kept strictly server-side.
 * - Never returns secret codes or keys in responses.
 */

require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/../config/mailer.php';

class EmSignerClient {
    private static ?string $cachedToken = null;
    private static int $tokenExpiresAt = 0;

    /**
     * Determine whether official credentials are configured
     */
    public static function isConfigured(): bool {
        return function_exists('isVerifiedEsignConfigured') && isVerifiedEsignConfigured();
    }

    /**
     * Authorize application against emSigner API to obtain a JWT AuthToken
     */
    public static function authorizeApp(bool $forceRefresh = false): array {
        if (!self::isConfigured()) {
            return [
                'success' => false,
                'error'   => 'emSigner credentials are not configured in .env'
            ];
        }

        // Return cached token if valid
        $now = time();
        if (!$forceRefresh && self::$cachedToken && self::$tokenExpiresAt > ($now + 60)) {
            return [
                'success' => true,
                'token'   => self::$cachedToken
            ];
        }

        if (!$forceRefresh && !empty($_SESSION['emsigner_auth_token']) && ($_SESSION['emsigner_auth_token_exp'] ?? 0) > ($now + 60)) {
            self::$cachedToken = $_SESSION['emsigner_auth_token'];
            self::$tokenExpiresAt = (int)$_SESSION['emsigner_auth_token_exp'];
            return [
                'success' => true,
                'token'   => self::$cachedToken
            ];
        }

        $url = rtrim(ESIGN_API_BASE_URL, '/') . '/AuthorizeApp';
        $payload = [
            'AppName'   => EMSIGNER_APP_NAME,
            'SecretKey' => EMSIGNER_SECRET_CODE
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Accept: application/json'
            ],
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ]);

        $rawResponse = curl_exec($ch);
        $httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError   = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return [
                'success' => false,
                'error'   => 'emSigner connection error: ' . $curlError
            ];
        }

        $data = json_decode($rawResponse, true);
        if (!$data || !($data['IsSuccess'] ?? false)) {
            $msg = !empty($data['Messages']) ? implode('; ', (array)$data['Messages']) : 'Failed to authorize application';
            return [
                'success' => false,
                'error'   => "emSigner AuthorizeApp Error (HTTP {$httpCode}): {$msg}"
            ];
        }

        $token = $data['Response']['AuthToken'] ?? null;
        if (empty($token)) {
            return [
                'success' => false,
                'error'   => 'emSigner did not return an AuthToken'
            ];
        }

        // Cache token for 15 minutes
        self::$cachedToken = $token;
        self::$tokenExpiresAt = $now + 900;
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['emsigner_auth_token'] = $token;
            $_SESSION['emsigner_auth_token_exp'] = self::$tokenExpiresAt;
        }

        return [
            'success' => true,
            'token'   => $token
        ];
    }

    /**
     * Create an official emSigner embedded signing session
     */
    public static function initiateSigningSession(array $params): array {
        $auth = self::authorizeApp();
        if (!$auth['success']) {
            return [
                'success' => false,
                'error'   => $auth['error']
            ];
        }
        $token = $auth['token'];

        $url = rtrim(ESIGN_API_BASE_URL, '/') . '/InitiateEmbeddedSigning';

        $refNo         = $params['reference_no'] ?? ('AGRI-' . date('YmdHis') . '-' . substr(uniqid(), -4));
        $docName       = $params['document_name'] ?? 'Document.pdf';
        $fileData      = $params['file_data_base64'] ?? '';
        $signerEmail   = $params['signer_email'] ?? '';
        $signerName    = $params['signer_name'] ?? 'Signer';
        $initiatorName = $params['initiator_name'] ?? 'AgriStack Portal';
        $initiatorMail = $params['initiator_email'] ?? (!empty(SMTP_FROM_EMAIL) ? SMTP_FROM_EMAIL : 'admin@agristack.gov.in');
        $redirectUrl   = $params['redirect_url'] ?? '';
        $modes         = $params['mode_of_signature'] ?? '1,2,3,12';

        if (empty($fileData)) {
            return [
                'success' => false,
                'error'   => 'Document file data is empty'
            ];
        }

        if (empty($signerEmail)) {
            return [
                'success' => false,
                'error'   => 'Signer email address is required for emSigner session'
            ];
        }

        $payload = [
            'WorkflowType'        => 1, // Serial
            'ReferenceNo'         => $refNo,
            'RedirectURL'         => $redirectUrl,
            'Name'                => $initiatorName,
            'EmailId'             => $initiatorMail,
            'DoNotNotifyCustomer' => false, // Allow emSigner notification if enabled
            'DonotSendCompletionMailToParticipants' => false,
            'SignatoryEmailIds'   => [$signerEmail],
            'SignatureSettings'   => [
                [
                    'ModeOfSignature' => (string)$modes,
                    'Name'            => $signerName
                ]
            ],
            'lstDocumentDetails'  => [
                [
                    'DocumentName'   => $docName,
                    'FileData'       => $fileData,
                    'ControlDetails' => [
                        [
                            'Width'      => 160,
                            'Top'        => 127,
                            'Page'       => 'All',
                            'Left'       => 40,
                            'Height'     => 83,
                            'ControlID'  => 4,
                            'AssignedTo' => 1
                        ]
                    ]
                ]
            ]
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: basic ' . $token
            ],
            CURLOPT_TIMEOUT        => 35,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ]);

        $rawResponse = curl_exec($ch);
        $httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError   = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            return [
                'success' => false,
                'error'   => 'emSigner connection error: ' . $curlError
            ];
        }

        $data = json_decode($rawResponse, true);
        if (!$data || !($data['IsSuccess'] ?? false)) {
            $msg = !empty($data['Messages']) ? implode('; ', (array)$data['Messages']) : 'Failed to initiate signing session';
            return [
                'success' => false,
                'error'   => "emSigner Initiation Error (HTTP {$httpCode}): {$msg}"
            ];
        }

        $resp = $data['Response'] ?? [];
        $workflowId = (int)($resp['WorkflowId'] ?? 0);
        $signingUrl = $resp['URL'] ?? '';
        $docId      = (int)($resp['DocumentIdList'][0] ?? 0);

        if (empty($signingUrl)) {
            return [
                'success' => false,
                'error'   => 'emSigner did not return a valid signing URL'
            ];
        }

        return [
            'success'      => true,
            'workflow_id'  => $workflowId,
            'signing_url'  => $signingUrl,
            'reference_no' => $resp['ReferenceNo'] ?? $refNo,
            'document_id'  => $docId,
            'raw'          => $resp
        ];
    }

    /**
     * Query status of a workflow from emSigner
     */
    public static function getWorkflowInfo(int $workflowId, string $referenceNo = ''): array {
        $auth = self::authorizeApp();
        if (!$auth['success']) {
            return [
                'success' => false,
                'error'   => $auth['error']
            ];
        }
        $token = $auth['token'];

        $url = rtrim(ESIGN_API_BASE_URL, '/') . '/GetWorkflowInfo';
        $payload = [
            'WorkflowId'  => $workflowId,
            'ReferenceNo' => $referenceNo
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: basic ' . $token
            ],
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ]);

        $rawResponse = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($rawResponse, true);
        return [
            'success' => (bool)($data['IsSuccess'] ?? false),
            'data'    => $data['Response'] ?? null,
            'error'   => !empty($data['Messages']) ? implode('; ', (array)$data['Messages']) : null
        ];
    }

    /**
     * Send signing invitation email to participant with emSigner session URL
     */
    public static function sendSigningInvitationEmail(
        string $signerEmail,
        string $signerName,
        string $signingUrl,
        string $documentTitle,
        string $referenceNo
    ): array {
        if (empty($signerEmail)) {
            return ['success' => false, 'message' => 'Signer email address is empty'];
        }

        $subject = "Action Required: Digital Signature Request via emSigner [{$referenceNo}]";
        $timestamp = date('d M Y, h:i A');

        $body = "Dear {$signerName},\n\n"
              . "A digital signature request has been generated for you on the AgriStack Farmer Registry Portal.\n\n"
              . "════════════════════════════════════════════════════\n"
              . "           DIGITAL SIGNING REQUEST DETAILS\n"
              . "════════════════════════════════════════════════════\n"
              . "Document / Item : {$documentTitle}\n"
              . "Reference ID    : {$referenceNo}\n"
              . "Signer Name     : {$signerName}\n"
              . "Provider        : emSigner by eMudhra\n"
              . "Generated At    : {$timestamp}\n"
              . "════════════════════════════════════════════════════\n\n"
              . "To review and affix your legally recognized digital signature, please open the following secure emSigner session link:\n\n"
              . "{$signingUrl}\n\n"
              . "Instructions:\n"
              . "1. Open the secure link above in your web browser.\n"
              . "2. Authenticate and review the document content.\n"
              . "3. Affix your signature using Aadhaar eSign or Digital Signature Certificate.\n"
              . "4. Once completed, you will be redirected back to the AgriStack portal.\n\n"
              . "Regards,\n"
              . "AgriStack Digital Signature Services\n"
              . "Government of India / AgriStack Registry";

        return sendPortalEmail($signerEmail, $subject, $body, $signerName);
    }

    /**
     * Generate a valid 1-page PDF file in binary bytes for agreements
     */
    public static function generateAgreementPdf(string $title, array $lines): string {
        $content = "BT\n/F1 15 Tf\n50 740 Td\n(" . addcslashes($title, "()\\") . ") Tj\nET\n";
        $content .= "BT\n/F1 10 Tf\n50 710 Td\n";
        foreach ($lines as $line) {
            $content .= "0 -16 Td\n(" . addcslashes($line, "()\\") . ") Tj\n";
        }
        $content .= "ET\n";

        $streamLen = strlen($content);
        $pdf = "%PDF-1.4\n";
        $offsets = [];

        $offsets[1] = strlen($pdf);
        $pdf .= "1 0 obj\n<</Type/Catalog/Pages 2 0 R>>\nendobj\n";

        $offsets[2] = strlen($pdf);
        $pdf .= "2 0 obj\n<</Type/Pages/Kids[3 0 R]/Count 1>>\nendobj\n";

        $offsets[3] = strlen($pdf);
        $pdf .= "3 0 obj\n<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Resources<</Font<</F1 4 0 R>>>>/Contents 5 0 R>>\nendobj\n";

        $offsets[4] = strlen($pdf);
        $pdf .= "4 0 obj\n<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>\nendobj\n";

        $offsets[5] = strlen($pdf);
        $pdf .= "5 0 obj\n<</Length {$streamLen}>>\nstream\n{$content}\nendstream\nendobj\n";

        $xrefOffset = strlen($pdf);
        $pdf .= "xref\n0 6\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= 5; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<</Size 6/Root 1 0 R>>\nstartxref\n{$xrefOffset}\n%%EOF";
        return $pdf;
    }
}
