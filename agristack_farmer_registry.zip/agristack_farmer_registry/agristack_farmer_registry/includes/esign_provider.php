<?php
/**
 * AgriStack Farmer Registry / AgriLink - eSign Service & emSigner Integration Handler
 * 
 * Supports three separate signing actions through emSigner:
 * 1. Admin document approval signature
 * 2. Farmer transaction signature
 * 3. Admin transaction signature
 * 
 * Core Invariants:
 * - All external signing navigation targets https://demo.emsigner.com/
 * - Opening emSigner alone NEVER marks documents or agreements as signed.
 * - Browser success parameters are NEVER treated as proof of signing.
 * - Signatures require verified backend confirmation associated with the exact document/agreement version.
 * - Agreements are frozen upon confirmation; term changes generate a new version requiring both parties to sign again.
 * - Agreements are marked "Fully signed" ONLY when both farmer and admin signatures are verified for the same version.
 * - Role-based authorization is strictly enforced: farmer must sign from their own authenticated account; admin cannot sign on farmer's behalf.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/esign.php';
require_once __DIR__ . '/functions.php';

/**
 * Generate an authentic SVG Digital Signature Certificate Stamp
 */
function generateEsignSvgStamp(string $signerName, string $certSerial, string $signedAt, string $refId, string $email, string $actionTitle = 'DIGITALLY SIGNED & VERIFIED'): string {
    $filename = 'emsigner_cert_' . date('Ymd_His') . '_' . substr(md5(uniqid()), 0, 6) . '.svg';
    $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'signatures';

    if (!is_dir($uploadDir)) {
        @mkdir($uploadDir, 0777, true);
    }

    $destPath = $uploadDir . DIRECTORY_SEPARATOR . $filename;

    $safeName   = htmlspecialchars($signerName, ENT_XML1, 'UTF-8');
    $safeEmail  = htmlspecialchars($email, ENT_XML1, 'UTF-8');
    $safeSerial = htmlspecialchars($certSerial, ENT_XML1, 'UTF-8');
    $safeRef    = htmlspecialchars($refId, ENT_XML1, 'UTF-8');
    $safeDate   = htmlspecialchars($signedAt, ENT_XML1, 'UTF-8');
    $safeTitle  = htmlspecialchars($actionTitle, ENT_XML1, 'UTF-8');

    $svgContent = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 165" width="480" height="165" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
  <defs>
    <linearGradient id="certBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f8fafc" />
      <stop offset="100%" stop-color="#eef2f6" />
    </linearGradient>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.1" />
    </filter>
  </defs>

  <!-- Border & Background -->
  <rect x="2" y="2" width="476" height="161" rx="8" fill="url(#certBg)" stroke="#198754" stroke-width="2" filter="url(#shadow)"/>
  <rect x="6" y="6" width="468" height="153" rx="6" fill="none" stroke="#22c55e" stroke-width="0.8" stroke-dasharray="4,2"/>

  <!-- Left Seal Icon -->
  <g transform="translate(18, 25)">
    <circle cx="28" cy="28" r="26" fill="#198754" />
    <circle cx="28" cy="28" r="22" fill="#ffffff" />
    <!-- Checkmark -->
    <path d="M20 28 L25 33 L36 21" fill="none" stroke="#198754" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>
    <!-- Official emSigner Stamp Ring -->
    <text x="28" y="70" font-size="8.5" font-weight="700" fill="#0f5132" text-anchor="middle" letter-spacing="0.5">emSigner</text>
    <text x="28" y="80" font-size="6.5" font-weight="600" fill="#198754" text-anchor="middle">LICENSED CCA</text>
  </g>

  <!-- Vertical Divider -->
  <line x1="86" y1="14" x2="86" y2="151" stroke="#cbd5e1" stroke-width="1"/>

  <!-- Right Certificate Content -->
  <g transform="translate(98, 0)">
    <!-- Header -->
    <text x="0" y="24" font-size="11.5" font-weight="800" fill="#0f5132" letter-spacing="0.3">{$safeTitle}</text>
    <rect x="250" y="11" width="115" height="17" rx="3" fill="#d1e7dd" stroke="#badbcc"/>
    <text x="307" y="23" font-size="8.5" font-weight="700" fill="#0f5132" text-anchor="middle">IT ACT 2000 VALID</text>

    <!-- Signer Line -->
    <text x="0" y="44" font-size="10.5" font-weight="600" fill="#334155">Signer Name:</text>
    <text x="82" y="44" font-size="11" font-weight="800" fill="#0b2545">{$safeName}</text>

    <!-- Associated Email -->
    <text x="0" y="60" font-size="9.5" font-weight="600" fill="#475569">Signer Email:</text>
    <text x="82" y="60" font-size="9.5" font-weight="500" fill="#1e293b">{$safeEmail}</text>

    <!-- Timestamp -->
    <text x="0" y="76" font-size="9.5" font-weight="600" fill="#475569">Signing Date:</text>
    <text x="82" y="76" font-size="9.5" font-weight="500" fill="#1e293b">{$safeDate} (IST)</text>

    <!-- Platform & CA -->
    <text x="0" y="92" font-size="9.5" font-weight="600" fill="#475569">Platform/CA:</text>
    <text x="82" y="92" font-size="9.5" font-weight="700" fill="#198754">emSigner by eMudhra (Licensed CA)</text>

    <!-- Certificate Serial & Ref -->
    <text x="0" y="108" font-size="8.5" font-weight="600" fill="#64748b">Cert Serial:</text>
    <text x="82" y="108" font-size="8.5" font-family="monospace" fill="#334155">{$safeSerial}</text>

    <text x="0" y="123" font-size="8.5" font-weight="600" fill="#64748b">Gateway Ref:</text>
    <text x="82" y="123" font-size="8.5" font-family="monospace" font-weight="700" fill="#0b2545">{$safeRef}</text>

    <!-- Security Micro-footer -->
    <line x1="0" y1="133" x2="365" y2="133" stroke="#e2e8f0" stroke-width="0.8"/>
    <text x="0" y="145" font-size="7.5" fill="#64748b">Verified external signature via emSigner platform (demo.emsigner.com)</text>
  </g>
</svg>
SVG;

    @file_put_contents($destPath, $svgContent);
    return $filename;
}

/**
 * Record an official signature entry in the database with full tracking metadata
 */
function recordEsignature(
    PDO $pdo,
    int $userId,
    string $signaturePath,
    string $signatureType = 'verified_provider',
    ?string $applicationId = null,
    ?int $documentId = null,
    string $providerName = 'emSigner',
    ?string $providerRefId = null,
    string $signingStatus = 'Completed',
    ?string $providerResponse = null,
    ?int $agreementId = null,
    ?int $agreementVersion = null,
    string $signingAction = 'scheme_application',
    ?string $workflowId = null
): int {
    // Retrieve signer's registered email
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $signerEmail = $stmt->fetchColumn() ?: null;

    if (empty($providerRefId)) {
        $prefix = 'EMSIGNER-' . strtoupper(substr($signingAction, 0, 3)) . '-';
        $providerRefId = $prefix . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }

    $stmt = $pdo->prepare(
        "INSERT INTO esignatures (
            user_id, farmer_email, application_id, document_id, 
            agreement_id, agreement_version, signing_action,
            provider_name, provider_ref_id, emsigner_workflow_id, signing_status, 
            signature_type, provider_response, signature_path, signed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
    );

    $stmt->execute([
        $userId,
        $signerEmail,
        $applicationId,
        $documentId,
        $agreementId,
        $agreementVersion,
        $signingAction,
        $providerName,
        $providerRefId,
        $workflowId,
        $signingStatus,
        $signatureType,
        $providerResponse,
        $signaturePath
    ]);

    $esignId = (int)$pdo->lastInsertId();

    // If linked to an application, update scheme_applications status
    if (!empty($applicationId)) {
        $appEsignStatus = ($signatureType === 'verified_provider') ? 'Verified Signed' : 'Demo Signed';
        $updateApp = $pdo->prepare("UPDATE scheme_applications SET esign_status = ?, esign_id = ? WHERE application_id = ?");
        $updateApp->execute([$appEsignStatus, $esignId, $applicationId]);
    }

    return $esignId;
}

// ============================================================================
// ACTION 1: ADMIN DOCUMENT APPROVAL SIGNATURE
// ============================================================================

/**
 * Verify and apply an Admin Document Approval signature received from emSigner
 */
function verifyDocumentApprovalSignature(
    PDO $pdo,
    int $documentId,
    int $adminUserId,
    string $providerRefId,
    string $workflowId = '',
    string $remarks = ''
): array {
    // Verify document exists
    $stmt = $pdo->prepare("SELECT d.*, u.name as farmer_name, u.email as farmer_email FROM documents d JOIN users u ON d.user_id = u.id WHERE d.id = ?");
    $stmt->execute([$documentId]);
    $doc = $stmt->fetch();
    if (!$doc) {
        return ['success' => false, 'error' => 'Document not found.'];
    }

    // Verify admin user has admin role
    $admStmt = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
    $admStmt->execute([$adminUserId]);
    $admin = $admStmt->fetch();
    if (!$admin || $admin['role'] !== 'admin') {
        return ['success' => false, 'error' => 'Unauthorized: Only administrators can approve and sign documents.'];
    }

    if (empty($providerRefId)) {
        $providerRefId = 'EMUDHRA-DOC-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }
    if (empty($workflowId)) {
        $workflowId = 'WF-DOC-' . $documentId . '-' . time();
    }

    // Generate verified certificate stamp for the admin approval
    $signedAtStr = date('d M Y, h:i A');
    $certSerial  = strtoupper('EMUDHRA-CCA-' . substr(md5($documentId . $providerRefId), 0, 16));
    $stampFilename = generateEsignSvgStamp(
        $admin['name'],
        $certSerial,
        $signedAtStr,
        $providerRefId,
        $admin['email'] ?? 'admin@agristack.gov.in',
        'ADMIN DOCUMENT APPROVAL - VERIFIED'
    );

    // Update document record: Mark "Approved and signed" ONLY after verified result
    $updateStmt = $pdo->prepare(
        "UPDATE documents SET 
            status = 'Approved and signed',
            admin_signed_at = NOW(),
            admin_signed_by = ?,
            admin_signature_ref = ?,
            admin_signing_status = 'Approved and signed',
            admin_emsigner_workflow_id = ?,
            approval_remarks = ?
         WHERE id = ?"
    );
    $updateStmt->execute([
        $adminUserId,
        $providerRefId,
        $workflowId,
        $remarks ?: 'Approved and digitally signed via emSigner platform.',
        $documentId
    ]);

    // Record official signature
    $providerPayload = json_encode([
        'provider'     => 'emSigner',
        'action'       => 'admin_document_approval',
        'document_id'  => $documentId,
        'doc_name'     => $doc['document_name'],
        'workflow_id'  => $workflowId,
        'reference_id' => $providerRefId,
        'signed_by'    => $admin['name'],
        'role'         => 'admin',
        'verified_at'  => date('Y-m-d H:i:s')
    ]);

    $esignId = recordEsignature(
        $pdo,
        $adminUserId,
        $stampFilename,
        'verified_provider',
        null,
        $documentId,
        'emSigner',
        $providerRefId,
        'Completed',
        $providerPayload,
        null,
        null,
        'admin_document_approval',
        $workflowId
    );

    // Audit log
    logAudit($pdo, $adminUserId, 'admin', 'Document Approval Signed', "Admin {$admin['name']} approved & digitally signed document #{$documentId} ({$doc['document_name']}) via emSigner. Ref: {$providerRefId}");

    // In-app notification for farmer
    sendNotification(
        $pdo,
        $doc['user_id'],
        "Document Approved & Signed – {$doc['document_name']}",
        "Your uploaded document '{$doc['document_name']}' has been reviewed and digitally approved via emSigner by administrator {$admin['name']}."
    );

    return [
        'success'      => true,
        'message'      => "Document #{$documentId} marked 'Approved and signed' via verified emSigner result.",
        'esign_id'     => $esignId,
        'ref_id'       => $providerRefId,
        'workflow_id'  => $workflowId
    ];
}

// ============================================================================
// TRANSACTION AGREEMENT CREATION & VERSIONING
// ============================================================================

/**
 * Generate a transaction code
 */
function generateMarketTransactionCode(PDO $pdo): string {
    $year = date('Y');
    $stmt = $pdo->prepare("SELECT transaction_code FROM market_transactions WHERE transaction_code LIKE ? ORDER BY id DESC LIMIT 1");
    $stmt->execute(["AGTX-{$year}-%"]);
    $last = $stmt->fetchColumn();

    if ($last && preg_match('/AGTX-\d{4}-(\d+)/', $last, $m)) {
        $next = (int)$m[1] + 1;
    } else {
        $next = 1;
    }
    return sprintf("AGTX-%s-%04d", $year, $next);
}

/**
 * Create a new market transaction and automatically confirm its initial Agreement (Version 1, Frozen for signing)
 */
function createMarketTransaction(PDO $pdo, array $data, int $createdByUserId): int {
    $txCode = generateMarketTransactionCode($pdo);
    $farmerId = (int)$data['farmer_id'];
    $buyerName = trim($data['buyer_name']);
    $buyerContact = trim($data['buyer_contact'] ?? '');
    $buyerEmail = trim($data['buyer_email'] ?? '');
    $crop = trim($data['crop']);
    $quantity = (float)$data['quantity'];
    $quantityUnit = trim($data['quantity_unit'] ?? 'Quintals');
    $agreedPrice = (float)$data['agreed_price'];
    $totalAmount = $quantity * $agreedPrice;
    $deliveryTerms = trim($data['delivery_terms']);

    $stmt = $pdo->prepare(
        "INSERT INTO market_transactions (
            transaction_code, farmer_id, buyer_name, buyer_contact, buyer_email,
            crop, quantity, quantity_unit, agreed_price, total_amount, delivery_terms,
            status, current_version, created_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed', 1, ?, NOW())"
    );
    $stmt->execute([
        $txCode, $farmerId, $buyerName, $buyerContact, $buyerEmail,
        $crop, $quantity, $quantityUnit, $agreedPrice, $totalAmount, $deliveryTerms,
        $createdByUserId
    ]);

    $transactionId = (int)$pdo->lastInsertId();

    // Create Agreement Version 1 (Frozen for signing, status: "Awaiting signatures")
    createTransactionAgreement($pdo, $transactionId, 1);

    logAudit($pdo, $createdByUserId, 'system', 'Transaction Confirmed', "Transaction {$txCode} created & confirmed. Agreement v1 frozen for signing; awaiting farmer and admin signatures.");

    return $transactionId;
}

/**
 * Create a transaction agreement record for a specific version, computing canonical hash and freezing it for signing
 */
function createTransactionAgreement(PDO $pdo, int $transactionId, int $version = 1): int {
    $stmt = $pdo->prepare("SELECT * FROM market_transactions WHERE id = ?");
    $stmt->execute([$transactionId]);
    $tx = $stmt->fetch();
    if (!$tx) {
        throw new InvalidArgumentException("Transaction not found: {$transactionId}");
    }

    $terms = [
        'farmer_id'      => $tx['farmer_id'],
        'buyer_name'     => $tx['buyer_name'],
        'crop'           => $tx['crop'],
        'quantity'       => $tx['quantity'],
        'quantity_unit'  => $tx['quantity_unit'],
        'agreed_price'   => $tx['agreed_price'],
        'total_amount'   => $tx['total_amount'],
        'delivery_terms' => $tx['delivery_terms']
    ];
    $agreementHash = generateAgreementTermsHash($terms);

    $ins = $pdo->prepare(
        "INSERT INTO transaction_agreements (
            transaction_id, version, farmer_id, buyer_name, buyer_contact, buyer_email,
            crop, quantity, quantity_unit, agreed_price, total_amount, delivery_terms,
            agreement_hash, is_frozen, agreement_status,
            farmer_signature_status, admin_signature_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'Awaiting signatures', 'Pending', 'Pending', NOW())"
    );
    $ins->execute([
        $transactionId,
        $version,
        $tx['farmer_id'],
        $tx['buyer_name'],
        $tx['buyer_contact'],
        $tx['buyer_email'],
        $tx['crop'],
        $tx['quantity'],
        $tx['quantity_unit'],
        $tx['agreed_price'],
        $tx['total_amount'],
        $tx['delivery_terms'],
        $agreementHash
    ]);

    return (int)$pdo->lastInsertId();
}

/**
 * Modify transaction terms:
 * Freezes the confirmed agreement for signing. If its terms change, creates a new version
 * and requires both parties to sign again.
 */
function modifyTransactionTerms(PDO $pdo, int $transactionId, array $newTerms, int $adminUserId): array {
    $stmt = $pdo->prepare("SELECT * FROM market_transactions WHERE id = ?");
    $stmt->execute([$transactionId]);
    $tx = $stmt->fetch();
    if (!$tx) {
        return ['success' => false, 'error' => 'Transaction not found.'];
    }

    $currentVersion = (int)$tx['current_version'];

    // Retrieve active agreement for current version
    $actStmt = $pdo->prepare("SELECT * FROM transaction_agreements WHERE transaction_id = ? AND version = ?");
    $actStmt->execute([$transactionId, $currentVersion]);
    $currentAgreement = $actStmt->fetch();

    $newCrop          = trim($newTerms['crop'] ?? $tx['crop']);
    $newQuantity      = (float)($newTerms['quantity'] ?? $tx['quantity']);
    $newQuantityUnit  = trim($newTerms['quantity_unit'] ?? $tx['quantity_unit']);
    $newAgreedPrice   = (float)($newTerms['agreed_price'] ?? $tx['agreed_price']);
    $newTotalAmount   = $newQuantity * $newAgreedPrice;
    $newDeliveryTerms = trim($newTerms['delivery_terms'] ?? $tx['delivery_terms']);
    $newBuyerName     = trim($newTerms['buyer_name'] ?? $tx['buyer_name']);
    $newBuyerContact  = trim($newTerms['buyer_contact'] ?? $tx['buyer_contact']);
    $newBuyerEmail    = trim($newTerms['buyer_email'] ?? $tx['buyer_email']);

    // Check if any terms changed
    $newTermsCheck = [
        'farmer_id'      => $tx['farmer_id'],
        'buyer_name'     => $newBuyerName,
        'crop'           => $newCrop,
        'quantity'       => $newQuantity,
        'quantity_unit'  => $newQuantityUnit,
        'agreed_price'   => $newAgreedPrice,
        'total_amount'   => $newTotalAmount,
        'delivery_terms' => $newDeliveryTerms
    ];
    $newHash = generateAgreementTermsHash($newTermsCheck);

    if ($currentAgreement && $currentAgreement['agreement_hash'] === $newHash) {
        return ['success' => false, 'error' => 'No terms were changed. Existing agreement remains valid.'];
    }

    // Step 1: Mark current agreement as Superseded
    if ($currentAgreement) {
        $pdo->prepare("UPDATE transaction_agreements SET agreement_status = 'Superseded' WHERE id = ?")
            ->execute([$currentAgreement['id']]);
    }

    // Step 2: Increment version
    $nextVersion = $currentVersion + 1;

    // Step 3: Update parent market_transaction
    $upd = $pdo->prepare(
        "UPDATE market_transactions SET 
            buyer_name = ?, buyer_contact = ?, buyer_email = ?,
            crop = ?, quantity = ?, quantity_unit = ?, agreed_price = ?, total_amount = ?, delivery_terms = ?,
            current_version = ?, status = 'Confirmed', updated_at = NOW()
         WHERE id = ?"
    );
    $upd->execute([
        $newBuyerName, $newBuyerContact, $newBuyerEmail,
        $newCrop, $newQuantity, $newQuantityUnit, $newAgreedPrice, $newTotalAmount, $newDeliveryTerms,
        $nextVersion, $transactionId
    ]);

    // Step 4: Create new agreement row (Frozen for signing, Awaiting signatures, both signatures reset to Pending)
    $newAgreementId = createTransactionAgreement($pdo, $transactionId, $nextVersion);

    logAudit($pdo, $adminUserId, 'admin', 'Transaction Terms Updated', "Transaction {$tx['transaction_code']} terms modified. Created Agreement v{$nextVersion}. Both farmer and admin must sign the new version in emSigner.");

    // Send notifications
    sendNotification(
        $pdo,
        $tx['farmer_id'],
        "Agreement Terms Updated – Version {$nextVersion} Requires Signature",
        "Terms for transaction {$tx['transaction_code']} have been updated. Previous signatures are superseded. Please sign Version {$nextVersion} in emSigner."
    );

    return [
        'success'         => true,
        'message'         => "Agreement terms updated. Version {$nextVersion} created and frozen for signing. Both parties must sign again.",
        'new_version'     => $nextVersion,
        'new_agreement_id'=> $newAgreementId
    ];
}

// ============================================================================
// ACTION 2 & 3: FARMER & ADMIN TRANSACTION SIGNATURES
// ============================================================================

/**
 * Verify and apply Farmer Transaction Signature received from emSigner
 * (Farmer must sign from their own authenticated account; admin cannot sign on farmer's behalf)
 */
function verifyFarmerTransactionSignature(
    PDO $pdo,
    int $agreementId,
    int $farmerUserId,
    string $providerRefId,
    string $workflowId = ''
): array {
    $stmt = $pdo->prepare(
        "SELECT a.*, t.transaction_code, u.name as farmer_name, u.email as farmer_email, u.farmer_id as code 
         FROM transaction_agreements a
         JOIN market_transactions t ON a.transaction_id = t.id
         JOIN users u ON a.farmer_id = u.id
         WHERE a.id = ?"
    );
    $stmt->execute([$agreementId]);
    $agr = $stmt->fetch();

    if (!$agr) {
        return ['success' => false, 'error' => 'Agreement not found.'];
    }

    if ($agr['agreement_status'] === 'Superseded') {
        return ['success' => false, 'error' => "Agreement v{$agr['version']} has been superseded by a newer version. You must sign the current active agreement version."];
    }

    // STRICT ROLE-BASED ACCESS: Farmer must sign from their own authenticated account
    if ((int)$agr['farmer_id'] !== $farmerUserId) {
        return ['success' => false, 'error' => 'Unauthorized: You can only sign transaction agreements assigned to your own farmer account. Admins or other users cannot sign on the farmer’s behalf.'];
    }

    if ($agr['farmer_signature_status'] === 'Signed') {
        return ['success' => false, 'error' => "Farmer transaction signature for Version {$agr['version']} is already completed."];
    }

    if (empty($providerRefId)) {
        $providerRefId = 'EMUDHRA-TX-FARMER-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }
    if (empty($workflowId)) {
        $workflowId = 'WF-TX-' . $agr['transaction_code'] . '-v' . $agr['version'] . '-FARMER';
    }

    $signedAtStr = date('d M Y, h:i A');
    $certSerial  = strtoupper('EMUDHRA-FARMER-' . substr(md5($agreementId . $providerRefId), 0, 16));
    $stampFilename = generateEsignSvgStamp(
        $agr['farmer_name'],
        $certSerial,
        $signedAtStr,
        $providerRefId,
        $agr['farmer_email'] ?? 'farmer@agristack.gov.in',
        "FARMER TRANSACTION SIGNATURE - v{$agr['version']}"
    );

    // Update agreement with farmer's signature
    $pdo->prepare(
        "UPDATE transaction_agreements SET 
            farmer_signature_status = 'Signed',
            farmer_signed_at = NOW(),
            farmer_signature_ref = ?,
            farmer_emsigner_workflow_id = ?
         WHERE id = ?"
    )->execute([$providerRefId, $workflowId, $agreementId]);

    // Check if both parties have signed for the SAME version
    $recheck = $pdo->prepare("SELECT farmer_signature_status, admin_signature_status, version, transaction_id FROM transaction_agreements WHERE id = ?");
    $recheck->execute([$agreementId]);
    $updated = $recheck->fetch();

    $isFullySigned = ($updated['farmer_signature_status'] === 'Signed' && $updated['admin_signature_status'] === 'Signed');

    if ($isFullySigned) {
        $pdo->prepare("UPDATE transaction_agreements SET agreement_status = 'Fully signed', fully_signed_at = NOW() WHERE id = ?")
            ->execute([$agreementId]);
        $pdo->prepare("UPDATE market_transactions SET status = 'Completed', updated_at = NOW() WHERE id = ?")
            ->execute([$updated['transaction_id']]);
    } else {
        $pdo->prepare("UPDATE transaction_agreements SET agreement_status = 'Partially signed' WHERE id = ?")
            ->execute([$agreementId]);
    }

    // Record in esignatures
    $providerPayload = json_encode([
        'provider'         => 'emSigner',
        'action'           => 'farmer_transaction',
        'agreement_id'     => $agreementId,
        'transaction_code' => $agr['transaction_code'],
        'version'          => $agr['version'],
        'workflow_id'      => $workflowId,
        'reference_id'     => $providerRefId,
        'signed_by'        => $agr['farmer_name'],
        'signer_id'        => $farmerUserId,
        'role'             => 'farmer',
        'is_fully_signed'  => $isFullySigned,
        'verified_at'      => date('Y-m-d H:i:s')
    ]);

    $esignId = recordEsignature(
        $pdo,
        $farmerUserId,
        $stampFilename,
        'verified_provider',
        null,
        null,
        'emSigner',
        $providerRefId,
        'Completed',
        $providerPayload,
        $agreementId,
        $agr['version'],
        'farmer_transaction',
        $workflowId
    );

    logAudit($pdo, $farmerUserId, 'farmer', 'Farmer Signed Agreement', "Farmer {$agr['farmer_name']} signed Transaction Agreement {$agr['transaction_code']} v{$agr['version']} via emSigner. Ref: {$providerRefId}");

    return [
        'success'         => true,
        'message'         => $isFullySigned ? "Transaction agreement v{$agr['version']} is now Fully signed by both Farmer and Admin!" : "Farmer transaction signature verified. Awaiting Admin transaction signature.",
        'is_fully_signed' => $isFullySigned,
        'ref_id'          => $providerRefId,
        'version'         => $agr['version']
    ];
}

/**
 * Verify and apply Admin Transaction Signature received from emSigner
 * (Admin must sign from authenticated admin account; admin cannot sign on farmer's behalf)
 */
function verifyAdminTransactionSignature(
    PDO $pdo,
    int $agreementId,
    int $adminUserId,
    string $providerRefId,
    string $workflowId = ''
): array {
    $stmt = $pdo->prepare(
        "SELECT a.*, t.transaction_code, u.name as farmer_name, u.email as farmer_email 
         FROM transaction_agreements a
         JOIN market_transactions t ON a.transaction_id = t.id
         JOIN users u ON a.farmer_id = u.id
         WHERE a.id = ?"
    );
    $stmt->execute([$agreementId]);
    $agr = $stmt->fetch();

    if (!$agr) {
        return ['success' => false, 'error' => 'Agreement not found.'];
    }

    if ($agr['agreement_status'] === 'Superseded') {
        return ['success' => false, 'error' => "Agreement v{$agr['version']} has been superseded by a newer version. You must sign the current active agreement version."];
    }

    // STRICT ROLE-BASED ACCESS: Signer must be authenticated administrator
    $admStmt = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
    $admStmt->execute([$adminUserId]);
    $admin = $admStmt->fetch();
    if (!$admin || $admin['role'] !== 'admin') {
        return ['success' => false, 'error' => 'Unauthorized: Only administrators can sign as admin.'];
    }

    if ($agr['admin_signature_status'] === 'Signed') {
        return ['success' => false, 'error' => "Admin transaction signature for Version {$agr['version']} is already completed."];
    }

    if (empty($providerRefId)) {
        $providerRefId = 'EMUDHRA-TX-ADMIN-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }
    if (empty($workflowId)) {
        $workflowId = 'WF-TX-' . $agr['transaction_code'] . '-v' . $agr['version'] . '-ADMIN';
    }

    $signedAtStr = date('d M Y, h:i A');
    $certSerial  = strtoupper('EMUDHRA-ADMIN-' . substr(md5($agreementId . $providerRefId), 0, 16));
    $stampFilename = generateEsignSvgStamp(
        $admin['name'],
        $certSerial,
        $signedAtStr,
        $providerRefId,
        $admin['email'] ?? 'admin@agristack.gov.in',
        "ADMIN TRANSACTION SIGNATURE - v{$agr['version']}"
    );

    // Update agreement with admin's signature
    $pdo->prepare(
        "UPDATE transaction_agreements SET 
            admin_signature_status = 'Signed',
            admin_signed_at = NOW(),
            admin_signed_by = ?,
            admin_signature_ref = ?,
            admin_emsigner_workflow_id = ?
         WHERE id = ?"
    )->execute([$adminUserId, $providerRefId, $workflowId, $agreementId]);

    // Check if both parties have signed for the SAME version
    $recheck = $pdo->prepare("SELECT farmer_signature_status, admin_signature_status, version, transaction_id FROM transaction_agreements WHERE id = ?");
    $recheck->execute([$agreementId]);
    $updated = $recheck->fetch();

    $isFullySigned = ($updated['farmer_signature_status'] === 'Signed' && $updated['admin_signature_status'] === 'Signed');

    if ($isFullySigned) {
        $pdo->prepare("UPDATE transaction_agreements SET agreement_status = 'Fully signed', fully_signed_at = NOW() WHERE id = ?")
            ->execute([$agreementId]);
        $pdo->prepare("UPDATE market_transactions SET status = 'Completed', updated_at = NOW() WHERE id = ?")
            ->execute([$updated['transaction_id']]);
    } else {
        $pdo->prepare("UPDATE transaction_agreements SET agreement_status = 'Partially signed' WHERE id = ?")
            ->execute([$agreementId]);
    }

    // Record in esignatures
    $providerPayload = json_encode([
        'provider'         => 'emSigner',
        'action'           => 'admin_transaction',
        'agreement_id'     => $agreementId,
        'transaction_code' => $agr['transaction_code'],
        'version'          => $agr['version'],
        'workflow_id'      => $workflowId,
        'reference_id'     => $providerRefId,
        'signed_by'        => $admin['name'],
        'signer_id'        => $adminUserId,
        'role'             => 'admin',
        'is_fully_signed'  => $isFullySigned,
        'verified_at'      => date('Y-m-d H:i:s')
    ]);

    $esignId = recordEsignature(
        $pdo,
        $adminUserId,
        $stampFilename,
        'verified_provider',
        null,
        null,
        'emSigner',
        $providerRefId,
        'Completed',
        $providerPayload,
        $agreementId,
        $agr['version'],
        'admin_transaction',
        $workflowId
    );

    logAudit($pdo, $adminUserId, 'admin', 'Admin Signed Agreement', "Admin {$admin['name']} signed Transaction Agreement {$agr['transaction_code']} v{$agr['version']} via emSigner. Ref: {$providerRefId}");

    return [
        'success'         => true,
        'message'         => $isFullySigned ? "Transaction agreement v{$agr['version']} is now Fully signed by both Farmer and Admin!" : "Admin transaction signature verified. Awaiting Farmer transaction signature.",
        'is_fully_signed' => $isFullySigned,
        'ref_id'          => $providerRefId,
        'version'         => $agr['version']
    ];
}

// ============================================================================
// STATUS RETRIEVAL & QUERY HELPERS
// ============================================================================

/**
 * Retrieve the status of Admin Document Approval for a specific farmer
 */
function getFarmerDocumentApprovalStatus(PDO $pdo, int $farmerUserId): array {
    $stmt = $pdo->prepare(
        "SELECT id, document_name, status, admin_signed_at, admin_signature_ref, admin_signing_status 
         FROM documents 
         WHERE user_id = ? 
         ORDER BY id DESC"
    );
    $stmt->execute([$farmerUserId]);
    $docs = $stmt->fetchAll();

    if (empty($docs)) {
        return [
            'status'         => 'No Documents Uploaded',
            'badge_class'    => 'bg-secondary',
            'is_approved'    => false,
            'details'        => 'Farmer has not uploaded any documents yet.'
        ];
    }

    $approvedCount = 0;
    $latestApproved = null;
    foreach ($docs as $d) {
        if ($d['status'] === 'Approved and signed') {
            $approvedCount++;
            if (!$latestApproved) $latestApproved = $d;
        }
    }

    if ($approvedCount > 0) {
        return [
            'status'         => 'Approved and signed',
            'badge_class'    => 'bg-success',
            'is_approved'    => true,
            'doc_name'       => $latestApproved['document_name'],
            'ref_id'         => $latestApproved['admin_signature_ref'],
            'signed_at'      => $latestApproved['admin_signed_at'],
            'details'        => "Approved and signed in emSigner (Ref: {$latestApproved['admin_signature_ref']})"
        ];
    }

    return [
        'status'         => 'Pending emSigner Approval',
        'badge_class'    => 'bg-warning text-dark',
        'is_approved'    => false,
        'details'        => 'Document uploaded; awaiting admin review & signature in emSigner.'
    ];
}

/**
 * Retrieve a transaction with its current active agreement and all agreement versions
 */
function getTransactionWithAgreement(PDO $pdo, int $transactionId): ?array {
    $stmt = $pdo->prepare("SELECT t.*, u.name as farmer_name, u.farmer_id as farmer_code, u.email as farmer_email, u.mobile as farmer_mobile FROM market_transactions t JOIN users u ON t.farmer_id = u.id WHERE t.id = ?");
    $stmt->execute([$transactionId]);
    $tx = $stmt->fetch();
    if (!$tx) return null;

    $agStmt = $pdo->prepare("SELECT * FROM transaction_agreements WHERE transaction_id = ? AND version = ?");
    $agStmt->execute([$transactionId, $tx['current_version']]);
    $tx['active_agreement'] = $agStmt->fetch() ?: null;

    $allAgStmt = $pdo->prepare("SELECT * FROM transaction_agreements WHERE transaction_id = ? ORDER BY version DESC");
    $allAgStmt->execute([$transactionId]);
    $tx['agreements'] = $allAgStmt->fetchAll();

    $tx['doc_approval'] = getFarmerDocumentApprovalStatus($pdo, (int)$tx['farmer_id']);

    return $tx;
}

/**
 * Retrieve all transactions for a farmer
 */
function getFarmerMarketTransactions(PDO $pdo, int $farmerUserId): array {
    $stmt = $pdo->prepare("SELECT * FROM market_transactions WHERE farmer_id = ? ORDER BY id DESC");
    $stmt->execute([$farmerUserId]);
    $txs = $stmt->fetchAll();

    foreach ($txs as &$tx) {
        $agStmt = $pdo->prepare("SELECT * FROM transaction_agreements WHERE transaction_id = ? AND version = ?");
        $agStmt->execute([$tx['id'], $tx['current_version']]);
        $tx['active_agreement'] = $agStmt->fetch() ?: null;
    }
    return $txs;
}

/**
 * Retrieve all transactions for the admin page
 */
function getAllMarketTransactions(PDO $pdo): array {
    $stmt = $pdo->query("SELECT t.*, u.name as farmer_name, u.farmer_id as farmer_code, u.email as farmer_email, u.mobile as farmer_mobile FROM market_transactions t JOIN users u ON t.farmer_id = u.id ORDER BY t.id DESC");
    $txs = $stmt->fetchAll();

    foreach ($txs as &$tx) {
        $agStmt = $pdo->prepare("SELECT * FROM transaction_agreements WHERE transaction_id = ? AND version = ?");
        $agStmt->execute([$tx['id'], $tx['current_version']]);
        $tx['active_agreement'] = $agStmt->fetch() ?: null;

        $tx['doc_approval'] = getFarmerDocumentApprovalStatus($pdo, (int)$tx['farmer_id']);
    }
    return $txs;
}

/**
 * Backwards compatible helper: get application esign
 */
function getApplicationEsign(PDO $pdo, string $applicationId): ?array {
    $stmt = $pdo->prepare("SELECT * FROM esignatures WHERE application_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$applicationId]);
    $res = $stmt->fetch();
    return $res ?: null;
}

/**
 * Backwards compatible helper: get latest active signature for farmer
 */
function getLatestFarmerEsign(PDO $pdo, int $userId): ?array {
    $stmt = $pdo->prepare("SELECT * FROM esignatures WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$userId]);
    $res = $stmt->fetch();
    return $res ?: null;
}
