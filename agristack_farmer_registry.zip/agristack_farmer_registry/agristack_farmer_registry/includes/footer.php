    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="/agristack_farmer_registry/assets/js/main.js"></script>
    <script src="/agristack_farmer_registry/assets/js/emsigner_portal.js"></script>
</body>
</html>
