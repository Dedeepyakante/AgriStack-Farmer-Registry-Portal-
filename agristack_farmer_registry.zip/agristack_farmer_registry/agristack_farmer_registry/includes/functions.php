<?php
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function generateFarmerId($pdo) {
    $year = date('Y');
    $prefix = "AGRIF" . $year;
    $stmt = $pdo->prepare("SELECT farmer_id FROM users WHERE farmer_id LIKE ?");
    $stmt->execute([$prefix . '%']);
    $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $maxNum = 0;
    foreach ($existing as $id) {
        if ($id && strpos($id, $prefix) === 0) {
            $num = intval(substr($id, strlen($prefix)));
            if ($num > $maxNum) {
                $maxNum = $num;
            }
        }
    }
    
    $nextNum = $maxNum + 1;
    do {
        $candidateId = $prefix . str_pad((string)$nextNum, 4, '0', STR_PAD_LEFT);
        $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE farmer_id = ?");
        $chk->execute([$candidateId]);
        $exists = ($chk->fetchColumn() > 0);
        if ($exists) {
            $nextNum++;
        }
    } while ($exists);

    return $candidateId;
}

function generateApplicationId($pdo) {
    $year = date('Y');
    $prefix = "APP" . $year;
    $stmt = $pdo->prepare("SELECT application_id FROM scheme_applications WHERE application_id LIKE ?");
    $stmt->execute([$prefix . '%']);
    $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $maxNum = 0;
    foreach ($existing as $id) {
        if ($id && strpos($id, $prefix) === 0) {
            $num = intval(substr($id, strlen($prefix)));
            if ($num > $maxNum) {
                $maxNum = $num;
            }
        }
    }
    
    $nextNum = $maxNum + 1;
    do {
        $candidateId = $prefix . str_pad((string)$nextNum, 5, '0', STR_PAD_LEFT);
        $chk = $pdo->prepare("SELECT COUNT(*) FROM scheme_applications WHERE application_id = ?");
        $chk->execute([$candidateId]);
        $exists = ($chk->fetchColumn() > 0);
        if ($exists) {
            $nextNum++;
        }
    } while ($exists);

    return $candidateId;
}

function generateTransactionId($pdo) {
    $year = date('Y');
    $prefix = "DBT" . $year;
    $stmt = $pdo->prepare("SELECT transaction_id FROM dbt_transactions WHERE transaction_id LIKE ?");
    $stmt->execute([$prefix . '%']);
    $existing = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $maxNum = 0;
    foreach ($existing as $id) {
        if ($id && strpos($id, $prefix) === 0) {
            $num = intval(substr($id, strlen($prefix)));
            if ($num > $maxNum) {
                $maxNum = $num;
            }
        }
    }
    
    $nextNum = $maxNum + 1;
    do {
        $candidateId = $prefix . str_pad((string)$nextNum, 5, '0', STR_PAD_LEFT);
        $chk = $pdo->prepare("SELECT COUNT(*) FROM dbt_transactions WHERE transaction_id = ?");
        $chk->execute([$candidateId]);
        $exists = ($chk->fetchColumn() > 0);
        if ($exists) {
            $nextNum++;
        }
    } while ($exists);

    return $candidateId;
}

function logAudit($pdo, $user_id, $role, $action, $description) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, role, action, description, ip_address) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $role, $action, $description, $ip]);
}

function sendNotification($pdo, $user_id, $title, $message) {
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $title, $message]);
}

function getUnreadNotificationsCount($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn();
}
