<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgriStack Farmer Registry Portal</title>
<?php require_once __DIR__ . '/../config/csrf.php'; ?>
    <meta name="csrf-token" content="<?= htmlspecialchars(getCsrfToken()) ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="/agristack_farmer_registry/assets/css/style.css">
</head>
<body>
<div class="disclaimer-banner">
    Academic Prototype &mdash; Not an official UIDAI, AgriStack or Government of India application.
</div>
