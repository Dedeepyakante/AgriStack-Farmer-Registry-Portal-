<?php require_once __DIR__ . '/../config/auth.php'; ?>
<nav class="navbar navbar-expand-lg navbar-light topbar">
    <div class="container-fluid">
        <a class="navbar-brand text-success fw-bold" href="/agristack_farmer_registry/index.php">AgriStack Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if(isLoggedIn()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <i class="bi bi-bell"></i> 
                            <span class="badge bg-danger rounded-pill">0</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/login.php">Farmer Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/agristack_farmer_registry/admin/login.php">Admin Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-success text-white px-3 ms-2" href="/agristack_farmer_registry/register.php">Register</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
