<?php
$role = getUserRole();
?>
<div class="sidebar p-3">
    <h5 class="text-center text-white mb-4"><i class="bi bi-person-circle fs-2"></i><br><small><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></small></h5>
    
    <?php if ($role === 'farmer'): ?>
        <a href="/agristack_farmer_registry/farmer/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="/agristack_farmer_registry/farmer/profile.php"><i class="bi bi-person me-2"></i> Profile</a>
        <a href="/agristack_farmer_registry/farmer/ekyc.php"><i class="bi bi-fingerprint me-2"></i> eKYC</a>
        <a href="/agristack_farmer_registry/farmer/farms.php"><i class="bi bi-geo-alt me-2"></i> Farm Registry</a>
        <a href="/agristack_farmer_registry/farmer/geotag.php"><i class="bi bi-pin-map me-2"></i> Geo-Tagging</a>
        <a href="/agristack_farmer_registry/farmer/documents.php"><i class="bi bi-file-earmark-text me-2"></i> Documents</a>
        <a href="/agristack_farmer_registry/farmer/transactions.php"><i class="bi bi-receipt me-2"></i> Transactions</a>
        <a href="/agristack_farmer_registry/farmer/schemes.php"><i class="bi bi-journal-text me-2"></i> Schemes</a>
        <a href="/agristack_farmer_registry/farmer/applications.php"><i class="bi bi-ui-checks me-2"></i> Applications</a>
        <a href="/agristack_farmer_registry/farmer/notifications.php"><i class="bi bi-bell me-2"></i> Notifications</a>
        <a href="/agristack_farmer_registry/farmer/dossier.php"><i class="bi bi-file-person me-2"></i> Farmer Dossier</a>
    <?php elseif ($role === 'admin'): ?>
        <a href="/agristack_farmer_registry/admin/dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a href="/agristack_farmer_registry/admin/farmers.php"><i class="bi bi-people me-2"></i> Farmers</a>
        <a href="/agristack_farmer_registry/admin/ekyc.php"><i class="bi bi-fingerprint me-2"></i> eKYC Review</a>
        <a href="/agristack_farmer_registry/admin/documents.php"><i class="bi bi-file-earmark-text me-2"></i> Documents</a>
        <a href="/agristack_farmer_registry/admin/transactions.php"><i class="bi bi-receipt me-2"></i> Transactions</a>
        <a href="/agristack_farmer_registry/admin/applications.php"><i class="bi bi-ui-checks me-2"></i> Applications</a>
        <a href="/agristack_farmer_registry/admin/schemes.php"><i class="bi bi-journal-text me-2"></i> Schemes</a>
        <a href="/agristack_farmer_registry/admin/dbt.php"><i class="bi bi-cash-stack me-2"></i> DBT Sandbox</a>
        <a href="/agristack_farmer_registry/admin/notifications.php"><i class="bi bi-bell me-2"></i> Notifications</a>
        <a href="/agristack_farmer_registry/admin/audit-logs.php"><i class="bi bi-list-columns-reverse me-2"></i> Audit Logs</a>
        <a href="/agristack_farmer_registry/admin/project-info.php"><i class="bi bi-info-circle me-2"></i> Project Info</a>
    <?php endif; ?>
    <hr class="border-white">
    <a href="/agristack_farmer_registry/logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a>
</div>
