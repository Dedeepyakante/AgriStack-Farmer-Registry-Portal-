<?php
require_once 'config/auth.php';
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$stmt = $pdo->query("SELECT * FROM student_details LIMIT 1");
$project = $stmt->fetch();
?>
<div class="container mt-5">
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h1 class="display-4 text-success fw-bold">AgriStack Farmer Registry Portal</h1>
            <p class="lead mt-3">An academic prototype designed to demonstrate digital farmer registration, identity verification workflows, farm registration, geo-tagging, agricultural scheme applications, eSign, paperless documentation and DBT transaction simulation.</p>
            <div class="mt-4">
                <a href="register.php" class="btn btn-success btn-lg me-2">Farmer Registration</a>
                <a href="login.php" class="btn btn-outline-success btn-lg">Farmer Login</a>
            </div>
        </div>
        <div class="col-md-6">
            <img src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Agriculture" class="img-fluid rounded shadow">
        </div>
    </div>

    <div class="row text-center my-5">
        <h2 class="mb-4">Features & Workflow</h2>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-person-vcard fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Digital Registry & eKYC</h5>
                    <p class="card-text text-muted">Register and complete demo identity verification to receive a unique Farmer ID.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-geo-alt fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Farm Geo-Tagging</h5>
                    <p class="card-text text-muted">Register land records and accurately geo-tag farm locations on the map.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-ui-checks fs-1 text-success mb-3"></i>
                    <h5 class="card-title">Scheme Applications</h5>
                    <p class="card-text text-muted">Apply for agricultural schemes seamlessly with paperless eSign.</p>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card h-100 border-0 shadow-sm dashboard-card">
                <div class="card-body">
                    <i class="bi bi-cash-stack fs-1 text-success mb-3"></i>
                    <h5 class="card-title">DBT Simulation</h5>
                    <p class="card-text text-muted">Experience Direct Benefit Transfer workflows via a sandbox environment.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row my-5">
        <div class="col-12">
            <div class="card bg-light border-0">
                <div class="card-body p-5 text-center">
                    <h3 class="mb-3">About This Project</h3>
                    <p>This portal is developed strictly as a B.Tech academic prototype for educational purposes.</p>
                    <div class="row justify-content-center mt-4">
                        <div class="col-md-8 text-start">
                            <ul class="list-group list-group-flush bg-transparent">
                                <li class="list-group-item bg-transparent"><strong>Student Name:</strong> <?= htmlspecialchars($project['student_name']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Register Number:</strong> <?= htmlspecialchars($project['register_number']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Department:</strong> <?= htmlspecialchars($project['department']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>College:</strong> <?= htmlspecialchars($project['college_name']) ?></li>
                                <li class="list-group-item bg-transparent"><strong>Guide Name:</strong> <?= htmlspecialchars($project['guide_name']) ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
