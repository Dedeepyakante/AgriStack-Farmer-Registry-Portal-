<?php
/**
 * Land Patta Record Page (Public)
 * ================================
 * URL: /agristack_farmer_registry/land/patta.php?token=SECURE_TOKEN
 *
 * This page is intentionally public — it is the page that opens when
 * a QR code is scanned. It displays the Land / Patta record for the
 * specific geo-tagged farm identified by the secure QR token.
 *
 * SECURITY:
 *   - Token must be exactly 64 hex characters.
 *   - Looked up via PDO prepared statement.
 *   - No Aadhaar, mobile, password, or financial data is displayed.
 *   - All output is HTML-escaped.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/patta.php';

$token = trim($_GET['token'] ?? '');
$farm  = null;
$error = '';

/* ── Validate token format ── */
if ($token === '') {
    $error = 'No verification token provided in this QR link.';
} elseif (!preg_match('/^[0-9a-f]{64}$/', $token)) {
    $error = 'Invalid token format. This QR code may be corrupted or tampered.';
} else {
    /* ── Look up farm by token ── */
    $stmt = $pdo->prepare("
        SELECT
            f.id,
            f.farm_name,
            f.survey_number,
            f.village,
            f.mandal,
            f.district,
            f.state,
            f.land_area,
            f.land_unit,
            f.ownership_type,
            f.crop_type,
            f.irrigation_type,
            f.latitude,
            f.longitude,
            f.qr_generated_at,
            f.created_at        AS farm_registered_at,
            u.farmer_id,
            u.name              AS farmer_name
        FROM farms f
        INNER JOIN users u ON u.id = f.user_id
        WHERE f.qr_token = ?
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $farm = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$farm) {
        $error = 'Land Patta Record Not Found. This QR token is invalid or the record has been removed.';
    }
}

/* ── Helper: geo-tag status ── */
$geo_tagged   = $farm && !empty($farm['latitude']) && !empty($farm['longitude']);
$record_type  = isOfficialPattaConfigured() ? 'Official Patta' : 'Demo Patta Record';

$page_title = $farm
    ? 'Land Patta — ' . $farm['farm_name'] . ' | AgriStack'
    : 'Land Patta Record | AgriStack';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <meta name="description" content="Public Land Patta / Land Verification record from the AgriStack Farmer Registry. Academic prototype.">
    <meta name="robots" content="noindex, nofollow">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">

    <style>
        :root {
            --g-dark:  #145a32;
            --g-mid:   #1e8449;
            --g-light: #27ae60;
            --g-pale:  #f0fdf4;
            --g-bdr:   #bbf7d0;
        }
        body {
            background: linear-gradient(150deg, #e8f5e9 0%, #f1f8e9 60%, #e0f2f1 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        /* ── Disclaimer banner ── */
        .disclaimer-banner {
            background: var(--g-dark);
            color: rgba(255,255,255,0.82);
            text-align: center;
            font-size: 0.73rem;
            padding: 5px 12px;
            letter-spacing: 0.025em;
        }

        /* ── Hero header ── */
        .patta-hero {
            background: linear-gradient(135deg, var(--g-dark) 0%, var(--g-mid) 55%, var(--g-light) 100%);
            color: #fff;
            padding: 2.5rem 0 2rem;
        }
        .verified-chip {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            background: rgba(255,255,255,0.18);
            border: 1px solid rgba(255,255,255,0.38);
            border-radius: 999px;
            padding: 5px 16px;
            font-size: 0.82rem;
            backdrop-filter: blur(4px);
        }
        .demo-chip {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            background: rgba(255,220,0,0.22);
            border: 1px solid rgba(255,220,0,0.45);
            border-radius: 999px;
            padding: 5px 16px;
            font-size: 0.82rem;
        }

        /* ── Patta card ── */
        .patta-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 32px rgba(20,90,50,0.10);
        }
        .patta-card .card-section-title {
            font-size: 0.78rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--g-mid);
            padding-bottom: 6px;
            border-bottom: 2px solid var(--g-pale);
            margin-bottom: 12px;
        }

        /* ── Info rows ── */
        .info-row {
            display: flex;
            align-items: flex-start;
            padding: 9px 0;
            border-bottom: 1px solid #f3f4f6;
            font-size: 0.875rem;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label  { width: 46%; font-weight: 600; color: #5a6472; flex-shrink: 0; }
        .info-value  { color: #111827; }

        /* ── Status badges ── */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            border-radius: 999px;
            padding: 3px 12px;
            font-size: 0.78rem;
            font-weight: 700;
        }
        .badge-verified  { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .badge-demo      { background: #fef9c3; color: #713f12; border: 1px solid #fde047; }
        .badge-official  { background: #dbeafe; color: #1e3a8a; border: 1px solid #93c5fd; }

        /* ── Coordinates box ── */
        .coord-box {
            background: var(--g-pale);
            border: 1px solid var(--g-bdr);
            border-radius: 10px;
            padding: 12px 16px;
            font-family: 'Courier New', monospace;
            font-size: 0.83rem;
        }

        /* ── Map ── */
        .map-frame {
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid var(--g-bdr);
            box-shadow: 0 2px 14px rgba(20,90,50,0.08);
        }

        /* ── Error state ── */
        .error-wrap {
            max-width: 520px;
            margin: 80px auto;
            text-align: center;
        }
        .error-icon { font-size: 4rem; color: #ef4444; }

        /* ── Footer ── */
        .patta-footer {
            background: var(--g-dark);
            color: rgba(255,255,255,0.65);
            font-size: 0.75rem;
            text-align: center;
            padding: 14px;
            margin-top: 48px;
        }

        /* ── Print styles ── */
        @media print {
            .no-print, .patta-hero .d-flex { display: none !important; }
            body { background: #fff !important; }
            .patta-card { box-shadow: none !important; border: 1px solid #ddd; }
        }
    </style>
</head>
<body>

<!-- Disclaimer -->
<div class="disclaimer-banner">
    Academic Prototype &mdash; Not an official UIDAI, AgriStack or Government of India application.
</div>

<?php if ($error): ?>
<!-- ══════════════════════════════════════════════════
     ERROR STATE
     ══════════════════════════════════════════════════ -->
<div class="container py-5">
    <div class="error-wrap">
        <div class="error-icon mb-3"><i class="bi bi-x-octagon-fill"></i></div>
        <h3 class="fw-bold text-danger mb-2">Land Patta Record Not Found</h3>
        <p class="text-muted mb-4"><?= htmlspecialchars($error) ?></p>
        <div class="p-3 rounded mb-4" style="background:#fef2f2;border:1px solid #fecaca;">
            <div class="small text-muted">
                Possible reasons: the QR was regenerated (old token invalidated), the farm record
                was deleted, or this token never existed.
            </div>
        </div>
        <a href="/agristack_farmer_registry/" class="btn btn-outline-success">
            <i class="bi bi-house me-1"></i> Portal Home
        </a>
    </div>
</div>

<?php else: ?>
<!-- ══════════════════════════════════════════════════
     SUCCESS STATE — PATTA RECORD
     ══════════════════════════════════════════════════ -->

<!-- Hero -->
<div class="patta-hero">
    <div class="container text-center">
        <div class="mb-2 d-flex justify-content-center gap-2 flex-wrap">
            <span class="verified-chip">
                <i class="bi bi-patch-check-fill"></i> Token Verified
            </span>
            <span class="demo-chip">
                <i class="bi bi-exclamation-triangle-fill"></i> Academic Demo Patta Record
            </span>
        </div>
        <h1 class="fw-bold mt-3 mb-1" style="font-size:1.9rem;">
            🌾 Land Patta Record
        </h1>
        <p class="opacity-75 mb-1">AgriStack Farmer Registry — Geo-Tagged Farm / Land Record</p>
        <p class="opacity-60 small">
            Verified at <?= date('d M Y, h:i A') ?> &nbsp;|&nbsp;
            <strong>Not an official Government Land Record</strong>
        </p>
    </div>
</div>

<div class="container py-4">

    <!-- ── Official disclaimer block ── -->
    <div class="alert d-flex align-items-start gap-3 mb-4"
         style="background:#fffbeb;border:1.5px solid #fde68a;border-radius:12px;">
        <i class="bi bi-exclamation-triangle-fill text-warning fs-5 flex-shrink-0 mt-1"></i>
        <div>
            <div class="fw-bold text-warning-emphasis mb-1">Academic Prototype — Demo Land / Patta Record</div>
            <div class="small text-muted">
                This page is part of an academic project simulating the AgriStack Farmer Registry.
                The information shown is from the project's demonstration database only.
                <strong>This is NOT an official Government Land Record or Patta.</strong>
                <?php if (!isOfficialPattaConfigured()): ?>
                No official government patta URL has been configured for this installation.
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="row g-4">

        <!-- ══ LEFT: Patta details ══ -->
        <div class="col-lg-5">
            <div class="patta-card p-4 h-100">

                <!-- Farmer section -->
                <div class="card-section-title"><i class="bi bi-person-fill me-1"></i>Farmer Details</div>
                <div class="info-row">
                    <div class="info-label">Farmer ID</div>
                    <div class="info-value">
                        <span class="fw-bold text-success font-monospace">
                            <?= htmlspecialchars($farm['farmer_id'] ?? 'N/A') ?>
                        </span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Farmer Name</div>
                    <div class="info-value"><?= htmlspecialchars($farm['farmer_name']) ?></div>
                </div>

                <!-- Farm / Land section -->
                <div class="card-section-title mt-4"><i class="bi bi-geo-alt-fill me-1"></i>Farm / Land Details</div>
                <div class="info-row">
                    <div class="info-label">Farm / Land Name</div>
                    <div class="info-value fw-semibold"><?= htmlspecialchars($farm['farm_name']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Survey / Patta Number</div>
                    <div class="info-value fw-bold text-success"><?= htmlspecialchars($farm['survey_number']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Village</div>
                    <div class="info-value"><?= htmlspecialchars($farm['village']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Mandal</div>
                    <div class="info-value"><?= htmlspecialchars($farm['mandal']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">District</div>
                    <div class="info-value"><?= htmlspecialchars($farm['district']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">State</div>
                    <div class="info-value"><?= htmlspecialchars($farm['state']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Land Area</div>
                    <div class="info-value">
                        <strong><?= htmlspecialchars($farm['land_area']) ?></strong>
                        <?= htmlspecialchars($farm['land_unit']) ?>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ownership Type</div>
                    <div class="info-value"><?= htmlspecialchars($farm['ownership_type']) ?></div>
                </div>
                <?php if (!empty($farm['crop_type'])): ?>
                <div class="info-row">
                    <div class="info-label">Crop Type</div>
                    <div class="info-value"><?= htmlspecialchars($farm['crop_type']) ?></div>
                </div>
                <?php endif; ?>
                <?php if (!empty($farm['irrigation_type'])): ?>
                <div class="info-row">
                    <div class="info-label">Irrigation Type</div>
                    <div class="info-value"><?= htmlspecialchars($farm['irrigation_type']) ?></div>
                </div>
                <?php endif; ?>

                <!-- Geo-tagging section -->
                <div class="card-section-title mt-4">
                    <i class="bi bi-crosshair2 me-1"></i>Geo-Tagging
                </div>
                <div class="info-row">
                    <div class="info-label">Latitude</div>
                    <div class="info-value font-monospace small">
                        <?= htmlspecialchars($farm['latitude']) ?>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Longitude</div>
                    <div class="info-value font-monospace small">
                        <?= htmlspecialchars($farm['longitude']) ?>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Geo-Tagging Status</div>
                    <div class="info-value">
                        <?php if ($geo_tagged): ?>
                        <span class="status-badge badge-verified">
                            <i class="bi bi-check-circle-fill"></i> Geo-Tagged
                        </span>
                        <?php else: ?>
                        <span class="status-badge" style="background:#fee2e2;color:#7f1d1d;border:1px solid #fca5a5;">
                            <i class="bi bi-x-circle-fill"></i> Not Geo-Tagged
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Record status section -->
                <div class="card-section-title mt-4">
                    <i class="bi bi-shield-check me-1"></i>Record Status
                </div>
                <div class="info-row">
                    <div class="info-label">Land Record Status</div>
                    <div class="info-value">
                        <span class="status-badge badge-verified">
                            <i class="bi bi-database-check"></i> Active
                        </span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Record Type</div>
                    <div class="info-value">
                        <?php if (isOfficialPattaConfigured()): ?>
                        <span class="status-badge badge-official">
                            <i class="bi bi-bank"></i> <?= htmlspecialchars(PATTA_OFFICIAL_LABEL) ?>
                        </span>
                        <?php else: ?>
                        <span class="status-badge badge-demo">
                            <i class="bi bi-mortarboard-fill"></i> Demo Patta Record
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">Farm Registered On</div>
                    <div class="info-value">
                        <?= date('d M Y', strtotime($farm['farm_registered_at'])) ?>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-label">QR Generated On</div>
                    <div class="info-value">
                        <?= $farm['qr_generated_at']
                            ? date('d M Y, h:i A', strtotime($farm['qr_generated_at']))
                            : 'N/A' ?>
                    </div>
                </div>

                <!-- Coordinates box -->
                <div class="coord-box mt-3">
                    <div class="text-muted small fw-semibold mb-1">
                        <i class="bi bi-crosshair2 me-1"></i>Verified GPS Coordinates
                    </div>
                    <div>📍 Lat: <strong><?= htmlspecialchars($farm['latitude']) ?></strong></div>
                    <div>📍 Lng: <strong><?= htmlspecialchars($farm['longitude']) ?></strong></div>
                </div>

                <!-- Actions -->
                <div class="mt-3 d-flex gap-2 flex-wrap no-print">
                    <button onclick="window.print()" class="btn btn-sm btn-outline-secondary">
                        <i class="bi bi-printer me-1"></i> Print Patta
                    </button>
                    <a href="/agristack_farmer_registry/" class="btn btn-sm btn-outline-success">
                        <i class="bi bi-house me-1"></i> Portal Home
                    </a>
                </div>
            </div>
        </div>

        <!-- ══ RIGHT: Map ══ -->
        <div class="col-lg-7">
            <div class="patta-card p-4">
                <h6 class="fw-bold text-success mb-3">
                    <i class="bi bi-map me-2"></i>Farm Location — Interactive Map
                </h6>
                <div class="map-frame">
                    <div id="map" style="height: 420px;"></div>
                </div>

                <!-- Info note below map -->
                <div class="mt-3 p-3 rounded" style="background:var(--g-pale);border:1px solid var(--g-bdr);">
                    <div class="small fw-semibold text-success mb-1">
                        <i class="bi bi-info-circle me-1"></i>How this QR works
                    </div>
                    <div class="small text-muted">
                        The QR code scanned to reach this page encodes only a
                        <strong>secure random URL</strong>. Your Aadhaar number, mobile number,
                        and financial details are <strong>never stored in the QR code</strong>.
                        The farm record is retrieved from the AgriStack database using a
                        one-way token that cannot be reverse-engineered.
                    </div>
                </div>

                <!-- Additional farm info card -->
                <div class="mt-3 row g-2">
                    <div class="col-6">
                        <div class="p-3 rounded text-center" style="background:#f8fafc;border:1px solid #e2e8f0;">
                            <div class="small text-muted fw-semibold">Land Area</div>
                            <div class="fw-bold text-success fs-5">
                                <?= htmlspecialchars($farm['land_area']) ?>
                                <small class="fs-6 fw-normal"><?= htmlspecialchars($farm['land_unit']) ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 rounded text-center" style="background:#f8fafc;border:1px solid #e2e8f0;">
                            <div class="small text-muted fw-semibold">Ownership</div>
                            <div class="fw-bold text-success fs-6">
                                <?= htmlspecialchars($farm['ownership_type']) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!-- /row -->
</div><!-- /container -->

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const lat      = <?= json_encode((float)$farm['latitude']) ?>;
    const lng      = <?= json_encode((float)$farm['longitude']) ?>;
    const farmName = <?= json_encode(htmlspecialchars($farm['farm_name'])) ?>;
    const village  = <?= json_encode(htmlspecialchars($farm['village'])) ?>;
    const district = <?= json_encode(htmlspecialchars($farm['district'])) ?>;
    const area     = <?= json_encode($farm['land_area'] . ' ' . $farm['land_unit']) ?>;
    const surveyNo = <?= json_encode(htmlspecialchars($farm['survey_number'])) ?>;

    const map = L.map('map').setView([lat, lng], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    /* Custom green pin icon */
    const greenPin = L.divIcon({
        html: `<div style="
            width:30px;height:30px;
            background:linear-gradient(135deg,#145a32,#27ae60);
            border:3px solid #fff;
            border-radius:50% 50% 50% 0;
            transform:rotate(-45deg);
            box-shadow:0 3px 10px rgba(0,0,0,.35);
        "></div>`,
        className: '',
        iconSize: [30, 30],
        iconAnchor: [15, 30],
        popupAnchor: [0, -32]
    });

    L.marker([lat, lng], { icon: greenPin })
        .addTo(map)
        .bindPopup(`
            <div style="font-family:system-ui;min-width:200px;line-height:1.5;">
                <div style="font-weight:700;color:#145a32;font-size:1rem;">📍 ${farmName}</div>
                <div style="color:#555;font-size:0.8rem;">${village}, ${district}</div>
                <div style="margin:6px 0;font-size:0.8rem;">
                    <span style="color:#888;">Survey No:</span> <strong>${surveyNo}</strong>
                </div>
                <div style="font-size:0.8rem;">
                    <span style="color:#888;">Area:</span> <strong>${area}</strong>
                </div>
                <div style="font-family:monospace;font-size:0.72rem;color:#555;margin-top:6px;">
                    ${lat.toFixed(6)}, ${lng.toFixed(6)}
                </div>
            </div>
        `, { maxWidth: 240 })
        .openPopup();

    /* Highlight circle */
    L.circle([lat, lng], {
        radius: 60,
        color: '#1e8449',
        fillColor: '#27ae60',
        fillOpacity: 0.12,
        weight: 2,
        dashArray: '6 4'
    }).addTo(map);
});
</script>

<?php endif; // end success state ?>

<!-- Footer -->
<div class="patta-footer">
    AgriStack Farmer Registry &mdash; Academic Prototype &mdash;
    Not an official UIDAI, AgriStack or Government of India application.
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
