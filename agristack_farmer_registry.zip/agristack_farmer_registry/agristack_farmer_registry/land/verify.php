<?php
/**
 * Land Verification Page (Public)
 * URL: /agristack_farmer_registry/land/verify.php?token=UNIQUE_TOKEN
 *
 * This page is intentionally public — it shows only non-sensitive farm
 * geo-location details. No Aadhaar, mobile, password or financial data
 * is exposed here.
 */

require_once __DIR__ . '/../config/database.php';

$token   = trim($_GET['token'] ?? '');
$farm    = null;
$farmer  = null;
$error   = '';

if ($token === '') {
    $error = 'No verification token provided.';
} elseif (!preg_match('/^[0-9a-f]{64}$/', $token)) {
    $error = 'Invalid token format.';
} else {
    // Fetch farm by token — join users for farmer name only
    $stmt = $pdo->prepare("
        SELECT f.id, f.farm_name, f.survey_number, f.village, f.mandal,
               f.district, f.state, f.land_area, f.land_unit, f.ownership_type,
               f.crop_type, f.irrigation_type, f.latitude, f.longitude,
               f.qr_generated_at, f.created_at,
               u.farmer_id, u.name AS farmer_name
        FROM farms f
        JOIN users u ON u.id = f.user_id
        WHERE f.qr_token = ?
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $farm = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$farm) {
        $error = 'No land record found for this QR code. The token may be invalid or expired.';
    }
}

$page_title = $farm ? 'Land Verification — ' . htmlspecialchars($farm['farm_name']) : 'Land Verification';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> | AgriStack Farmer Registry</title>
    <meta name="description" content="Public land verification page for AgriStack Farmer Registry. Scan the QR code to verify land geo-tagging details.">
    <meta name="robots" content="noindex, nofollow">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <style>
        :root {
            --green-dark:   #145a32;
            --green-mid:    #1e8449;
            --green-light:  #27ae60;
            --green-pale:   #f0fdf4;
            --border-green: #bbf7d0;
        }

        body {
            background: linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 50%, #e0f2f1 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        .disclaimer-banner {
            background: #145a32;
            color: rgba(255,255,255,0.85);
            text-align: center;
            font-size: 0.75rem;
            padding: 5px 12px;
            letter-spacing: 0.03em;
        }

        .verify-hero {
            background: linear-gradient(135deg, var(--green-dark) 0%, var(--green-mid) 60%, var(--green-light) 100%);
            color: #fff;
            padding: 2.5rem 0 1.5rem;
        }
        .verify-hero .badge-status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.18);
            border: 1px solid rgba(255,255,255,0.35);
            border-radius: 999px;
            padding: 4px 14px;
            font-size: 0.8rem;
            backdrop-filter: blur(4px);
        }

        .verify-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 30px rgba(20,90,50,0.10);
        }

        .info-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label {
            width: 42%;
            font-weight: 600;
            color: #555;
            font-size: 0.87rem;
        }
        .info-value {
            color: #1a1a1a;
            font-size: 0.87rem;
        }

        .coords-box {
            background: var(--green-pale);
            border: 1px solid var(--border-green);
            border-radius: 10px;
            padding: 12px 16px;
            font-family: monospace;
            font-size: 0.85rem;
        }

        .map-frame {
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid var(--border-green);
            box-shadow: 0 2px 16px rgba(20,90,50,0.08);
        }

        .verified-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: linear-gradient(90deg, #d1fae5, #a7f3d0);
            border: 1.5px solid #34d399;
            border-radius: 999px;
            padding: 6px 18px;
            font-size: 0.85rem;
            font-weight: 700;
            color: #065f46;
        }

        .error-section {
            max-width: 520px;
            margin: 80px auto;
        }
        .error-icon { font-size: 4rem; color: #dc3545; }

        @media print {
            .no-print { display: none !important; }
            body { background: #fff !important; }
            .verify-card { box-shadow: none !important; }
        }
    </style>
</head>
<body>
<div class="disclaimer-banner">
    Academic Prototype &mdash; Not an official UIDAI, AgriStack or Government of India application.
</div>

<?php if ($error): ?>
<!-- ============ ERROR STATE ============ -->
<div class="container">
    <div class="error-section text-center">
        <div class="error-icon mb-3"><i class="bi bi-exclamation-octagon-fill"></i></div>
        <h3 class="fw-bold text-danger mb-2">Verification Failed</h3>
        <p class="text-muted mb-4"><?= htmlspecialchars($error) ?></p>
        <a href="/agristack_farmer_registry/" class="btn btn-outline-success">
            <i class="bi bi-house me-1"></i> Go to Portal Home
        </a>
    </div>
</div>

<?php else: ?>
<!-- ============ SUCCESS STATE ============ -->

<!-- Hero Banner -->
<div class="verify-hero">
    <div class="container text-center">
        <div class="mb-2">
            <span class="verified-badge">
                <i class="bi bi-patch-check-fill"></i> Record Verified
            </span>
        </div>
        <h1 class="fw-bold mt-3 mb-1" style="font-size:1.8rem;">🌾 Land Verification Portal</h1>
        <p class="opacity-75 mb-2">AgriStack Farmer Registry — Farm Geo-Tagging Record</p>
        <div class="badge-status mt-1">
            <i class="bi bi-shield-lock-fill"></i>
            Secure Token Match — Verified <?= date('d M Y, h:i A') ?>
        </div>
    </div>
</div>

<!-- Content -->
<div class="container py-4">
    <div class="row justify-content-center g-4">

        <!-- Farm Details Card -->
        <div class="col-lg-5">
            <div class="verify-card p-4 h-100">
                <h5 class="fw-bold text-success mb-1">
                    <i class="bi bi-geo-alt-fill me-2"></i><?= htmlspecialchars($farm['farm_name']) ?>
                </h5>
                <p class="small text-muted mb-3">Survey No. <?= htmlspecialchars($farm['survey_number']) ?></p>

                <div class="info-row">
                    <div class="info-label">Farmer ID</div>
                    <div class="info-value font-monospace fw-semibold text-success"><?= htmlspecialchars($farm['farmer_id'] ?? 'N/A') ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Farmer Name</div>
                    <div class="info-value"><?= htmlspecialchars($farm['farmer_name']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Village</div>
                    <div class="info-value"><?= htmlspecialchars($farm['village']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Mandal</div>
                    <div class="info-value"><?= htmlspecialchars($farm['mandal']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">District</div>
                    <div class="info-value"><?= htmlspecialchars($farm['district']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">State</div>
                    <div class="info-value"><?= htmlspecialchars($farm['state']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Land Area</div>
                    <div class="info-value"><?= htmlspecialchars($farm['land_area']) ?> <?= htmlspecialchars($farm['land_unit']) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ownership</div>
                    <div class="info-value"><?= htmlspecialchars($farm['ownership_type']) ?></div>
                </div>
                <?php if (!empty($farm['crop_type'])): ?>
                <div class="info-row">
                    <div class="info-label">Crop Type</div>
                    <div class="info-value"><?= htmlspecialchars($farm['crop_type']) ?></div>
                </div>
                <?php endif; ?>
                <?php if (!empty($farm['irrigation_type'])): ?>
                <div class="info-row">
                    <div class="info-label">Irrigation</div>
                    <div class="info-value"><?= htmlspecialchars($farm['irrigation_type']) ?></div>
                </div>
                <?php endif; ?>
                <div class="info-row">
                    <div class="info-label">Registered On</div>
                    <div class="info-value"><?= date('d M Y', strtotime($farm['created_at'])) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">QR Generated</div>
                    <div class="info-value"><?= $farm['qr_generated_at'] ? date('d M Y, h:i A', strtotime($farm['qr_generated_at'])) : 'N/A' ?></div>
                </div>

                <!-- Coordinates box -->
                <div class="coords-box mt-3">
                    <div class="text-muted small fw-semibold mb-1"><i class="bi bi-crosshair2 me-1"></i>Geo-Coordinates (Verified)</div>
                    <div>📍 Latitude: <strong><?= htmlspecialchars($farm['latitude']) ?></strong></div>
                    <div>📍 Longitude: <strong><?= htmlspecialchars($farm['longitude']) ?></strong></div>
                </div>

                <!-- Actions -->
                <div class="mt-3 d-flex gap-2 flex-wrap no-print">
                    <button onclick="window.print()" class="btn btn-sm btn-outline-secondary">
                        <i class="bi bi-printer me-1"></i> Print
                    </button>
                    <a href="/agristack_farmer_registry/" class="btn btn-sm btn-outline-success">
                        <i class="bi bi-house me-1"></i> Portal Home
                    </a>
                </div>
            </div>
        </div>

        <!-- Map Card -->
        <div class="col-lg-7">
            <div class="verify-card p-4 h-100">
                <h5 class="fw-bold text-success mb-3">
                    <i class="bi bi-map me-2"></i>Farm Location on Map
                </h5>
                <div class="map-frame">
                    <div id="map" style="height: 400px;"></div>
                </div>
                <div class="mt-3 p-3 rounded" style="background:#f0fdf4;border:1px solid #bbf7d0;">
                    <div class="small text-success fw-semibold mb-1">
                        <i class="bi bi-info-circle me-1"></i>Verification Note
                    </div>
                    <div class="small text-muted">
                        This page confirms the geo-tagging record stored in the AgriStack Farmer Registry for the above farm.
                        The QR code encodes only a secure verification URL — no Aadhaar, mobile number, or financial data is embedded.
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const lat = <?= json_encode((float)$farm['latitude']) ?>;
    const lng = <?= json_encode((float)$farm['longitude']) ?>;
    const farmName = <?= json_encode(htmlspecialchars($farm['farm_name'])) ?>;
    const district = <?= json_encode(htmlspecialchars($farm['district'])) ?>;

    const map = L.map('map').setView([lat, lng], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    // Custom green marker
    const greenIcon = L.divIcon({
        html: `<div style="
            background: linear-gradient(135deg,#145a32,#27ae60);
            border: 3px solid #fff;
            border-radius: 50% 50% 50% 0;
            transform: rotate(-45deg);
            width: 28px; height: 28px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        "></div>`,
        className: '',
        iconSize: [28, 28],
        iconAnchor: [14, 28],
        popupAnchor: [0, -30]
    });

    L.marker([lat, lng], { icon: greenIcon })
        .addTo(map)
        .bindPopup(`
            <div style="font-family:system-ui;min-width:180px;">
                <div style="font-weight:700;color:#145a32;font-size:1rem;">📍 ${farmName}</div>
                <div style="color:#555;font-size:0.8rem;margin:4px 0;">${district}</div>
                <div style="font-family:monospace;font-size:0.75rem;color:#333;">
                    Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}
                </div>
            </div>
        `, { maxWidth: 220 })
        .openPopup();

    // Circle to highlight the area
    L.circle([lat, lng], {
        radius: 50,
        color: '#1e8449',
        fillColor: '#27ae60',
        fillOpacity: 0.15,
        weight: 2,
        dashArray: '6 4'
    }).addTo(map);
});
</script>

<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
