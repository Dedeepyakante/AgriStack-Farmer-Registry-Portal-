<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

// If already logged in, redirect to appropriate dashboard
if (isLoggedIn()) {
    if (getUserRole() === 'farmer') {
        header("Location: farmer/dashboard.php");
        exit;
    } else {
        header("Location: admin/dashboard.php");
        exit;
    }
}

$error = '';
$mobile_val = '';

// Pick up errors set by Google OAuth callback or other redirects
if (!empty($_SESSION['login_error'])) {
    $error = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $identity = trim($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha  = $_POST['captcha'] ?? '';
    $mobile_val = $identity;

    if (empty($identity) || empty($password)) {
        $error = 'Please enter both Mobile Number and Password.';
    } elseif (!isset($_SESSION['captcha_answer']) || $captcha === '' || (int)$captcha !== (int)$_SESSION['captcha_answer']) {
        $error = 'Invalid CAPTCHA answer. Please solve the calculation again.';
    } else {
        // Look up farmer by mobile or farmer_id or email
        $stmt = $pdo->prepare("SELECT * FROM users WHERE (mobile = ? OR farmer_id = ? OR email = ?) AND role = 'farmer'");
        $stmt->execute([$identity, $identity, $identity]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if (isset($user['status']) && $user['status'] !== 'active') {
                $error = 'Your farmer account is inactive. Please contact support.';
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role']    = $user['role'];
                $_SESSION['name']    = $user['name'];

                logAudit($pdo, $user['id'], $user['role'], 'Login', 'Farmer logged in successfully.');

                header("Location: farmer/dashboard.php");
                exit;
            }
        } else {
            // Check if identity belongs to an admin account
            $chkAdmin = $pdo->prepare("SELECT id, name FROM users WHERE (mobile = ? OR email = ?) AND role = 'admin'");
            $chkAdmin->execute([$identity, $identity]);
            $isAdmin = $chkAdmin->fetch();

            if ($isAdmin) {
                $error = 'This account is registered as an <strong>Administrator</strong>. <br><a href="admin/login.php" class="alert-link">Click here to Login to Admin Portal</a>.';
            } else {
                $error = 'Invalid mobile number or password. Please check your credentials or <a href="register.php" class="alert-link">Register New Farmer</a>.';
            }
        }
    }
}

// Generate simple captcha
$num1 = rand(1, 10);
$num2 = rand(1, 10);
$_SESSION['captcha_answer'] = $num1 + $num2;

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0">
                <div class="card-header bg-success text-white text-center py-3">
                    <div class="mb-1"><i class="bi bi-person-circle fs-2"></i></div>
                    <h4 class="mb-0 fw-bold">Farmer Login</h4>
                    <small class="text-light opacity-75">AgriStack Farmer Registry Portal</small>
                </div>
                <div class="card-body p-4">
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form method="post" action="login.php" novalidate>
                        <div class="mb-3">
                            <label for="mobile" class="form-label fw-semibold">Registered Mobile / Email / Farmer ID</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-person-badge"></i></span>
                                <input type="text" id="mobile" name="mobile" class="form-control" value="<?= htmlspecialchars($mobile_val) ?>" placeholder="Enter Mobile, Email, or Farmer ID" required autofocus>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label fw-semibold">Password</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-key"></i></span>
                                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label for="captcha" class="form-label fw-semibold">Security Verification</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light font-monospace fw-bold text-dark"><?= $num1 ?> + <?= $num2 ?> = ?</span>
                                <input type="number" id="captcha" name="captcha" class="form-control" placeholder="Result" required>
                            </div>
                        </div>

                        <button type="submit" name="login" class="btn btn-success w-100 py-2 fw-semibold">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login to Farmer Portal
                        </button>
                    </form>

                    <div class="text-center my-3 position-relative">
                        <hr>
                        <span class="position-absolute top-50 start-50 translate-middle bg-white px-2 text-muted small">OR</span>
                    </div>

                    <a href="sso_demo.php" class="btn btn-outline-danger w-100 py-2 d-flex align-items-center justify-content-center gap-2 mb-3" style="border-color:#db4437;color:#db4437;font-weight:600;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.2H42V20H24v8h11.3C33.7 33.1 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.5 6.5 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.8z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.6 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34.5 6.5 29.5 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.3 26.7 36 24 36c-5.2 0-9.6-3-11.3-7.2l-6.5 5C9.6 39.6 16.3 44 24 44z"/><path fill="#1976D2" d="M43.6 20.2H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.3 5.6l6.2 5.2C37 38.1 44 33 44 24c0-1.3-.1-2.7-.4-3.8z"/></svg>
                        Continue with Google
                    </a>

                    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                        <a href="forgot-password.php" class="text-decoration-none small text-danger fw-semibold">
                            <i class="bi bi-question-circle me-1"></i>Forgot Password?
                        </a>
                        <a href="register.php" class="text-decoration-none small text-success fw-semibold">
                            <i class="bi bi-person-plus me-1"></i>Register New Farmer
                        </a>
                    </div>

                    <div class="mt-3 pt-2 border-top">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>
                <div class="card-footer bg-light border-0 py-3 text-center">
                    <small class="text-muted">
                        <i class="bi bi-shield-check me-1"></i>Secure AgriStack Farmer Registry Portal
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
