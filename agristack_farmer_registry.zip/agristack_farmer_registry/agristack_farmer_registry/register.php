<?php
session_start();
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$error = '';
$success = '';

$name = '';
$dob = '';
$gender = 'Male';
$mobile = '';
$email = '';
$address = '';
$district = '';
$state = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? 'Male';
    $mobile = trim($_POST['mobile'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $district = trim($_POST['district'] ?? '');
    $state = trim($_POST['state'] ?? '');
    $password = $_POST['password'] ?? '';
    $cpassword = $_POST['cpassword'] ?? '';
    $captcha = $_POST['captcha'] ?? '';

    if (!isset($_SESSION['captcha_answer']) || (int)$captcha !== (int)$_SESSION['captcha_answer']) {
        $error = 'Invalid CAPTCHA solution. Please solve the calculation again.';
    } elseif (empty($name)) {
        $error = 'Please enter your full name.';
    } elseif (strlen($mobile) !== 10 || !ctype_digit($mobile)) {
        $error = 'Please enter a valid 10-digit mobile number.';
    } elseif (empty($email)) {
        $error = 'Email address is required to register your Farmer account.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address format (e.g. farmer@example.com).';
    } elseif ($password !== $cpassword) {
        $error = 'Passwords do not match. Please re-enter.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } else {
        // Check for existing mobile number
        $stmt = $pdo->prepare("SELECT id, role FROM users WHERE mobile = ?");
        $stmt->execute([$mobile]);
        $existing = $stmt->fetch();

        // Check for existing email address to prevent duplicate accounts
        $stmtEmail = $pdo->prepare("SELECT id, role FROM users WHERE email = ?");
        $stmtEmail->execute([$email]);
        $existingEmail = $stmtEmail->fetch();

        if ($existing) {
            if ($existing['role'] === 'farmer') {
                $error = 'This mobile number is already registered as a Farmer. <a href="login.php" class="alert-link">Login here</a> or <a href="forgot-password.php" class="alert-link">Reset Password</a>.';
            } else {
                $error = 'This mobile number is registered as an Administrator. <a href="admin/login.php" class="alert-link">Admin Login</a>.';
            }
        } elseif ($existingEmail) {
            if ($existingEmail['role'] === 'farmer') {
                $error = 'This email address is already registered to an existing Farmer account. <a href="login.php" class="alert-link">Login here</a> or use a different email.';
            } else {
                $error = 'This email address is registered as an Administrator. <a href="admin/login.php" class="alert-link">Admin Login</a>.';
            }
        } else {
            require_once 'includes/functions.php';
            $farmer_id = generateFarmerId($pdo);
            $hash = password_hash($password, PASSWORD_DEFAULT);

            try {
                $pdo->beginTransaction();
                
                $stmt = $pdo->prepare("INSERT INTO users (farmer_id, name, email, mobile, password_hash, role) VALUES (?, ?, ?, ?, ?, 'farmer')");
                $stmt->execute([$farmer_id, $name, $email, $mobile, $hash]);
                $user_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO farmer_profiles (user_id, dob, gender, address, district, state) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $dob, $gender, $address, $district, $state]);
                
                logAudit($pdo, $user_id, 'farmer', 'Registration', "Registered with Farmer ID $farmer_id (Email: $email)");
                
                $pdo->commit();
                $success = "Registration Successful! Your Farmer ID is: <b>$farmer_id</b>";
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Registration failed. ' . $e->getMessage();
            }
        }
    }
}

$num1 = rand(1, 10);
$num2 = rand(1, 10);
$_SESSION['captcha_answer'] = $num1 + $num2;
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow mb-5">
                <div class="card-header bg-success text-white text-center">
                    <h4>Farmer Registration</h4>
                    <small class="text-light">Create your official AgriStack Farmer Account</small>
                </div>
                <div class="card-body p-4">
                    <?php if($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if($success): ?>
                        <div class="alert alert-success text-center">
                            <h4><?= $success ?></h4>
                            <p>Your email <b><?= htmlspecialchars($email) ?></b> and mobile <b><?= htmlspecialchars($mobile) ?></b> are linked to this Farmer ID.</p>
                            <a href="login.php" class="btn btn-success mt-3"><i class="bi bi-box-arrow-in-right me-1"></i> Go to Login</a>
                        </div>
                    <?php else: ?>
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="fw-semibold">Full Name *</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($name) ?>" required placeholder="e.g. Ramesh Kumar">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="fw-semibold">Mobile Number *</label>
                                <input type="tel" name="mobile" class="form-control" required maxlength="10" pattern="[0-9]{10}" value="<?= htmlspecialchars($mobile) ?>" placeholder="10-digit mobile">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="fw-semibold">Email Address *</label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required placeholder="farmer@example.com">
                                <small class="text-muted">Required for DBT alerts, digital eSign & notifications.</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Date of Birth *</label>
                                <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($dob) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Gender *</label>
                                <select name="gender" class="form-select" required>
                                    <option value="Male" <?= $gender === 'Male' ? 'selected' : '' ?>>Male</option>
                                    <option value="Female" <?= $gender === 'Female' ? 'selected' : '' ?>>Female</option>
                                    <option value="Other" <?= $gender === 'Other' ? 'selected' : '' ?>>Other</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label>Address *</label>
                                <textarea name="address" class="form-control" required><?= htmlspecialchars($address) ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>District *</label>
                                <input type="text" name="district" class="form-control" value="<?= htmlspecialchars($district) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>State *</label>
                                <input type="text" name="state" class="form-control" value="<?= htmlspecialchars($state) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Password *</label>
                                <input type="password" name="password" class="form-control" required minlength="8">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Confirm Password *</label>
                                <input type="password" name="cpassword" class="form-control" required minlength="8">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Solve: <?= $num1 ?> + <?= $num2 ?> = ? *</label>
                                <input type="number" name="captcha" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Register</button>
                    </form>
                    <div class="text-center mt-3">
                        Already registered? <a href="login.php" class="text-decoration-none fw-bold text-success">Login here</a>
                    </div>
                    <?php endif; ?>
                    <div class="mt-3 pt-2 border-top">
                        <a href="index.php" class="btn btn-outline-secondary btn-sm w-100 py-2">
                            <i class="bi bi-house-door-fill me-1"></i> Return to Portal Home Page
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
