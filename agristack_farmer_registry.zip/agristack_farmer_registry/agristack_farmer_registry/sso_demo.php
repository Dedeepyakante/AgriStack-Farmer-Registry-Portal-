<?php
/**
 * Google OAuth Initiator — redirects the user to Google's account chooser
 * AgriStack Farmer Registry Portal
 */
session_start();
require_once __DIR__ . '/config/google.php';

if (!googleOAuthConfigured()) {
    // Google not yet configured — show setup instructions page
    require_once __DIR__ . '/config/database.php';
    require_once __DIR__ . '/includes/header.php';
    require_once __DIR__ . '/includes/navbar.php';
    ?>
    <div class="container mt-5 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow border-0">
                    <div class="card-header bg-warning text-dark text-center py-3">
                        <div class="mb-1"><i class="bi bi-google fs-2"></i></div>
                        <h4 class="mb-0 fw-bold">Google Sign-In Not Configured</h4>
                        <small class="opacity-75">Google OAuth credentials are missing</small>
                    </div>
                    <div class="card-body p-4">
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            <strong>Setup Required:</strong> To enable Google Sign-In, you need to configure Google OAuth credentials.
                        </div>
                        <h6 class="fw-bold mb-3"><i class="bi bi-list-ol me-2"></i>Setup Steps:</h6>
                        <ol class="list-group list-group-numbered mb-3">
                            <li class="list-group-item d-flex gap-2">
                                <div>Go to <a href="https://console.cloud.google.com/" target="_blank" class="fw-bold">Google Cloud Console</a> and create a project.</div>
                            </li>
                            <li class="list-group-item d-flex gap-2">
                                <div>Navigate to <strong>APIs &amp; Services &rarr; Credentials</strong> &rarr; <strong>Create OAuth 2.0 Client ID</strong>.</div>
                            </li>
                            <li class="list-group-item d-flex gap-2">
                                <div>Set Application Type to <strong>Web Application</strong>.</div>
                            </li>
                            <li class="list-group-item d-flex gap-2">
                                <div>Add Authorized Redirect URI:<br>
                                    <code class="bg-light px-2 py-1 rounded d-block mt-1">http://localhost/agristack_farmer_registry/auth/google-callback.php</code>
                                </div>
                            </li>
                            <li class="list-group-item d-flex gap-2">
                                <div>Copy your <strong>Client ID</strong> and <strong>Client Secret</strong> into <code>config/google.php</code>.</div>
                            </li>
                        </ol>
                        <div class="bg-light border rounded p-3 mb-3">
                            <small class="text-muted d-block mb-1">Edit: <code>config/google.php</code></small>
                            <pre class="mb-0 small"><code>define('GOOGLE_CLIENT_ID',     'YOUR_CLIENT_ID_HERE.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'YOUR_CLIENT_SECRET_HERE');</code></pre>
                        </div>
                        <a href="login.php" class="btn btn-success w-100 py-2 fw-semibold">
                            <i class="bi bi-arrow-left me-1"></i> Back to Farmer Login
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

// Generate CSRF state token and store in session
$state = bin2hex(random_bytes(16));
$_SESSION['google_oauth_state'] = $state;

// Redirect user to Google's account chooser
$googleAuthUrl = buildGoogleAuthUrl($state);
header('Location: ' . $googleAuthUrl);
exit;
