<?php
/**
 * Automated Verification Suite for AadhaarXmlVerifier
 * Tests X.509 certificate parsing, signature validation, tampering detection, and trust boundary.
 */

require_once dirname(__DIR__) . '/includes/AadhaarXmlVerifier.php';

$passed = 0;
$failed = 0;

function assertTest(string $name, bool $condition, string $detail = '') {
    global $passed, $failed;
    if ($condition) {
        echo "  [PASS] $name\n";
        $passed++;
    } else {
        echo "  [FAIL] $name" . ($detail ? " ($detail)" : "") . "\n";
        $failed++;
    }
}

echo "============================================================\n";
echo "Running Aadhaar XML Verifier Comprehensive Test Suite\n";
echo "============================================================\n\n";

// Test 1: Multiline Base64 Certificate Extraction
echo "Test Group 1: X.509 Embedded Certificate Normalization & Parsing\n";
$fixtureCert = file_get_contents(dirname(__DIR__) . '/config/certificates/test_fixtures/test_uidai_cert.pem');
$cleanBase64 = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $fixtureCert);

// Simulate embedded XML certificate with carriage returns, newlines, and indentation
$multilineXmlCert = "   \r\n   " . chunk_split($cleanBase64, 40, "\r\n") . "   \n\t   ";
$pemResult = AadhaarXmlVerifier::normalizeCertToPem($multilineXmlCert);
assertTest("Normalize multiline whitespace-embedded certificate to PEM", $pemResult !== null && str_contains($pemResult, '-----BEGIN CERTIFICATE-----'));

$pubKey = openssl_pkey_get_public($pemResult);
assertTest("Extract public key resource from normalized PEM", $pubKey !== false);

// Test 2: Binary DER Certificate Conversion
echo "\nTest Group 2: Binary DER Certificate Handling\n";
$derBytes = base64_decode($cleanBase64);
$derToPem = AadhaarXmlVerifier::normalizeCertToPem($derBytes);
assertTest("Normalize binary DER certificate data to valid PEM", $derToPem !== null);
$pubKeyFromDer = openssl_pkey_get_public($derToPem);
assertTest("Extract public key from binary DER certificate", $pubKeyFromDer !== false);

// Test 3: End-to-End Signature and XMLDSIG Verification
echo "\nTest Group 3: Cryptographic Signature & Demographic Validation\n";
$signedXmlPath = dirname(__DIR__) . '/tests/fixtures/test_signed_ekyc.xml';
if (file_exists($signedXmlPath)) {
    // 3a: Verification with test fixtures allowed
    $verifyResult = AadhaarXmlVerifier::verify($signedXmlPath, null, ['allow_test_fixtures' => true]);
    assertTest("Valid XMLDSIG signature verifies successfully", !empty($verifyResult['valid']) && $verifyResult['valid'] === true);
    assertTest("Code is VERIFIED", ($verifyResult['code'] ?? '') === 'VERIFIED');
    assertTest("Name extracted accurately", ($verifyResult['name'] ?? '') === 'Test Farmer');
    assertTest("Masked Aadhaar (4 digits) extracted without full number", ($verifyResult['aadhaar_last4'] ?? '') === '1234');
    assertTest("Full address concatenated properly", str_contains($verifyResult['address'] ?? '', 'Tenali'));

    // 3b: Production Mode Strictly Rejects Test Fixtures
    $prodResult = AadhaarXmlVerifier::verify($signedXmlPath, null, ['allow_test_fixtures' => false]);
    assertTest("Production mode rejects test fixture certificates", empty($prodResult['valid']) && ($prodResult['code'] ?? '') === 'TEST_CERT_REJECTED_IN_PRODUCTION');
} else {
    echo "  [SKIP] Signed XML test fixture file not found\n";
}

// Test 4: Tampering Detection (Cryptographic Digest Check)
echo "\nTest Group 4: Cryptographic Anti-Tampering Protection\n";
if (file_exists($signedXmlPath)) {
    $rawXml = file_get_contents($signedXmlPath);
    $tamperedXml = str_replace('Test Farmer', 'Tampered Malicious Name', $rawXml);
    $tempTampered = dirname(__DIR__) . '/ekyc_tests/temp_tampered.xml';
    file_put_contents($tempTampered, $tamperedXml);

    $tamperResult = AadhaarXmlVerifier::verify($tempTampered, null, ['allow_test_fixtures' => true]);
    assertTest("Altered demographic data triggers DIGEST_MISMATCH", empty($tamperResult['valid']) && ($tamperResult['code'] ?? '') === 'DIGEST_MISMATCH');
    @unlink($tempTampered);
}

// Test 5: Untrusted Third-Party Certificate Rejection
echo "\nTest Group 5: Trust Boundary & Untrusted Signer Rejection\n";
$cnf = 'C:/xampp/php/extras/ssl/openssl.cnf';
$res = @openssl_pkey_new(['config' => $cnf, 'private_key_bits' => 2048]);
if ($res) {
    $csr = @openssl_csr_new(['commonName' => 'Untrusted Signer'], $res, ['config' => $cnf]);
    $cert = @openssl_csr_sign($csr, null, $res, 1, ['config' => $cnf]);
    openssl_x509_export($cert, $untrustedPem);
    openssl_pkey_export($res, $untrustedPriv, null, ['config' => $cnf]);

    $dom = new DOMDocument();
    $dom->load($signedXmlPath);
    $xpath = new DOMXPath($dom);
    $xpath->registerNamespace('ds', 'http://www.w3.org/2000/09/xmldsig#');
    $signedInfo = $xpath->query('//ds:SignedInfo')->item(0);
    $c14nSignedInfo = $signedInfo->C14N(true, false);
    openssl_sign($c14nSignedInfo, $sigBytes, $untrustedPriv, OPENSSL_ALGO_SHA256);
    $xpath->query('//ds:SignatureValue')->item(0)->nodeValue = base64_encode($sigBytes);
    $cleanUntrusted = preg_replace('/-----(BEGIN|END) CERTIFICATE-----|\s+/', '', $untrustedPem);
    $xpath->query('//ds:X509Certificate')->item(0)->nodeValue = "\n" . chunk_split($cleanUntrusted, 64, "\n");

    $tempUntrusted = dirname(__DIR__) . '/ekyc_tests/temp_untrusted.xml';
    $dom->save($tempUntrusted);

    $untrustedResult = AadhaarXmlVerifier::verify($tempUntrusted, null, ['allow_test_fixtures' => true]);
    assertTest("Self-signed/untrusted certificate rejected as UNTRUSTED_ROOT_CERTIFICATE", 
        empty($untrustedResult['valid']) && ($untrustedResult['code'] ?? '') === 'UNTRUSTED_ROOT_CERTIFICATE');
    @unlink($tempUntrusted);
}

// Test 6: Official UIDAI Public Certificate Inspection & Path Consistency
echo "\nTest Group 6: Installed Authentic UIDAI Certificate Validation\n";
$officialCertPath = dirname(__DIR__) . '/certificates/uidai_offline_publickey_2026.cer';
$trustedUidaiPath = dirname(__DIR__) . '/config/certificates/trusted_uidai/uidai_offline_publickey_2026.cer';

assertTest("Official certificate exists in certificates/", file_exists($officialCertPath));
assertTest("Official certificate exists in config/certificates/trusted_uidai/", file_exists($trustedUidaiPath));

if (file_exists($officialCertPath)) {
    $officialRaw = file_get_contents($officialCertPath);
    $officialPem = AadhaarXmlVerifier::normalizeCertToPem($officialRaw);
    assertTest("Official certificate normalizes to valid PEM", $officialPem !== null);

    $parsedOfficial = openssl_x509_parse($officialPem);
    $org = $parsedOfficial['subject']['O'] ?? '';
    $cn  = $parsedOfficial['subject']['CN'] ?? '';
    assertTest("Certificate Subject Org is UNIQUE IDENTIFICATION AUTHORITY OF INDIA", $org === 'UNIQUE IDENTIFICATION AUTHORITY OF INDIA');
    assertTest("Certificate Common Name is UIDAI Digital Signature (DS)", str_contains($cn, 'DS Unique Identification Authority of India'));
    
    $keyUsage = $parsedOfficial['extensions']['keyUsage'] ?? '';
    assertTest("Key Usage includes Digital Signature", str_contains($keyUsage, 'Digital Signature'));
    
    $validTo = $parsedOfficial['validTo_time_t'] ?? 0;
    assertTest("Certificate is currently unexpired (valid until " . date('Y-m-d', $validTo) . ")", $validTo > time());

    // Check consistency between certificates/ and config/certificates/trusted_uidai/
    $trustedRaw = file_get_contents($trustedUidaiPath);
    assertTest("certificates/ and config/certificates/trusted_uidai/ certificates match exactly", hash('sha256', $officialRaw) === hash('sha256', $trustedRaw));
}

echo "\n============================================================\n";
echo "Summary: $passed Passed, $failed Failed\n";
echo "============================================================\n";

exit($failed > 0 ? 1 : 0);

